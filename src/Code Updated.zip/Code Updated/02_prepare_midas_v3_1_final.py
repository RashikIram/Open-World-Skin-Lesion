#!/usr/bin/env python
"""
MRA-MIDAS FINAL REVIEWER-HARDENED PREPROCESSING / SOURCE-ROTATION PROTOCOL V3.1
=====================================================================

This script prepares the public MRA-MIDAS release for TWO SEPARATE uses:

A) PAD-UFES source experiment
   MIDAS is an independent external target.
   Outputs modality-controlled lesion-level MIDAS test cohorts.

B) MIDAS source-rotation experiment
   MIDAS becomes the labeled source.
   Outputs a patient-disjoint 70/15/15 source split using one 6-inch
   clinical image per lesion.

IMPORTANT
---------
The two roles must NOT be mixed in the same experiment. If MIDAS is the
source, do not also report MIDAS as an external target for that setup.

Why V2 exists
-------------
The public release supplied here has no explicit lesion_id column.
The earlier draft used too many metadata fields to define lesion identity,
which can split one lesion when per-image metadata are inconsistent.

V2 instead uses the conservative release-level lesion key:

    midas_record_id
    + midas_location
    + midas_path
    + midas_iscontrol

This gives 1,189 release-level lesion groups in the supplied public CSV:
    964 biopsied/non-control groups
    225 control groups

Those counts are consistent with the public Stanford-only release being a
near-complete subset of the full 1,290-lesion / 1,046-biopsied study cohort.

Repeated images at the same acquisition distance remain within ONE lesion.
The script chooses one image deterministically per lesion/modality instead of
treating repeated photographs as independent lesions.

Primary MIDAS source modality
-----------------------------
6-inch clinical photography.

Reason:
PAD-UFES is a clinical/macroscopic source. MIDAS 6-inch clinical photography
is the most defensible source-domain replacement for the source-rotation
experiment. Dermoscopy is exported separately for external/modality analyses.

Textualization
--------------
Uses the same fixed schema and single-field ablations used in the final PAD/ISIC/MCR protocol:
    text_age_only
    text_location_only
    text_shared_robust
    text_core
    text_full
    text_missing_explicit

- core/full omit unavailable fields.
- missing_explicit writes unavailable fields as "unknown".
- pathology/diagnosis/clinical impressions/race/ethnicity are NEVER put into
  the model text.
- MIDAS personal melanoma history is retained for audit but is NOT mapped to
  the broader "personal skin cancer history" field because "no melanoma" does
  not imply "no prior skin cancer".

Primary six known classes
-------------------------
AK, BCC, MEL, NEV, SCC, SK

MIDAS mapping:
    malignant- ak                  -> AK
    malignant- bcc                 -> BCC
    malignant- melanoma            -> MEL
    benign-melanocytic nevus       -> NEV
    malignant- scc / sccis         -> SCC
    benign-seborrheic keratosis    -> SK

Semantic unknowns for external open-world evaluation:
    benign-dermatofibroma          -> DF
    benign-hemangioma              -> ANG

Broad "other" pathology categories are retained only in an audit table.

Default inputs
--------------
C:\\Users\\Nebula PC\\Downloads\\Deep Learning\\release_midas.csv
C:\\Users\\Nebula PC\\Downloads\\Deep Learning\\data.csv

Default output
--------------
C:\\Users\\Nebula PC\\Downloads\\Deep Learning\\preprocessed_outputs_midas_v3_1_final

Example
-------
python prepare_mra_midas_protocol_v2_corrected.py
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import unicodedata
from pathlib import Path

import numpy as np
import pandas as pd


# =============================================================================
# CONFIG
# =============================================================================

ROOT = Path(r"C:\Users\Nebula PC\Downloads\Deep Learning")
DEFAULT_METADATA = ROOT / "release_midas.csv"
DEFAULT_MANIFEST = ROOT / "data.csv"
DEFAULT_OUTPUT = ROOT / "preprocessed_outputs_midas_v3_1_final"

RANDOM_STATE = 42
SOURCE_SPLIT_TRIALS = 1000

DATASET_NAME = "MRA-MIDAS"
KNOWN_CLASSES = ["AK", "BCC", "MEL", "NEV", "SCC", "SK"]
SEMANTIC_UNKNOWNS = ["DF", "ANG"]
LABEL_TO_ID = {c: i for i, c in enumerate(KNOWN_CLASSES)}

LESION_KEY_COLS = [
    "midas_record_id",
    "midas_location",
    "midas_path",
    "midas_iscontrol",
]

PATHOLOGY_MAP = {
    "malignant- ak": "AK",
    "malignant- bcc": "BCC",
    "malignant- melanoma": "MEL",
    "benign-melanocytic nevus": "NEV",
    "malignant- scc": "SCC",
    "malignant- sccis": "SCC",
    "benign-seborrheic keratosis": "SK",
    "benign-dermatofibroma": "DF",
    "benign-hemangioma": "ANG",
}

HETEROGENEOUS_OOD = {
    "benign-other",
    "benign-fibrous papule",
    "malignant- other",
    "malignant-other",
    "other- non-neoplastic, inflammatory, infectious",
    "other- melanocytic lesion, possible re-excision (severe, spitz, aimp)",
    "melanocytic tumor, possible re-excision (severe, spitz, aimp)",
}

DISTANCE_CANONICAL = {
    "dscope": "dscope",
    "6in": "6in",
    "1ft": "1ft",
    "n/a - virtual": "virtual",
}

MISSING_TOKENS = {
    "", "nan", "none", "null", "n/a", "na", "unknown", "unk"
}


# =============================================================================
# TEXTUALIZATION SCHEMA — SAME STUDY-WIDE FIELD SET
# =============================================================================

STD_FIELD_LABELS = [
    ("std_age", "age group"),
    ("std_sex", "sex"),
    ("std_location", "anatomical site"),
    ("std_diameter", "diameter"),
    ("std_fitzpatrick", "Fitzpatrick type"),
    ("std_itch", "itching"),
    ("std_grew", "growth"),
    ("std_hurt", "pain"),
    ("std_changed", "change"),
    ("std_bleed", "bleeding"),
    ("std_elevation", "elevation"),
    ("std_personal_skin_cancer_history", "personal skin cancer history"),
    ("std_family_skin_cancer_history", "family skin cancer history"),
    ("std_general_cancer_history", "general cancer history"),
    ("std_smoking", "smoking"),
    ("std_alcohol", "alcohol"),
    ("std_pesticide_exposure", "pesticide exposure"),
    ("std_sunbed_use", "sunbed use"),
    ("std_organ_transplant", "organ transplant"),
    ("std_immunosuppression", "immunosuppression"),
    ("std_natural_hair_color", "natural hair color"),
    ("std_skin_reaction_to_sun", "skin reaction to sun"),
    ("std_moles_body_18", "moles on body at age 18"),
    ("std_moles_bigger_5mm", "moles larger than 5 mm"),
    ("std_moles_bigger_20cm", "moles field bigger 20 cm"),
    ("std_moles_body", "moles on body"),
    ("std_sunburn_number_group", "sunburn count group"),
]

CORE_FIELDS = ["std_age", "std_sex", "std_location"]
AGE_ONLY_FIELDS = ["std_age"]
LOCATION_ONLY_FIELDS = ["std_location"]
FULL_FIELDS = [x[0] for x in STD_FIELD_LABELS]
FIELD_TO_LABEL = dict(STD_FIELD_LABELS)


# =============================================================================
# HELPERS
# =============================================================================

def is_missing(x) -> bool:
    if pd.isna(x):
        return True
    return str(x).strip().lower() in MISSING_TOKENS


def norm_text(x):
    if is_missing(x):
        return np.nan
    return re.sub(r"\s+", " ", str(x).strip().lower())


def stable_str(x):
    if pd.isna(x):
        return "<NA>"
    return re.sub(r"\s+", " ", str(x).strip())


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def stable_table_hash(df: pd.DataFrame, cols: list[str], sort_cols: list[str]) -> str:
    q = df[[c for c in cols if c in df.columns]].copy()
    for c in q.columns:
        q[c] = q[c].fillna("").astype(str)
    q = q.sort_values([c for c in sort_cols if c in q.columns]).reset_index(drop=True)
    payload = q.to_csv(index=False, lineterminator="\n")
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def source_membership_hash(df: pd.DataFrame) -> str:
    cols = ["sample_id", "midas_record_id", "split", "image_file"]
    return stable_table_hash(df, cols, ["split", "sample_id"])


def lesion_semantic_hash(df: pd.DataFrame) -> str:
    cols = [
        "derived_lesion_id", "midas_record_id", "midas_location", "midas_path",
        "label_harmonized", "pathology_role", "std_age", "std_sex",
        "std_location", "std_diameter", "std_diameter_mm",
        "std_diameter_definition", "age_available", "sex_available",
        "location_available", "text_age_only", "text_location_only",
        "text_shared_robust", "text_core", "text_full",
        "text_missing_explicit",
    ]
    return stable_table_hash(df, cols, ["derived_lesion_id"])


def json_dump(obj, path: Path) -> None:
    def conv(x):
        if isinstance(x, Path):
            return str(x)
        if isinstance(x, (np.integer,)):
            return int(x)
        if isinstance(x, (np.floating,)):
            x = float(x)
            return None if math.isnan(x) else x
        if isinstance(x, np.ndarray):
            return x.tolist()
        if isinstance(x, dict):
            return {str(k): conv(v) for k, v in x.items()}
        if isinstance(x, (list, tuple)):
            return [conv(v) for v in x]
        return x

    path.write_text(json.dumps(conv(obj), indent=2), encoding="utf-8")


def normalize_filename_stem(x):
    if is_missing(x):
        return None
    return Path(str(x).strip()).stem.lower()


def normalize_age(x):
    """Decade-band age harmonization shared with PAD/ISIC/MCR."""
    if is_missing(x):
        return "unknown"
    try:
        v = float(x)
        if not np.isfinite(v) or v < 0:
            return "unknown"
        start = int(math.floor(v / 10.0) * 10)
        return f"{start}-{start + 9}"
    except (TypeError, ValueError):
        return "unknown"


def normalize_sex(x):
    if is_missing(x):
        return "unknown"
    s = str(x).strip().lower()
    if s in {"female", "f"}:
        return "female"
    if s in {"male", "m"}:
        return "male"
    return s


def normalize_fitzpatrick(x):
    if is_missing(x):
        return "unknown"
    s = str(x).strip().lower()
    roman = re.match(r"^\s*(i{1,3}|iv|v|vi)\b", s)
    if roman:
        d = {"i": "1", "ii": "2", "iii": "3", "iv": "4", "v": "5", "vi": "6"}
        return d[roman.group(1)]
    num = re.match(r"^\s*([1-6])(?:\.0)?\b", s)
    if num:
        return num.group(1)
    return "unknown"


def format_number(x):
    if is_missing(x):
        return None
    try:
        v = float(x)
        if not np.isfinite(v):
            return None
        if abs(v - round(v)) < 1e-9:
            return str(int(round(v)))
        return f"{v:.1f}".rstrip("0").rstrip(".")
    except (TypeError, ValueError):
        return None


def harmonize_site(x):
    """
    Word-boundary anatomical harmonization.

    Critical fix: "forearm" must never match the substring "ear".
    """
    if is_missing(x):
        return "unknown"

    s = unicodedata.normalize("NFKC", str(x)).replace("\xa0", " ")
    s = re.sub(r"\s+", " ", s.lower().strip())

    if s in {"unknown", "unclear"}:
        return "unknown"

    if re.search(r"\b(vulva|vulvar|penis|penile|genital|oral mucosa|buccal|tongue)\b", s):
        return "mucosal"

    if re.search(r"\b(finger|thumb|pinky|digit|hand|foot|toe|heel|plantar|intertarsal)\b", s):
        return "distal_extremity"

    if re.search(
        r"\b(scalp|crown|vertex|forehead|temple|cheek|chin|jaw|jawline|mandible|"
        r"nose|nasal|alar|ear|helix|antihelix|antitragus|conchal|auricular|"
        r"postauricular|preauricular|eyebrow|eyelid|canthus|lip|vermilion|"
        r"philtrum|neck|occiput|parietal|hairline|sideburn|malar|melolabia|submental)\b",
        s,
    ):
        return "head_neck"

    if re.search(r"\b(forearm|upper arm|arm|elbow|wrist|deltoid|shoulder|clavicle|axilla)\b", s):
        return "upper_extremity"

    if re.search(r"\b(thigh|leg|calf|shin|knee|ankle|malleolus|popliteal)\b", s):
        return "lower_extremity"

    if re.search(
        r"\b(abdomen|abdominal|back|chest|breast|flank|ribcage|hip|buttock|"
        r"buttox|inframammary|infra mammary|inguinal|groin|suprapubic|"
        r"supra pubic|mons pubis|hypogastric|umbilicus|side|scapula)\b",
        s,
    ):
        return "trunk"

    return "UNMAPPED"


def strict_mode(series: pd.Series):
    """Most frequent non-missing value; ties become NaN."""
    vals = [v for v in series.tolist() if not is_missing(v)]
    if not vals:
        return np.nan

    cleaned = [re.sub(r"\s+", " ", str(v).strip()) for v in vals]
    vc = pd.Series(cleaned).value_counts()
    if len(vc) == 1:
        return vc.index[0]
    if vc.iloc[0] > vc.iloc[1]:
        return vc.index[0]
    return np.nan


def make_lesion_id(row) -> str:
    payload = "||".join(
        f"{c}={stable_str(row[c]).lower()}"
        for c in LESION_KEY_COLS
    )
    return "MIDAS_LESION_" + hashlib.sha1(payload.encode("utf-8")).hexdigest()[:16]


# =============================================================================
# MANIFEST RESOLUTION
# =============================================================================

def resolve_manifest(metadata: pd.DataFrame, manifest: pd.DataFrame):
    if "file_name" not in manifest.columns:
        raise RuntimeError("data.csv must contain column 'file_name'.")

    mani = manifest.copy()
    mani["manifest_stem"] = mani["file_name"].map(normalize_filename_stem)

    stem_counts = mani["manifest_stem"].value_counts(dropna=False)
    unique_map = (
        mani[mani["manifest_stem"].map(stem_counts).eq(1)]
        .set_index("manifest_stem")["file_name"]
        .to_dict()
    )
    exact = set(mani["file_name"].astype(str))
    all_stems = set(mani["manifest_stem"].dropna())

    work = metadata.copy()
    work["metadata_stem"] = work["midas_file_name"].map(normalize_filename_stem)

    files, statuses = [], []
    for original, stem in zip(work["midas_file_name"], work["metadata_stem"]):
        original = str(original).strip()

        if original in exact:
            files.append(original)
            statuses.append("exact")
        elif stem in unique_map:
            files.append(unique_map[stem])
            statuses.append("unique_stem_extension_repair")
        elif stem in all_stems:
            files.append(np.nan)
            statuses.append("ambiguous_manifest_stem")
        else:
            files.append(np.nan)
            statuses.append("manifest_unmatched")

    work["image_file_resolved"] = files
    work["image_match_status"] = statuses
    work["image_manifest_resolved"] = work["image_file_resolved"].notna()

    return work


# =============================================================================
# RELEASE-LEVEL LESION MASTER
# =============================================================================

PATIENT_LEVEL_FIELDS = [
    "midas_gender",
    "midas_age",
    "midas_fitzpatrick",
    "midas_melanoma",
    "midas_ethnicity",
    "midas_race",
]

LESION_LEVEL_AUDIT_FIELDS = [
    "clinical_impression_1",
    "clinical_impression_2",
    "clinical_impression_3",
    "length__mm_",
    "width__mm_",
    "midas_pathreport",
]


def add_patient_consensus(work: pd.DataFrame) -> pd.DataFrame:
    out = work.copy()

    consensus = {}
    for patient_id, g in out.groupby("midas_record_id", dropna=False):
        consensus[patient_id] = {
            f: strict_mode(g[f])
            for f in PATIENT_LEVEL_FIELDS
        }

    for f in PATIENT_LEVEL_FIELDS:
        out[f"{f}_patient_consensus"] = [
            consensus[p][f] for p in out["midas_record_id"]
        ]

    return out


def lesion_master_from_rows(work: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for key, g in work.groupby(LESION_KEY_COLS, dropna=False, sort=False):
        first = g.iloc[0]

        row = {
            "derived_lesion_id": make_lesion_id(first),
            "midas_record_id": first["midas_record_id"],
            "midas_location": first["midas_location"],
            "midas_path": first["midas_path"],
            "midas_iscontrol": first["midas_iscontrol"],
            "n_image_rows": int(len(g)),
        }

        # Stable patient-level consensus.
        for f in PATIENT_LEVEL_FIELDS:
            row[f] = first.get(f"{f}_patient_consensus", np.nan)

        # Lesion-level fields are consensus-audited.
        for f in LESION_LEVEL_AUDIT_FIELDS:
            row[f] = strict_mode(g[f])
            nonmiss = {
                re.sub(r"\s+", " ", str(v).strip())
                for v in g[f].tolist()
                if not is_missing(v)
            }
            row[f"{f}_conflict"] = len(nonmiss) > 1

        # One deterministic image per acquisition type.
        for raw_distance, canonical in DISTANCE_CANONICAL.items():
            q = g[
                g["midas_distance"].astype(str).str.strip().str.lower().eq(raw_distance)
            ].copy()

            row[f"n_{canonical}_rows"] = int(len(q))
            q_resolved = q[q["image_manifest_resolved"]].copy()
            row[f"n_{canonical}_resolved_rows"] = int(len(q_resolved))

            if q_resolved.empty:
                row[f"image_{canonical}"] = np.nan
                row[f"image_{canonical}_selection_status"] = "unavailable"
            else:
                chosen = sorted(q_resolved["image_file_resolved"].astype(str))[0]
                row[f"image_{canonical}"] = chosen
                row[f"image_{canonical}_selection_status"] = (
                    "single"
                    if len(q_resolved) == 1
                    else "deterministic_first_of_repeated_views"
                )

        rows.append(row)

    lesion = pd.DataFrame(rows)

    pathology_norm = lesion["midas_path"].apply(norm_text)
    lesion["label_harmonized"] = pathology_norm.map(PATHOLOGY_MAP)

    control = (
        lesion["midas_iscontrol"].astype(str).str.strip().str.lower().eq("yes")
    )

    lesion["pathology_role"] = np.where(
        control,
        "control_not_primary",
        np.where(
            lesion["label_harmonized"].isin(KNOWN_CLASSES),
            "known",
            np.where(
                lesion["label_harmonized"].isin(SEMANTIC_UNKNOWNS),
                "semantic_unknown",
                np.where(
                    pathology_norm.isin(HETEROGENEOUS_OOD),
                    "heterogeneous_ood",
                    np.where(
                        pathology_norm.isna(),
                        "missing_pathology",
                        "unmapped_pathology",
                    ),
                ),
            ),
        ),
    )

    return lesion


# =============================================================================
# STANDARDIZATION + TEXTUALIZATION
# =============================================================================

def format_text_value(field, value):
    if field == "std_age" and value != "unknown":
        return f"{value} years"
    return value


def build_text(row, fields, explicit_missing=False):
    parts = []
    for field in fields:
        value = row.get(field, "unknown")
        if is_missing(value):
            value = "unknown"
        value = str(value).strip().lower()

        if value == "unknown" and not explicit_missing:
            continue

        parts.append(
            f"{FIELD_TO_LABEL[field]}: {format_text_value(field, value)}"
        )

    if not parts:
        return "Patient metadata unavailable."

    return "Patient metadata: " + "; ".join(parts) + "."


def standardize_lesions(lesion: pd.DataFrame) -> pd.DataFrame:
    out = lesion.copy()

    for field, _ in STD_FIELD_LABELS:
        out[field] = "unknown"

    out["std_age"] = out["midas_age"].apply(normalize_age)
    out["std_sex"] = out["midas_gender"].apply(normalize_sex)
    out["std_location"] = out["midas_location"].apply(harmonize_site)
    out["std_fitzpatrick"] = out["midas_fitzpatrick"].apply(normalize_fitzpatrick)

    def diameter_mm(row):
        vals = []
        for key in ["length__mm_", "width__mm_"]:
            try:
                v = float(row.get(key))
                if np.isfinite(v):
                    vals.append(v)
            except (TypeError, ValueError):
                pass
        return max(vals) if vals else np.nan

    out["std_diameter_mm"] = out.apply(diameter_mm, axis=1)
    out["std_diameter"] = out["std_diameter_mm"].apply(
        lambda x: "unknown"
        if pd.isna(x)
        else f"{float(x):.1f}".rstrip("0").rstrip(".") + " mm"
    )
    out["std_diameter_definition"] = (
        "lesion diameter in mm; MIDAS method=max(length,width)"
    )

    # Deliberately DO NOT map midas_melanoma into
    # std_personal_skin_cancer_history. The MIDAS variable is melanoma-specific,
    # while the study-wide standardized field is broader.

    for field, _ in STD_FIELD_LABELS:
        out[field] = out[field].apply(
            lambda x: "unknown"
            if is_missing(x)
            else str(x).strip().lower()
        )

    out["age_available"] = ~out["std_age"].apply(is_missing)
    out["sex_available"] = ~out["std_sex"].apply(is_missing)
    out["location_available"] = ~out["std_location"].apply(is_missing)

    out["text_age_only"] = out.apply(
        lambda r: build_text(r, AGE_ONLY_FIELDS, explicit_missing=False),
        axis=1,
    )
    out["text_location_only"] = out.apply(
        lambda r: build_text(r, LOCATION_ONLY_FIELDS, explicit_missing=False),
        axis=1,
    )

    out["text_core"] = out.apply(
        lambda r: build_text(r, CORE_FIELDS, explicit_missing=False),
        axis=1,
    )
    out["text_full"] = out.apply(
        lambda r: build_text(r, FULL_FIELDS, explicit_missing=False),
        axis=1,
    )
    out["text_missing_explicit"] = out.apply(
        lambda r: build_text(r, FULL_FIELDS, explicit_missing=True),
        axis=1,
    )

    # Restricted shared-schema primary cross-domain textualization. Sex is excluded here
    # because PAD-UFES has biopsy/acquisition-linked sex missingness.
    out["text_shared_robust"] = out.apply(
        lambda r: build_text(r, ["std_age", "std_location"], explicit_missing=False),
        axis=1,
    )
    out["primary_text_column"] = "text_shared_robust"
    out["text_core_role"] = "secondary_demographic_sensitivity_due_PAD_sex_missingness"
    out["text_full_role"] = "heterogeneous_schema_stress_test"
    out["text_missing_explicit_role"] = "informative_missingness_stress_test_only"

    return out


# =============================================================================
# MODELLING TABLES
# =============================================================================

def make_model_table(
    lesion: pd.DataFrame,
    modality: str,
    roles: set[str],
    split_name: str,
) -> pd.DataFrame:
    image_col = f"image_{modality}"

    q = lesion[
        lesion["pathology_role"].isin(roles)
        & lesion[image_col].notna()
    ].copy()

    q["dataset"] = DATASET_NAME
    q["role"] = "target"
    q["split"] = split_name
    q["sample_id"] = q["derived_lesion_id"]
    q["image_id"] = q[image_col]
    q["image_file"] = q[image_col]
    q["image_modality"] = modality

    q["known_unknown"] = np.where(
        q["label_harmonized"].isin(KNOWN_CLASSES),
        "known",
        "unknown",
    )
    q["is_unknown"] = ~q["label_harmonized"].isin(KNOWN_CLASSES)
    q["label_id"] = q["label_harmonized"].map(LABEL_TO_ID)
    q["label_open_id"] = np.where(
        q["is_unknown"],
        len(KNOWN_CLASSES),
        q["label_id"],
    )

    # Common aliases expected by the existing project style.
    q["age_clean"] = q["midas_age"]
    q["sex_clean"] = q["midas_gender"]
    q["site_clean"] = q["midas_location"]

    front = [
        "dataset", "role", "split",
        "sample_id", "image_id", "image_file", "image_modality",
        "midas_record_id", "derived_lesion_id",
        "label_harmonized", "label_id", "label_open_id",
        "known_unknown", "is_unknown", "pathology_role",
        "midas_path",
        "age_clean", "sex_clean", "site_clean",
        "std_age", "std_sex", "std_location", "std_diameter",
        "std_fitzpatrick", "age_available", "sex_available", "location_available",
        "text_age_only", "text_location_only",
        "text_shared_robust", "text_core", "text_full", "text_missing_explicit",
    ]
    rest = [c for c in q.columns if c not in front]
    return q[[c for c in front if c in q.columns] + rest].reset_index(drop=True)


# =============================================================================
# PATIENT-DISJOINT MIDAS SOURCE SPLIT
# =============================================================================

def optimize_patient_split(
    source: pd.DataFrame,
    trials: int = SOURCE_SPLIT_TRIALS,
    seed: int = RANDOM_STATE,
):
    """
    Deterministic stochastic-search allocation at PATIENT level.

    Objective balances:
    - total lesion count,
    - per-class lesion counts,
    while keeping all lesions from one midas_record_id in the same split.
    """

    ratios = {
        "source_train": 0.70,
        "source_val": 0.15,
        "source_test": 0.15,
    }

    patient_stats = {}
    for p, g in source.groupby("midas_record_id"):
        vc = g["label_harmonized"].value_counts()
        patient_stats[p] = {
            "size": int(len(g)),
            "counts": {c: int(vc.get(c, 0)) for c in KNOWN_CLASSES},
        }

    patients = list(patient_stats)
    total_n = len(source)
    total_class = {
        c: int((source["label_harmonized"] == c).sum())
        for c in KNOWN_CLASSES
    }

    target_size = {s: total_n * r for s, r in ratios.items()}
    target_class = {
        s: {c: total_class[c] * ratios[s] for c in KNOWN_CLASSES}
        for s in ratios
    }

    freq = {c: max(total_class[c], 1) for c in KNOWN_CLASSES}

    def fresh():
        return {
            s: {
                "patients": set(),
                "size": 0,
                "counts": {c: 0 for c in KNOWN_CLASSES},
            }
            for s in ratios
        }

    def add(state, s, p):
        state[s]["patients"].add(p)
        state[s]["size"] += patient_stats[p]["size"]
        for c in KNOWN_CLASSES:
            state[s]["counts"][c] += patient_stats[p]["counts"][c]

    def remove(state, s, p):
        state[s]["patients"].remove(p)
        state[s]["size"] -= patient_stats[p]["size"]
        for c in KNOWN_CLASSES:
            state[s]["counts"][c] -= patient_stats[p]["counts"][c]

    def objective(state):
        score = 0.0
        for s in ratios:
            score += 3.0 * (
                (state[s]["size"] - target_size[s])
                / max(target_size[s], 1.0)
            ) ** 2

            for c in KNOWN_CLASSES:
                tc = target_class[s][c]
                score += (
                    (state[s]["counts"][c] - tc)
                    / max(tc, 1.0)
                ) ** 2

                if state[s]["counts"][c] == 0:
                    score += 1000.0

        return score

    rng = np.random.default_rng(seed)
    best_score = None
    best_state = None

    for _ in range(trials):
        state = fresh()

        order = sorted(
            patients,
            key=lambda p: -(
                sum(
                    patient_stats[p]["counts"][c] / freq[c]
                    for c in KNOWN_CLASSES
                )
                + rng.random() * 0.30
            ),
        )

        for p in order:
            candidates = []

            for s in ratios:
                add(state, s, p)
                sc = objective(state)

                # Discourage major overshoot while still allowing whole patients.
                if state[s]["size"] > 1.15 * target_size[s]:
                    sc += 10.0 * (
                        (state[s]["size"] - target_size[s])
                        / max(target_size[s], 1.0)
                    ) ** 2

                remove(state, s, p)
                candidates.append((sc, s))

            min_sc = min(x[0] for x in candidates)
            best_splits = [
                s for sc, s in candidates
                if abs(sc - min_sc) < 1e-12
            ]
            chosen = best_splits[int(rng.integers(len(best_splits)))]
            add(state, chosen, p)

        sc = objective(state)
        if best_score is None or sc < best_score:
            best_score = sc
            best_state = state

    if best_state is None:
        raise RuntimeError("MIDAS patient split optimization failed.")

    all_assigned = set().union(
        *(best_state[s]["patients"] for s in best_state)
    )
    if all_assigned != set(patients):
        raise RuntimeError("MIDAS source patient allocation incomplete.")

    split_sets = {
        s: set(best_state[s]["patients"])
        for s in best_state
    }

    # Hard patient-disjoint audit.
    names = list(split_sets)
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            overlap = split_sets[a] & split_sets[b]
            if overlap:
                raise RuntimeError(
                    f"MIDAS patient leakage {a} vs {b}: {sorted(overlap)[:10]}"
                )

    return best_score, best_state


def build_midas_source_6in(lesion: pd.DataFrame, trials: int = SOURCE_SPLIT_TRIALS):
    source = make_model_table(
        lesion,
        modality="6in",
        roles={"known"},
        split_name="UNASSIGNED_SOURCE",
    )

    source["role"] = "source"

    score, state = optimize_patient_split(source, trials=trials)

    patient_to_split = {}
    for split_name, info in state.items():
        for p in info["patients"]:
            patient_to_split[p] = split_name

    source["split"] = source["midas_record_id"].map(patient_to_split)

    if source["split"].isna().any():
        raise RuntimeError("Unassigned MIDAS source rows after patient split.")

    # Re-check patient overlap from final table.
    patient_sets = {
        s: set(source.loc[source["split"].eq(s), "midas_record_id"])
        for s in ["source_train", "source_val", "source_test"]
    }
    assert not (patient_sets["source_train"] & patient_sets["source_val"])
    assert not (patient_sets["source_train"] & patient_sets["source_test"])
    assert not (patient_sets["source_val"] & patient_sets["source_test"])

    # No unknowns allowed in labeled source.
    if source["is_unknown"].any():
        raise RuntimeError("Unknown lesion entered MIDAS source cohort.")

    return source, score, state


# =============================================================================
# AUDITS
# =============================================================================

def make_release_vs_paper_audit(
    raw: pd.DataFrame,
    lesion: pd.DataFrame,
) -> pd.DataFrame:
    """
    Published full-study values are background references, NOT equality targets,
    because the public Stanford release is a near-complete Stanford subset.
    """

    noncontrol = lesion[
        lesion["midas_iscontrol"].astype(str).str.strip().str.lower().eq("no")
    ]
    control = lesion[
        lesion["midas_iscontrol"].astype(str).str.strip().str.lower().eq("yes")
    ]

    rows = [
        {
            "metric": "image_rows",
            "observed_public_release": len(raw),
            "published_full_study": 3830,
            "interpretation": "Public release is Stanford-only/near-entirety; equality not required.",
        },
        {
            "metric": "unique_midas_record_id",
            "observed_public_release": raw["midas_record_id"].nunique(),
            "published_full_study": 796,
            "interpretation": "Paper reports 734 Stanford + 62 Cleveland patients.",
        },
        {
            "metric": "derived_lesion_groups",
            "observed_public_release": len(lesion),
            "published_full_study": 1290,
            "interpretation": "Derived public-release lesion grouping; full study includes Cleveland.",
        },
        {
            "metric": "noncontrol_biopsied_groups",
            "observed_public_release": len(noncontrol),
            "published_full_study": 1046,
            "interpretation": "Public Stanford release subset; not an equality assertion.",
        },
        {
            "metric": "control_groups",
            "observed_public_release": len(control),
            "published_full_study": 244,
            "interpretation": "Public Stanford release subset; not an equality assertion.",
        },
        {
            "metric": "dscope_image_rows",
            "observed_public_release": int(
                raw["midas_distance"].astype(str).str.lower().eq("dscope").sum()
            ),
            "published_full_study": 1187,
            "interpretation": "Paper full-study image count.",
        },
        {
            "metric": "6in_image_rows",
            "observed_public_release": int(
                raw["midas_distance"].astype(str).str.lower().eq("6in").sum()
            ),
            "published_full_study": 1198,
            "interpretation": "Paper describes 15-cm clinical images.",
        },
        {
            "metric": "1ft_image_rows",
            "observed_public_release": int(
                raw["midas_distance"].astype(str).str.lower().eq("1ft").sum()
            ),
            "published_full_study": 1185,
            "interpretation": "Paper describes 30-cm clinical images.",
        },
        {
            "metric": "virtual_image_rows",
            "observed_public_release": int(
                raw["midas_distance"].astype(str).str.lower().eq("n/a - virtual").sum()
            ),
            "published_full_study": 260,
            "interpretation": "Paper full-study image count.",
        },
    ]

    return pd.DataFrame(rows)


# =============================================================================
# MAIN
# =============================================================================

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--metadata", type=Path, default=DEFAULT_METADATA)
    ap.add_argument("--manifest", type=Path, default=DEFAULT_MANIFEST)
    ap.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    ap.add_argument("--source-split-trials", type=int, default=SOURCE_SPLIT_TRIALS)
    args = ap.parse_args()

    outdir = args.output_dir
    outdir.mkdir(parents=True, exist_ok=True)

    if not args.metadata.exists():
        raise FileNotFoundError(args.metadata)
    if not args.manifest.exists():
        raise FileNotFoundError(args.manifest)

    raw = pd.read_csv(args.metadata, low_memory=False)
    manifest = pd.read_csv(args.manifest, low_memory=False)

    required = {
        "midas_record_id",
        "midas_file_name",
        "midas_iscontrol",
        "midas_distance",
        "midas_location",
        "midas_path",
        "midas_pathreport",
        "midas_gender",
        "midas_age",
        "midas_fitzpatrick",
        "midas_melanoma",
        "midas_ethnicity",
        "midas_race",
        "clinical_impression_1",
        "clinical_impression_2",
        "clinical_impression_3",
        "length__mm_",
        "width__mm_",
    }

    missing = required - set(raw.columns)
    if missing:
        raise RuntimeError(
            f"release_midas.csv missing required columns: {sorted(missing)}"
        )

    if raw["midas_file_name"].duplicated().any():
        bad = raw.loc[
            raw["midas_file_name"].duplicated(keep=False),
            "midas_file_name",
        ].head(20).tolist()
        raise RuntimeError(f"Duplicate metadata image filenames: {bad}")

    # -------------------------------------------------------------------------
    # Resolve images and derive patient/lesion tables.
    # -------------------------------------------------------------------------
    work = resolve_manifest(raw, manifest)
    work = add_patient_consensus(work)
    work["derived_lesion_id"] = work.apply(make_lesion_id, axis=1)

    lesion = lesion_master_from_rows(work)
    lesion = standardize_lesions(lesion)

    # Critical semantic location audit.
    if lesion["std_location"].eq("UNMAPPED").any():
        bad = lesion.loc[
            lesion["std_location"].eq("UNMAPPED"),
            ["midas_location", "derived_lesion_id"],
        ].head(50)
        raise RuntimeError(
            "Unmapped MIDAS locations after reviewer correction:\n"
            + bad.to_string(index=False)
        )

    forearm_bad = lesion[
        lesion["midas_location"].astype(str).str.contains(
            r"\bforearm\b", case=False, regex=True, na=False
        )
        & ~lesion["std_location"].eq("upper_extremity")
    ]
    if not forearm_bad.empty:
        raise RuntimeError(
            "FOREARM harmonization failure in MIDAS V3:\n"
            + forearm_bad[["midas_location", "std_location"]].head(50).to_string(index=False)
        )

    # Strong ID integrity.
    if lesion["derived_lesion_id"].duplicated().any():
        raise RuntimeError("Derived MIDAS lesion IDs are not unique.")

    # -------------------------------------------------------------------------
    # Save row-level and lesion-level audits.
    # -------------------------------------------------------------------------
    work.to_csv(outdir / "midas_release_row_audit.csv", index=False)
    lesion.to_csv(outdir / "midas_lesion_master.csv", index=False)

    image_audit_cols = [
        "_unnamed_var",
        "midas_record_id",
        "midas_file_name",
        "midas_distance",
        "midas_location",
        "midas_path",
        "derived_lesion_id",
        "image_file_resolved",
        "image_match_status",
    ]
    work[[c for c in image_audit_cols if c in work.columns]].to_csv(
        outdir / "midas_image_matching_audit.csv",
        index=False,
    )

    release_vs_paper = make_release_vs_paper_audit(raw, lesion)
    release_vs_paper.to_csv(
        outdir / "midas_release_vs_paper_audit.csv",
        index=False,
    )

    label_audit = (
        lesion.groupby(
            ["midas_path", "label_harmonized", "pathology_role"],
            dropna=False,
        )
        .size()
        .reset_index(name="n_lesion_groups")
        .sort_values("n_lesion_groups", ascending=False)
    )
    label_audit.to_csv(
        outdir / "midas_label_mapping_audit.csv",
        index=False,
    )

    # -------------------------------------------------------------------------
    # External target cohorts — PAD is source.
    # -------------------------------------------------------------------------
    external_tables = {}

    for modality in ["dscope", "6in", "1ft"]:
        known = make_model_table(
            lesion,
            modality=modality,
            roles={"known"},
            split_name="external_test",
        )
        openworld = make_model_table(
            lesion,
            modality=modality,
            roles={"known", "semantic_unknown"},
            split_name="external_test",
        )

        external_tables[f"{modality}_known"] = known
        external_tables[f"{modality}_openworld"] = openworld

        known.to_csv(
            outdir / f"midas_external_{modality}_known.csv",
            index=False,
        )
        openworld.to_csv(
            outdir / f"midas_external_{modality}_openworld.csv",
            index=False,
        )

    # Paired dermoscopy / 6in known subset: SAME lesions in both files.
    dscope_known = external_tables["dscope_known"]
    six_known = external_tables["6in_known"]

    paired_ids = sorted(
        set(dscope_known["derived_lesion_id"])
        & set(six_known["derived_lesion_id"])
    )

    paired_dscope = dscope_known[
        dscope_known["derived_lesion_id"].isin(paired_ids)
    ].copy()
    paired_six = six_known[
        six_known["derived_lesion_id"].isin(paired_ids)
    ].copy()

    paired_dscope = paired_dscope.sort_values("derived_lesion_id").reset_index(drop=True)
    paired_six = paired_six.sort_values("derived_lesion_id").reset_index(drop=True)

    if paired_dscope["derived_lesion_id"].tolist() != paired_six["derived_lesion_id"].tolist():
        raise RuntimeError("Paired MIDAS dscope/6in lesion IDs do not align.")

    paired_dscope.to_csv(
        outdir / "midas_paired_dscope_known.csv",
        index=False,
    )
    paired_six.to_csv(
        outdir / "midas_paired_6in_known.csv",
        index=False,
    )

    # Broad pathology categories — audit only.
    hetero = lesion[
        lesion["pathology_role"].eq("heterogeneous_ood")
    ].copy()
    hetero.to_csv(
        outdir / "midas_heterogeneous_ood_lesion_audit.csv",
        index=False,
    )

    # -------------------------------------------------------------------------
    # MIDAS-source setup — 6in clinical, patient-disjoint 70/15/15.
    # -------------------------------------------------------------------------
    source, split_score, split_state = build_midas_source_6in(
        lesion, trials=int(args.source_split_trials)
    )

    for split_name in ["source_train", "source_val", "source_test"]:
        part = source[source["split"].eq(split_name)].copy()
        part.to_csv(
            outdir / f"midas_6in_{split_name}.csv",
            index=False,
        )

    source.to_csv(
        outdir / "midas_6in_source_all.csv",
        index=False,
    )

    split_audit_rows = []
    for split_name in ["source_train", "source_val", "source_test"]:
        part = source[source["split"].eq(split_name)]
        row = {
            "split": split_name,
            "n_lesions": int(len(part)),
            "n_patients": int(part["midas_record_id"].nunique()),
        }
        for c in KNOWN_CLASSES:
            row[c] = int((part["label_harmonized"] == c).sum())
        split_audit_rows.append(row)

    split_audit = pd.DataFrame(split_audit_rows)
    split_audit.to_csv(
        outdir / "midas_source_split_audit.csv",
        index=False,
    )

    # -------------------------------------------------------------------------
    # Textualization audit.
    # -------------------------------------------------------------------------
    text_audit_rows = []

    audit_sets = {
        "external_dscope_known": external_tables["dscope_known"],
        "external_6in_known": external_tables["6in_known"],
        "source_6in_all": source,
    }

    for cohort_name, df in audit_sets.items():
        for text_col in [
            "text_age_only", "text_location_only", "text_shared_robust",
            "text_core", "text_full", "text_missing_explicit"
        ]:
            text_audit_rows.append({
                "cohort": cohort_name,
                "text_col": text_col,
                "n_rows": int(len(df)),
                "n_missing_text": int(df[text_col].isna().sum()),
                "n_contains_unknown": int(
                    df[text_col]
                    .str.contains(r"\bunknown\b", case=False, regex=True, na=False)
                    .sum()
                ),
                "mean_chars": float(df[text_col].astype(str).str.len().mean()),
            })

    text_audit = pd.DataFrame(text_audit_rows)

    # Core/full MUST omit explicit unknown.
    bad_core = int(
        source["text_core"]
        .str.contains(r"\bunknown\b", case=False, regex=True, na=False)
        .sum()
    )
    bad_full = int(
        source["text_full"]
        .str.contains(r"\bunknown\b", case=False, regex=True, na=False)
        .sum()
    )
    if bad_core or bad_full:
        raise RuntimeError(
            f"Textualization contract violated: core unknown={bad_core}, "
            f"full unknown={bad_full}"
        )

    text_audit.to_csv(
        outdir / "midas_textualization_audit.csv",
        index=False,
    )

    # -------------------------------------------------------------------------
    # Explicit three-pass audit summaries.
    # -------------------------------------------------------------------------
    pass1_rows = [
        {"check": "raw metadata image filenames unique", "passed": not raw["midas_file_name"].duplicated().any()},
        {"check": "raw image row count", "passed": len(raw) == 3416, "details": len(raw)},
        {"check": "manifest exact+repair resolution accounting", "passed": int(work["image_manifest_resolved"].sum()) == 3357, "details": int(work["image_manifest_resolved"].sum())},
        {"check": "derived lesion IDs unique", "passed": not lesion["derived_lesion_id"].duplicated().any()},
    ]
    pd.DataFrame(pass1_rows).to_csv(outdir / "midas_release_manifest_audit_pass1.csv", index=False)
    if not all(bool(r["passed"]) for r in pass1_rows):
        raise RuntimeError("MIDAS V3.1 PASS1 release/manifest audit failed.")

    pass2_rows = [
        {"check": "zero unmapped anatomical sites", "passed": not lesion["std_location"].eq("UNMAPPED").any()},
        {"check": "all forearm lesions upper_extremity", "passed": forearm_bad.empty},
        {
            "check": "source train/val/test patient disjoint",
            "passed": (
                set(source.loc[source["split"].eq("source_train"), "midas_record_id"].astype(str)).isdisjoint(
                    set(source.loc[source["split"].eq("source_val"), "midas_record_id"].astype(str))
                )
                and set(source.loc[source["split"].eq("source_train"), "midas_record_id"].astype(str)).isdisjoint(
                    set(source.loc[source["split"].eq("source_test"), "midas_record_id"].astype(str))
                )
                and set(source.loc[source["split"].eq("source_val"), "midas_record_id"].astype(str)).isdisjoint(
                    set(source.loc[source["split"].eq("source_test"), "midas_record_id"].astype(str))
                )
            ),
        },
        {"check": "external 6in known count", "passed": len(external_tables["6in_known"]) == 717, "details": len(external_tables["6in_known"])},
        {"check": "external dscope known count", "passed": len(external_tables["dscope_known"]) == 732, "details": len(external_tables["dscope_known"])},
        {"check": "restricted shared-schema and single-field text available", "passed": lesion[["text_age_only", "text_location_only", "text_shared_robust"]].notna().all().all()},
    ]
    pd.DataFrame(pass2_rows).to_csv(outdir / "midas_semantic_split_audit_pass2.csv", index=False)
    if not all(bool(r["passed"]) for r in pass2_rows):
        raise RuntimeError("MIDAS V3.1 PASS2 semantic/split audit failed.")

    # -------------------------------------------------------------------------
    # Protocol manifest.
    # -------------------------------------------------------------------------
    modality_summary = {}
    for modality in ["dscope", "6in", "1ft"]:
        k = external_tables[f"{modality}_known"]
        o = external_tables[f"{modality}_openworld"]
        modality_summary[modality] = {
            "known_n": int(len(k)),
            "known_class_counts": k["label_harmonized"].value_counts().sort_index().to_dict(),
            "openworld_n": int(len(o)),
            "unknown_n": int(o["is_unknown"].sum()),
            "openworld_class_counts": o["label_harmonized"].value_counts().sort_index().to_dict(),
        }

    patient_conflicts = {}
    for f in PATIENT_LEVEL_FIELDS:
        conflict_patients = 0
        for _, g in raw.groupby("midas_record_id", dropna=False):
            vals = {
                re.sub(r"\s+", " ", str(v).strip())
                for v in g[f].tolist()
                if not is_missing(v)
            }
            if len(vals) > 1:
                conflict_patients += 1
        patient_conflicts[f] = conflict_patients

    manifest_obj = {
        "protocol": "mra_midas_v3_1_final",
        "final_frozen_protocol": True,
        "random_state": RANDOM_STATE,
        "metadata_path": str(args.metadata),
        "metadata_sha256": sha256_file(args.metadata),
        "manifest_path": str(args.manifest),
        "manifest_sha256": sha256_file(args.manifest),
        "dataset_role_options": {
            "pad_source_setup": (
                "MIDAS external target only; use modality-specific external files."
            ),
            "midas_source_setup": (
                "MIDAS is labeled source; use 6in patient-disjoint source splits."
            ),
        },
        "derived_lesion_key": LESION_KEY_COLS,
        "derived_lesion_key_caveat": (
            "Public release has no explicit lesion_id; this is a reproducible "
            "release-level inferred grouping, not an official lesion identifier."
        ),
        "release_counts": {
            "image_rows": int(len(raw)),
            "unique_midas_record_id": int(raw["midas_record_id"].nunique()),
            "derived_lesion_groups": int(len(lesion)),
            "noncontrol_groups": int(
                lesion["midas_iscontrol"]
                .astype(str).str.lower().eq("no").sum()
            ),
            "control_groups": int(
                lesion["midas_iscontrol"]
                .astype(str).str.lower().eq("yes").sum()
            ),
        },
        "image_matching": work["image_match_status"].value_counts().to_dict(),
        "label_mapping": PATHOLOGY_MAP,
        "known_classes": KNOWN_CLASSES,
        "semantic_unknowns": SEMANTIC_UNKNOWNS,
        "broad_ood_policy": "audit only; excluded from primary semantic-open-world cohort",
        "patient_metadata_conflict_counts": patient_conflicts,
        "repeated_same_modality_policy": (
            "same lesion; deterministic lexicographically first resolved image"
        ),
        "external_target_modalities": modality_summary,
        "paired_dscope_6in_known_n": int(len(paired_ids)),
        "midas_source": {
            "primary_modality": "6in",
            "reason": "clinical/macroscopic source rotation comparable to PAD-UFES",
            "n_lesions": int(len(source)),
            "n_patients": int(source["midas_record_id"].nunique()),
            "split_ratio_target": "70/15/15",
            "split_unit": "midas_record_id",
            "patient_disjoint": True,
            "split_objective_score": float(split_score),
            "split_audit": split_audit.to_dict(orient="records"),
        },
        "textualization": {
            "core_fields": CORE_FIELDS,
            "primary_text_column": "text_shared_robust",
            "primary_description": (
                "restricted shared-schema text; reduces but does not eliminate missingness effects"
            ),
            "shared_schema_primary_fields": ["std_age", "std_location"],
            "text_age_only_fields": AGE_ONLY_FIELDS,
            "text_location_only_fields": LOCATION_ONLY_FIELDS,
            "full_fields": FULL_FIELDS,
            "text_full_missing_policy": "omit unavailable fields",
            "text_missing_explicit_policy": "same full schema; explicit unknown",
            "pathology_in_text": False,
            "clinical_impressions_in_text": False,
            "race_in_text": False,
            "ethnicity_in_text": False,
            "midas_melanoma_mapped_to_general_skin_cancer_history": False,
        },
        "three_pass_audit": {
            "pass1_release_manifest_all_true": all(bool(r["passed"]) for r in pass1_rows),
            "pass2_semantic_split_all_true": all(bool(r["passed"]) for r in pass2_rows),
            "pass3_reload_all_true": None,
        },
        "published_full_study_reference_counts": {
            "patients": 796,
            "stanford_patients": 734,
            "cleveland_patients": 62,
            "unique_lesions": 1290,
            "biopsied_histopathology_confirmed": 1046,
            "controls": 244,
            "images": 3830,
            "dscope": 1187,
            "clinical_15cm": 1198,
            "clinical_30cm": 1185,
            "virtual": 260,
            "note": (
                "These are full-study values from the MIDAS paper. "
                "The public Stanford release is a near-complete subset, so "
                "exact equality is NOT required."
            ),
        },
    }

    manifest_obj["lesion_semantic_sha256"] = lesion_semantic_hash(lesion)
    manifest_obj["source_membership_sha256"] = source_membership_hash(source)

    # Record hashes of model-facing outputs generated so far.
    output_hashes = {}
    for p in sorted(outdir.glob("*.csv")):
        output_hashes[p.name] = sha256_file(p)
    manifest_obj["output_file_sha256"] = output_hashes

    json_dump(
        manifest_obj,
        outdir / "midas_protocol_manifest_v3_1.json",
    )

    # -------------------------------------------------------------------------
    # Independent reload audit (second cross-check).
    # -------------------------------------------------------------------------
    reload_audit_rows = []

    def _reload_check(name, condition, details=""):
        reload_audit_rows.append(
            {"check": name, "passed": bool(condition), "details": str(details)}
        )
        if not condition:
            raise RuntimeError(
                f"MIDAS V3 RELOAD AUDIT FAILED: {name}: {details}"
            )

    lesion_reload = pd.read_csv(
        outdir / "midas_lesion_master.csv",
        low_memory=False,
    )
    source_reload = pd.read_csv(
        outdir / "midas_6in_source_all.csv",
        low_memory=False,
    )

    _reload_check(
        "derived lesion count",
        len(lesion_reload) == 1189,
        len(lesion_reload),
    )
    _reload_check(
        "non-control group count",
        int(
            lesion_reload["midas_iscontrol"]
            .astype(str)
            .str.lower()
            .eq("no")
            .sum()
        ) == 964,
    )
    _reload_check(
        "control group count",
        int(
            lesion_reload["midas_iscontrol"]
            .astype(str)
            .str.lower()
            .eq("yes")
            .sum()
        ) == 225,
    )
    _reload_check(
        "zero unmapped anatomical sites",
        not lesion_reload["std_location"].eq("UNMAPPED").any(),
    )

    reload_forearm = lesion_reload[
        lesion_reload["midas_location"]
        .astype(str)
        .str.contains(r"\bforearm\b", case=False, regex=True, na=False)
    ]
    _reload_check(
        "all forearm lesions map upper_extremity",
        reload_forearm["std_location"].eq("upper_extremity").all(),
        int((~reload_forearm["std_location"].eq("upper_extremity")).sum()),
    )

    age_ok = lesion_reload["std_age"].astype(str).str.match(
        r"^(?:\d{1,3}-\d{1,3}|unknown)$"
    )
    _reload_check(
        "age is decade-band or unknown",
        bool(age_ok.all()),
        int((~age_ok).sum()),
    )

    diam_rows = lesion_reload[
        lesion_reload["std_diameter_mm"].notna()
    ].copy()
    recomputed_diam = diam_rows.apply(
        lambda row: max(
            [
                float(v)
                for v in [row.get("length__mm_"), row.get("width__mm_")]
                if pd.notna(v) and np.isfinite(float(v))
            ]
        ),
        axis=1,
    )
    _reload_check(
        "diameter equals max(length,width)",
        np.allclose(
            diam_rows["std_diameter_mm"].astype(float),
            recomputed_diam.astype(float),
            equal_nan=True,
        ),
    )

    _reload_check(
        "lesion semantic hash survives disk round-trip",
        lesion_semantic_hash(lesion_reload) == lesion_semantic_hash(lesion),
        lesion_semantic_hash(lesion_reload),
    )
    _reload_check(
        "single-field textualizations exist after reload",
        lesion_reload["text_age_only"].notna().all()
        and lesion_reload["text_location_only"].notna().all(),
    )

    split_counts_reload = (
        source_reload["split"]
        .value_counts()
        .to_dict()
    )
    _reload_check(
        "source split lesion counts",
        split_counts_reload
        == {
            "source_train": 502,
            "source_val": 108,
            "source_test": 107,
        },
        split_counts_reload,
    )

    patient_sets = {
        split: set(
            source_reload.loc[
                source_reload["split"].eq(split),
                "midas_record_id",
            ].astype(str)
        )
        for split in ["source_train", "source_val", "source_test"]
    }
    _reload_check(
        "source train/val patient disjoint",
        not (patient_sets["source_train"] & patient_sets["source_val"]),
    )
    _reload_check(
        "source train/test patient disjoint",
        not (patient_sets["source_train"] & patient_sets["source_test"]),
    )
    _reload_check(
        "source val/test patient disjoint",
        not (patient_sets["source_val"] & patient_sets["source_test"]),
    )

    _reload_check(
        "source membership hash survives disk round-trip",
        source_membership_hash(source_reload) == source_membership_hash(source),
        source_membership_hash(source_reload),
    )

    pd.DataFrame(reload_audit_rows).to_csv(
        outdir / "midas_reload_audit_v3_1.csv",
        index=False,
    )

    if not all(row["passed"] for row in reload_audit_rows):
        raise RuntimeError("MIDAS V3 reload audit unexpectedly contains a failure.")

    manifest_obj["three_pass_audit"]["pass3_reload_all_true"] = True
    # Refresh hashes to include audit outputs produced after the first manifest write.
    manifest_obj["output_file_sha256"] = {
        p.name: sha256_file(p) for p in sorted(outdir.glob("*.csv"))
    }
    json_dump(manifest_obj, outdir / "midas_protocol_manifest_v3_1.json")

    (outdir / "MIDAS_V3_1_THREE_PASS_AUDIT_PASSED.flag").write_text(
        "mra_midas_v3_1_final\n"
        "PASS1_RELEASE_MANIFEST=TRUE\n"
        "PASS2_SEMANTIC_SPLIT=TRUE\n"
        "PASS3_RELOAD=TRUE\n",
        encoding="utf-8",
    )

    # -------------------------------------------------------------------------
    # Console summary.
    # -------------------------------------------------------------------------
    print("\n" + "=" * 108)
    print("MRA-MIDAS V3.1 FINAL REVIEWER-HARDENED PREPROCESSING COMPLETE")
    print("=" * 108)

    print(f"\nRaw image rows: {len(raw)}")
    print(f"Unique midas_record_id: {raw['midas_record_id'].nunique()}")
    print(f"Derived lesion groups: {len(lesion)}")

    print("\nControl status:")
    print(
        lesion["midas_iscontrol"]
        .value_counts(dropna=False)
        .to_string()
    )

    print("\nLesion-level pathology mapping:")
    print(
        lesion["label_harmonized"]
        .value_counts(dropna=False)
        .sort_index()
        .to_string()
    )

    print("\nImage matching:")
    print(work["image_match_status"].value_counts().to_string())

    print("\nExternal target cohorts:")
    for modality in ["dscope", "6in", "1ft"]:
        info = modality_summary[modality]
        print(
            f"  {modality}: known={info['known_n']}, "
            f"openworld={info['openworld_n']}, unknown={info['unknown_n']}"
        )

    print(f"\nPaired dscope+6in known lesions: {len(paired_ids)}")

    print("\nMIDAS 6in source split:")
    print(split_audit.to_string(index=False))

    print(f"\nOutput directory: {outdir}")
    print(
        "\nIMPORTANT: use MIDAS external files only when PAD is source; "
        "use MIDAS source split files only in the source-rotation setup."
    )


if __name__ == "__main__":
    main()
