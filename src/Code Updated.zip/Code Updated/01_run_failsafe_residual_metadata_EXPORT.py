#!/usr/bin/env python
from __future__ import annotations

"""
01 — FAIL-SAFE RESIDUAL METADATA FUSION (PAN-DERM ANCHOR)
=========================================================

Core hypothesis
---------------
A strong source-fine-tuned image model should remain the safe default. Metadata
is allowed to provide a RESIDUAL logit correction only when it is reliable:

    logits = image_logits + g(x,m) * delta_metadata

The PanDerm image-only F0-v3 checkpoint is the anchor. By default it is frozen.
The metadata path is BioClinicalBERT, using exactly the frozen V2.1 text columns.

Ablations
---------
naive_concat
mixture_gate
residual_no_gate
scalar_gate
uncertainty_gate
disagreement_gate
perturbation_gate
full_failsafe
full_failsafe_no_safety
full_failsafe_no_meta_aux

The dynamic-mixture baseline is important reviewer control: it separates the
proposed source-anchored residual formulation from generic adaptive gating.

Reliability inputs are added progressively:
    image entropy
    metadata entropy
    image-metadata JS disagreement
    controlled metadata-perturbation instability
    V2.1 field-availability fraction

Training / selection
--------------------
PAD source_train only; PAD source_val Macro-F1 only.
No target data or labels are used for training this script.
Evaluation is the exact F0 development cohort plus the exact frozen DermLIP-MCM
open-world branch.

The purpose is not merely to maximize a score. The main scientific endpoint is
whether the method reduces NEGATIVE TRANSFER for Full / Explicit-missingness
relative to the strong PanDerm image-only anchor.
"""

import argparse
import gc
import importlib
import importlib.util
import contextlib
import io
import json
import math
import os
import random
import re
import subprocess
import sys
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from PIL import Image
from torch.utils.data import DataLoader, Dataset
from transformers import AutoModel, AutoTokenizer
from tqdm.auto import tqdm


DEFAULT_ROOT=Path(r"C:\Users\Nebula PC\Downloads\Deep Learning")
SEEDS=[42,123,2026]
VIEWS=["age","location","shared_robust","core","full","missing_explicit"]
VARIANTS=[
    "naive_concat",
    "mixture_gate",
    "residual_no_gate",
    "scalar_gate",
    "uncertainty_gate",
    "disagreement_gate",
    "perturbation_gate",
    "full_failsafe",
    "full_failsafe_no_safety",
    "full_failsafe_no_meta_aux",
]

FIELD_LABELS=[
("std_age","age group"),("std_sex","sex"),("std_location","anatomical site"),
("std_diameter","lesion diameter"),("std_fitzpatrick","Fitzpatrick type"),
("std_itch","itching"),("std_grew","growth"),("std_hurt","pain"),
("std_changed","change"),("std_bleed","bleeding"),("std_elevation","elevation"),
("std_personal_skin_cancer_history","personal skin cancer history"),
("std_family_skin_cancer_history","family skin cancer history"),
("std_general_cancer_history","general cancer history"),("std_smoking","smoking"),
("std_alcohol","alcohol"),("std_pesticide_exposure","pesticide exposure"),
("std_sunbed_use","sunbed use"),("std_organ_transplant","organ transplant"),
("std_immunosuppression","immunosuppression"),
("std_natural_hair_color","natural hair color"),
("std_skin_reaction_to_sun","skin reaction to sun"),
("std_moles_body_18","moles on body at age 18"),
("std_moles_bigger_5mm","moles larger than 5 mm"),
("std_moles_bigger_20cm","moles field bigger 20 cm"),
("std_moles_body","moles on body"),
("std_sunburn_number_group","sunburn count group")]
FIELD_TO_LABEL=dict(FIELD_LABELS)
FULL_FIELDS=[x[0] for x in FIELD_LABELS]
VIEW_FIELDS={
"age":["std_age"],"location":["std_location"],
"shared_robust":["std_age","std_location"],
"core":["std_age","std_sex","std_location"],
"full":FULL_FIELDS,"missing_explicit":FULL_FIELDS,
}

BATCH_SIZE=16
EVAL_BATCH_SIZE=64
MAX_EPOCHS=35
EARLY_STOP=6
LR_TEXT=3e-5
LR_HEAD=1e-4
WEIGHT_DECAY=0.01
LAMBDA_META=0.10
LAMBDA_SAFETY=0.50
LAMBDA_GATE=0.01
GRAD_CLIP=3.0
HIDDEN=128


def jdump(obj,path):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    def cv(x):
        if isinstance(x,Path): return str(x)
        if isinstance(x,(np.integer,)): return int(x)
        if isinstance(x,(np.floating,)):
            v=float(x); return None if not np.isfinite(v) else v
        if isinstance(x,np.ndarray): return x.tolist()
        if isinstance(x,dict): return {str(k):cv(v) for k,v in x.items()}
        if isinstance(x,(list,tuple)): return [cv(v) for v in x]
        return x
    path.write_text(json.dumps(cv(obj),indent=2),encoding="utf-8")


def seed_all(seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)


def cleanup():
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        try: torch.cuda.ipc_collect()
        except Exception: pass


def discover_f0(root):
    p=root/"run_f0_foundation_representation_sanity.py"
    if p.exists(): return p
    h=sorted(root.glob("run_f0_foundation_representation_sanity*.py"))
    if not h: raise FileNotFoundError("F0-v3 script missing")
    return h[0]


def import_f0(root):
    p=discover_f0(root).resolve()
    if str(p.parent) not in sys.path: sys.path.insert(0,str(p.parent))
    if p.stem.isidentifier():
        importlib.invalidate_caches(); m=importlib.import_module(p.stem)
    else:
        spec=importlib.util.spec_from_file_location("f0_v3_runtime",p)
        m=importlib.util.module_from_spec(spec); sys.modules["f0_v3_runtime"]=m; spec.loader.exec_module(m)
        if os.name=="nt": m.RUNTIME_NUM_WORKERS=0
    return m,p


def image_ckpt(root,seed):
    return root/"results_f0_backbone_metadata_benchmark"/"development"/"children"/"image__panderm_base"/f"seed_{seed}"/"best.pt"


def missing(x):
    if pd.isna(x): return True
    return str(x).strip().lower() in {"","nan","none","null","unknown","n/a","na"}


def clean(x): return "unknown" if missing(x) else str(x).strip().lower()


def build_text(row,fields,explicit_missing=False):
    parts=[]
    for f in fields:
        v=clean(row.get(f,"unknown"))
        if v=="unknown" and not explicit_missing: continue
        if f=="std_age" and v!="unknown": v=f"{v} years"
        parts.append(f"{FIELD_TO_LABEL[f]}: {v}")
    return "Patient metadata unavailable." if not parts else "Patient metadata: "+"; ".join(parts)+"."


def availability_fraction(row,fields):
    if not fields: return 0.0
    return float(np.mean([not missing(row.get(f,"unknown")) for f in fields]))


def _formatted_field_value(field, value):
    v=clean(value)
    if field=="std_age" and v!="unknown":
        return f"{v} years"
    return v


def _mask_field_in_frozen_text(text, row, field):
    """
    Mask one AVAILABLE field inside the exact frozen F0 text string.

    Unlike rebuilding the whole sentence from std_* columns, this preserves the
    dataset-specific V2.1/V3.1 textualization grammar. That matters for MIDAS,
    where the mechanism audit found a small reconstruction mismatch.

    Returns: (perturbed_text, changed_flag)
    """
    value=clean(row.get(field,"unknown"))
    if value=="unknown":
        return text, 0

    label=FIELD_TO_LABEL[field]
    formatted=_formatted_field_value(field, value)

    # First try the exact reviewer-facing label:value phrase, preserving label
    # and all surrounding text but replacing only the value.
    patt=rf"({re.escape(label)}\s*:\s*){re.escape(formatted)}"
    new,n=re.subn(patt, r"\1unknown", str(text), count=1, flags=re.IGNORECASE)
    if n:
        return new, 1

    # Age is occasionally rendered without the helper's "years" suffix.
    if field=="std_age":
        patt=rf"({re.escape(label)}\s*:\s*){re.escape(value)}"
        new,n=re.subn(patt, r"\1unknown", str(text), count=1, flags=re.IGNORECASE)
        if n:
            return new, 1

    # Conservative fallback: do NOT rebuild the entire sentence. A failed
    # field match becomes a no-op and is audited through perturbation coverage.
    return str(text), 0


def make_perturbation_texts(f0, frame, text_col, view):
    """
    Two deterministic, controlled field-value masks per sample.
    The original frozen textualization remains unchanged except for the selected
    field value. This is a sensitivity perturbation, not a causal counterfactual.
    """
    fields=VIEW_FIELDS[view]
    cf1=[]; cf2=[]; av=[]; cov=[]
    for i,(_,row) in enumerate(frame.iterrows()):
        original=f0.safe_text(row[text_col])
        av.append(availability_fraction(row,fields))
        available=[f for f in fields if not missing(row.get(f,"unknown"))]

        t1=original; c1=0
        if available:
            f1=available[i%len(available)]
            t1,c1=_mask_field_in_frozen_text(original,row,f1)

        t2=original; c2=0
        if len(available)>1:
            f2=available[(i+1)%len(available)]
            t2,c2=_mask_field_in_frozen_text(original,row,f2)
        elif available:
            t2,c2=_mask_field_in_frozen_text(original,row,available[0])

        cf1.append(t1); cf2.append(t2)
        cov.append(0.5*(c1+c2))
    return cf1,cf2,np.asarray(av,dtype=np.float32),np.asarray(cov,dtype=np.float32)

class FailSafeDataset(Dataset):
    def __init__(self,f0,frame,transform,tokenizer,text_col,view,train,return_label):
        self.frame=frame.reset_index(drop=True)
        self.transform=transform
        self.train=train
        self.return_label=return_label
        orig=[f0.safe_text(x) for x in self.frame[text_col].tolist()]
        cf1,cf2,av,cov=make_perturbation_texts(f0,self.frame,text_col,view)
        def enc(texts):
            z=tokenizer(texts,padding="max_length",truncation=True,max_length=f0.MAX_TEXT_LEN,return_tensors="pt")
            return z["input_ids"].contiguous(),z["attention_mask"].contiguous()
        self.ids,self.mask=enc(orig)
        self.cf1_ids,self.cf1_mask=enc(cf1)
        self.cf2_ids,self.cf2_mask=enc(cf2)
        self.av=torch.from_numpy(av)
        self.perturbation_coverage=torch.from_numpy(cov)
    def __len__(self): return len(self.frame)
    def __getitem__(self,i):
        r=self.frame.iloc[i]
        out={
            "pixel_values":self.transform(Image.open(r["image_path"]).convert("RGB")),
            "input_ids":self.ids[i],"attention_mask":self.mask[i],
            "cf1_input_ids":self.cf1_ids[i],"cf1_attention_mask":self.cf1_mask[i],
            "cf2_input_ids":self.cf2_ids[i],"cf2_attention_mask":self.cf2_mask[i],
            "availability":self.av[i],
            "perturbation_coverage":self.perturbation_coverage[i],
            "index":torch.tensor(i,dtype=torch.long),
        }
        if self.return_label: out["label"]=torch.tensor(int(r["label_id"]),dtype=torch.long)
        return out


def entropy_from_logits(x):
    p=F.softmax(x,dim=1).clamp_min(1e-8)
    return -(p*p.log()).sum(1)/math.log(x.shape[1])


def js_from_logits(a,b):
    p=F.softmax(a,dim=1).clamp_min(1e-8)
    q=F.softmax(b,dim=1).clamp_min(1e-8)
    m=.5*(p+q)
    return .5*(p*(p.log()-m.log())).sum(1)+.5*(q*(q.log()-m.log())).sum(1)


class FailSafeModel(nn.Module):
    def __init__(self,f0,image_anchor,variant,num_classes,freeze_anchor=True):
        super().__init__()
        self.f0=f0
        self.image_anchor=image_anchor
        self.variant=variant
        self.freeze_anchor=freeze_anchor
        if freeze_anchor:
            for p in self.image_anchor.parameters(): p.requires_grad_(False)
        self.text_encoder=AutoModel.from_pretrained(f0.BIOCLINICAL_MODEL)
        tdim=int(self.text_encoder.config.hidden_size)
        idim=int(self.image_anchor.classifier.in_features)
        self.text_proj=nn.Sequential(nn.Linear(tdim,HIDDEN),nn.GELU(),nn.LayerNorm(HIDDEN))
        self.meta_head=nn.Linear(HIDDEN,num_classes)
        self.delta_head=nn.Linear(HIDDEN,num_classes)
        self.concat_head=nn.Sequential(
            nn.Linear(idim+HIDDEN,2*HIDDEN),nn.GELU(),nn.Dropout(f0.DROPOUT),nn.Linear(2*HIDDEN,num_classes)
        )
        self.scalar_gate=nn.Parameter(torch.tensor(0.0))
        # Maximum gate input is [Himg,Hmeta,JS,CFinstability,availability].
        self.gate=nn.Sequential(nn.Linear(5,32),nn.GELU(),nn.Linear(32,1))

    def train(self, mode: bool = True):
        super().train(mode)
        if self.freeze_anchor:
            self.image_anchor.eval()
        return self

    def image_features_logits(self,pixel_values):
        with torch.set_grad_enabled(not self.freeze_anchor and self.training):
            z=self.image_anchor.encode(pixel_values)
            logits=self.image_anchor.classifier(z)
        return z,logits

    def text_feature_logits(self,ids,mask):
        o=self.text_encoder(input_ids=ids,attention_mask=mask)
        z=getattr(o,"pooler_output",None)
        if z is None: z=o.last_hidden_state[:,0]
        h=self.text_proj(z)
        return h,self.meta_head(h)

    def gate_value(self,img_logits,meta_logits,cf1_logits,cf2_logits,availability):
        bs=img_logits.shape[0]
        if self.variant=="residual_no_gate":
            return torch.ones(bs,1,device=img_logits.device)
        if self.variant=="scalar_gate":
            return torch.sigmoid(self.scalar_gate).expand(bs,1)
        h_i=entropy_from_logits(img_logits)
        h_m=entropy_from_logits(meta_logits)
        js=js_from_logits(img_logits,meta_logits)
        cf=.5*(js_from_logits(meta_logits,cf1_logits)+js_from_logits(meta_logits,cf2_logits))
        av=availability.float().view(-1)
        features=torch.stack([h_i,h_m,js,cf,av],dim=1)
        if self.variant=="uncertainty_gate":
            features[:,2:]=0
        elif self.variant=="disagreement_gate":
            features[:,3:]=0
        elif self.variant=="perturbation_gate":
            features[:,4]=0
        elif self.variant not in {
            "mixture_gate","full_failsafe",
            "full_failsafe_no_safety","full_failsafe_no_meta_aux"
        }:
            raise ValueError(self.variant)
        return torch.sigmoid(self.gate(features))

    def forward(self,pixel_values,input_ids,attention_mask,cf1_input_ids=None,cf1_attention_mask=None,
                cf2_input_ids=None,cf2_attention_mask=None,availability=None,return_aux=False):
        zi,img_logits=self.image_features_logits(pixel_values)

        needs_perturb=self.variant in {
            "perturbation_gate","full_failsafe",
            "full_failsafe_no_safety","full_failsafe_no_meta_aux"
        }

        if needs_perturb and cf1_input_ids is not None:
            # One BERT call instead of three: identical mathematics, less launch/
            # synchronization overhead.
            all_ids=torch.cat([input_ids,cf1_input_ids,cf2_input_ids],dim=0)
            all_mask=torch.cat([attention_mask,cf1_attention_mask,cf2_attention_mask],dim=0)
            o=self.text_encoder(input_ids=all_ids,attention_mask=all_mask)
            z=getattr(o,"pooler_output",None)
            if z is None: z=o.last_hidden_state[:,0]
            h_all=self.text_proj(z)
            meta_all=self.meta_head(h_all)
            B=input_ids.shape[0]
            h=h_all[:B]
            meta_logits=meta_all[:B]
            cf1_logits=meta_all[B:2*B]
            cf2_logits=meta_all[2*B:]
        else:
            h,meta_logits=self.text_feature_logits(input_ids,attention_mask)
            cf1_logits=meta_logits
            cf2_logits=meta_logits

        if self.variant=="naive_concat":
            logits=self.concat_head(torch.cat([zi,h],dim=1))
            aux={"image_logits":img_logits,"meta_logits":meta_logits,
                 "gate":torch.ones(img_logits.shape[0],1,device=img_logits.device)}
            return (logits,aux) if return_aux else logits

        if availability is None:
            availability=torch.ones(img_logits.shape[0],device=img_logits.device)
        g=self.gate_value(img_logits,meta_logits,cf1_logits,cf2_logits,availability)

        if self.variant=="mixture_gate":
            # Generic dynamic-gating reviewer baseline: interpolate complete
            # image-only and metadata-only predictions.
            logits=(1.0-g)*img_logits + g*meta_logits
            delta=meta_logits-img_logits
        else:
            delta=self.delta_head(h)
            logits=img_logits+g*delta

        aux={"image_logits":img_logits,"meta_logits":meta_logits,"cf1_logits":cf1_logits,
             "cf2_logits":cf2_logits,"gate":g,"delta":delta}
        return (logits,aux) if return_aux else logits


def move(batch,device):
    return {k:(v.to(device,non_blocking=torch.cuda.is_available()) if torch.is_tensor(v) else v)
            for k,v in batch.items()}


def loader(f0,ds,batch,shuffle):
    return DataLoader(ds,**f0.loader_kwargs(batch,shuffle=shuffle))


def export_case_predictions_csv(frame, pred, out_path, meta, classes, y_key="y",
                               prob_key="probs", anchor_key="anchor_probs",
                               gate_key=None):
    """Write development-cohort predictions with hashed case/patient keys."""
    import hashlib
    import json
    import os
    idx = pred.get("index", np.arange(len(pred[prob_key]))).astype(int)
    fr = frame.iloc[idx].reset_index(drop=True)
    probs = pred[prob_key]
    anchor = pred.get(anchor_key)
    ys = pred.get(y_key)
    if ys is None:
        raise ValueError("Case export requires labels on known development cohorts.")
    candidates = ("patient_id", "patient_uid", "patient_group_id",
                  "patient_group", "split_group_id", "group_id", "patient")
    patient_col = next((c for c in candidates if c in fr.columns), None)
    rows = []
    class_names = [str(x) for x in classes]
    for i in range(len(fr)):
        path = str(fr.iloc[i].get("image_path", ""))
        # Hash full normalized path for stable matching across methods on this machine.
        case_raw = os.path.normcase(os.path.abspath(path)) if path else f"row-{idx[i]}"
        case_key = hashlib.sha256(case_raw.encode("utf-8")).hexdigest()[:20]
        patient_raw = str(fr.iloc[i][patient_col]) if patient_col else case_key
        if patient_raw.strip().lower() in {"", "nan", "none", "null"}:
            patient_raw = case_key
        group_key = hashlib.sha256(patient_raw.encode("utf-8")).hexdigest()[:20]
        row = {
            **meta,
            "domain": str(meta.get("domain", "")),
            "sample_key": case_key,
            "bootstrap_group_key": group_key,
            "group_key_type": "patient" if patient_col else "case",
            "y_true": int(ys[i]),
            "y_true_name": (class_names[int(ys[i])] if 0 <= int(ys[i]) < len(class_names) else "UNKNOWN"),
            "class_names_json": json.dumps(class_names, ensure_ascii=False),
            "y_pred": int(np.argmax(probs[i])),
            "y_pred_name": class_names[int(np.argmax(probs[i]))],
            "max_softmax_probability": float(np.max(probs[i])),
            "normalized_entropy": float(-(np.clip(probs[i], 1e-12, 1.0) * np.log(np.clip(probs[i], 1e-12, 1.0))).sum() / np.log(len(class_names))),
        }
        for j, value in enumerate(probs[i]):
            row[f"prob_{j:02d}"] = float(value)
        if anchor is not None:
            row["anchor_y_pred"] = int(np.argmax(anchor[i]))
            for j, value in enumerate(anchor[i]):
                row[f"anchor_prob_{j:02d}"] = float(value)
        if gate_key and gate_key in pred:
            gate = pred[gate_key][i]
            row["residual_gate"] = float(np.asarray(gate).mean())
        rows.append(row)
    import pandas as pd
    pd.DataFrame(rows).to_csv(out_path, index=False)

@torch.no_grad()
def predict(model,loader_,device):
    model.eval(); probs=[]; anchor_probs=[]; ys=[]; gates=[]; idx=[]; cov=[]
    for b in loader_:
        idx.append(b["index"].numpy())
        if "perturbation_coverage" in b:
            cov.append(b["perturbation_coverage"].numpy())
        b=move(b,device)
        logits,aux=model(
            b["pixel_values"],b["input_ids"],b["attention_mask"],
            b["cf1_input_ids"],b["cf1_attention_mask"],
            b["cf2_input_ids"],b["cf2_attention_mask"],b["availability"],True
        )
        probs.append(F.softmax(logits.float(),dim=1).cpu().numpy())
        anchor_probs.append(F.softmax(aux["image_logits"].float(),dim=1).cpu().numpy())
        gates.append(aux["gate"].float().cpu().numpy())
        if "label" in b: ys.append(b["label"].cpu().numpy())
    return {
        "probs":np.concatenate(probs),
        "anchor_probs":np.concatenate(anchor_probs),
        "gate":np.concatenate(gates).reshape(-1),
        "y_true":np.concatenate(ys).astype(int) if ys else None,
        "index":np.concatenate(idx).astype(int),
        "perturbation_coverage":float(np.concatenate(cov).mean()) if cov else np.nan,
    }


def load_anchor(f0,root,frames,t2,v8,seed,device):
    cond=f0.condition_map()["image__panderm_base"]
    _buf=io.StringIO()
    with contextlib.redirect_stdout(_buf):
        model,opt,train_tf,eval_tf,tok,bundle,audit=f0.build_condition_model(
            root,t2,v8,cond,seed,device,frames.source_train
        )
    del opt
    p=image_ckpt(root,seed)
    if not p.exists(): raise FileNotFoundError(p)
    payload=torch.load(p,map_location=device)
    model.load_state_dict(payload.get("state_dict",payload),strict=True)
    return model,train_tf,eval_tf,bundle,p


def run_one(root,view,variant,seed,force=False,export_only=False):
    outroot=root/"results_01_failsafe_residual_v21"
    run=outroot/view/variant/f"seed_{seed}"
    flag=run/"RUN_COMPLETE.flag"
    if flag.exists() and not force and not export_only:
        print(f"[01] skip {view}/{variant}/s{seed}"); return
    run.mkdir(parents=True,exist_ok=True)
    f0,f0_path=import_f0(root)
    frames,t2,t2_path=f0.load_study_frames(root,"development")
    v8,v8_path=f0.import_v8(root)
    device=torch.device("cuda" if torch.cuda.is_available() else "cpu")
    seed_all(seed)
    anchor,train_tf,eval_tf,bundle,anchor_path=load_anchor(f0,root,frames,t2,v8,seed,device)
    tokenizer=AutoTokenizer.from_pretrained(f0.BIOCLINICAL_MODEL)
    model=FailSafeModel(f0,anchor,variant,len(f0.KNOWN_CLASSES),freeze_anchor=True).to(device)

    text_col=f0.TEXT_VARIANTS[view]
    train_ds=FailSafeDataset(f0,frames.source_train,train_tf,tokenizer,text_col,view,True,True)
    val_ds=FailSafeDataset(f0,frames.source_val,eval_tf,tokenizer,text_col,view,False,True)
    tr=loader(f0,train_ds,BATCH_SIZE,True); va=loader(f0,val_ds,EVAL_BATCH_SIZE,False)

    weights,counts=f0.effective_number_loss_weights(frames.source_train,device)
    ce=nn.CrossEntropyLoss(weight=weights)
    ce_none=nn.CrossEntropyLoss(weight=weights,reduction="none")
    params=[
        {"params":model.text_encoder.parameters(),"lr":LR_TEXT},
        {"params":[p for n,p in model.named_parameters() if not n.startswith("text_encoder.") and p.requires_grad],"lr":LR_HEAD},
    ]
    opt=torch.optim.AdamW(params,weight_decay=WEIGHT_DECAY)
    sched=torch.optim.lr_scheduler.ReduceLROnPlateau(opt,mode="max",factor=.5,patience=2)

    best=-1.; patience=0; best_epoch=-1; bestp=run/"best.pt"; hist=[]
    if export_only:
        if not flag.exists():
            raise RuntimeError(f"Refusing export from an incomplete run (RUN_COMPLETE.flag missing): {run}")
        if not bestp.exists():
            raise FileNotFoundError(f"Cannot export; checkpoint missing: {bestp}")
        payload=torch.load(bestp,map_location=device)
        model.load_state_dict(payload["state_dict"],strict=True)
        exports=[]
        for domain,frame in frames.known_eval.items():
            ds=FailSafeDataset(f0,frame,eval_tf,tokenizer,text_col,view,False,True)
            pc=predict(model,loader(f0,ds,EVAL_BATCH_SIZE,False),device)
            export_case_predictions_csv(
                frame, pc, run/f"case_predictions_{re.sub(r'[^A-Za-z0-9]+','_',domain)}.csv",
                {"view":view,"variant":variant,"seed":seed,"domain":domain,
                 "cohort":"development_known_eval"},
                f0.KNOWN_CLASSES, y_key="y_true", gate_key="gate",
            )
            exports.append(pd.read_csv(run/f"case_predictions_{re.sub(r'[^A-Za-z0-9]+','_',domain)}.csv"))
        for domain,frame in frames.open_eval.items():
            ds=FailSafeDataset(f0,frame,eval_tf,tokenizer,text_col,view,False,False)
            pc=predict(model,loader(f0,ds,EVAL_BATCH_SIZE,False),device)
            pc["y_true"]=f0.make_open_targets(frame)
            export_case_predictions_csv(
                frame,pc,run/f"case_predictions_open_{re.sub(r'[^A-Za-z0-9]+','_',domain)}.csv",
                {"view":view,"variant":variant,"seed":seed,"domain":domain,
                 "cohort":"development_open_eval"},
                f0.KNOWN_CLASSES,y_key="y_true",gate_key="gate",
            )
            exports.append(pd.read_csv(run/f"case_predictions_open_{re.sub(r'[^A-Za-z0-9]+','_',domain)}.csv"))
        merged=pd.concat(exports,ignore_index=True) if exports else pd.DataFrame()
        merged.to_csv(run/"case_predictions.csv",index=False)
        for domain in frames.known_eval:
            for prefix in ("case_predictions_", "case_predictions_open_"):
                part=run/f"{prefix}{re.sub(r'[^A-Za-z0-9]+','_',domain)}.csv"
                if part.exists(): part.unlink()
        print(f"[01] exported development predictions: {run/'case_predictions.csv'}")
        return
    for epoch in tqdm(range(1,MAX_EPOCHS+1),desc=f"01 {view}/{variant}/s{seed}",unit="epoch",dynamic_ncols=True):
        model.train()
        agg_loss=torch.zeros((),device=device)
        agg_ce=torch.zeros((),device=device)
        agg_safety=torch.zeros((),device=device)
        agg_gate=torch.zeros((),device=device)
        agg_n=0
        for b in tr:
            b=move(b,device); opt.zero_grad(set_to_none=True)
            logits,aux=model(
                b["pixel_values"],b["input_ids"],b["attention_mask"],
                b["cf1_input_ids"],b["cf1_attention_mask"],
                b["cf2_input_ids"],b["cf2_attention_mask"],b["availability"],True
            )
            cls=ce(logits,b["label"])
            meta=ce(aux["meta_logits"],b["label"])
            # Source-side "do no worse than anchor" soft constraint.
            final_per=ce_none(logits,b["label"])
            anchor_per=ce_none(aux["image_logits"].detach(),b["label"])
            safety=F.relu(final_per-anchor_per).mean()
            gate_pen=aux["gate"].mean()
            meta_weight=0.0 if variant=="full_failsafe_no_meta_aux" else LAMBDA_META
            safety_weight=0.0 if variant in {"naive_concat","full_failsafe_no_safety"} else LAMBDA_SAFETY
            gate_weight=0.0 if variant=="naive_concat" else LAMBDA_GATE

            loss=cls+meta_weight*meta+safety_weight*safety+gate_weight*gate_pen
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(),GRAD_CLIP)
            opt.step()

            bs=len(b["label"]); agg_n+=bs
            agg_loss += loss.detach()*bs
            agg_ce += cls.detach()*bs
            agg_safety += safety.detach()*bs
            agg_gate += gate_pen.detach()*bs

        pc=predict(model,va,device); vm=f0.closed_metrics(pc["y_true"],pc["probs"])
        sched.step(vm["macro_f1"])
        imp=vm["macro_f1"]>best+1e-12
        if imp:
            best=vm["macro_f1"]; best_epoch=epoch; patience=0
            torch.save({"state_dict":model.state_dict(),"view":view,"variant":variant,"seed":seed,
                        "best_source_val_macro_f1":best},bestp)
        else: patience+=1
        hist.append({
            "epoch":epoch,
            "train_loss":float((agg_loss/max(agg_n,1)).cpu()),
            "class_ce":float((agg_ce/max(agg_n,1)).cpu()),
            "safety_hinge":float((agg_safety/max(agg_n,1)).cpu()),
            "mean_gate_train":float((agg_gate/max(agg_n,1)).cpu()),
            "source_val_macro_f1":vm["macro_f1"],
            "source_val_balanced_accuracy":vm["balanced_accuracy"],
            "mean_gate_val":float(pc["gate"].mean()),
            "std_gate_val":float(pc["gate"].std()),
            "perturbation_coverage_val":pc["perturbation_coverage"],
            "patience":patience
        })
        if patience>=EARLY_STOP: break
    pd.DataFrame(hist).to_csv(run/"history.csv",index=False)
    model.load_state_dict(torch.load(bestp,map_location=device)["state_dict"],strict=True)

    closed=[]
    for domain,frame in frames.known_eval.items():
        ds=FailSafeDataset(f0,frame,eval_tf,tokenizer,text_col,view,False,True)
        pc=predict(model,loader(f0,ds,EVAL_BATCH_SIZE,False),device)
        met=f0.closed_metrics(pc["y_true"],pc["probs"])
        anchor_met=f0.closed_metrics(pc["y_true"],pc["anchor_probs"])
        y=pc["y_true"]
        final_pred=pc["probs"].argmax(1)
        anchor_pred=pc["anchor_probs"].argmax(1)
        harm=float(((anchor_pred==y)&(final_pred!=y)).mean())
        rescue=float(((anchor_pred!=y)&(final_pred==y)).mean())
        override=float((anchor_pred!=final_pred).mean())
        closed.append({
            "view":view,"variant":variant,"seed":seed,"domain":domain,"n":len(frame),
            "mean_gate":float(pc["gate"].mean()),
            "std_gate":float(pc["gate"].std()),
            "perturbation_coverage":pc["perturbation_coverage"],
            "best_epoch":best_epoch,
            "best_source_val_macro_f1":best,
            "anchor_macro_f1":anchor_met["macro_f1"],
            "delta_macro_f1_vs_anchor":met["macro_f1"]-anchor_met["macro_f1"],
            "harm_rate_anchor_correct_final_wrong":harm,
            "rescue_rate_anchor_wrong_final_correct":rescue,
            "prediction_override_rate":override,
            **met
        })
    pd.DataFrame(closed).to_csv(run/"closed_metrics.csv",index=False)

    threshold,ood=f0.prepare_ood_cache(root,outroot,frames,v8)
    op=[]
    for domain,frame in frames.open_eval.items():
        ds=FailSafeDataset(f0,frame,eval_tf,tokenizer,text_col,view,False,False)
        pc=predict(model,loader(f0,ds,EVAL_BATCH_SIZE,False),device)
        y=f0.make_open_targets(frame); met=f0.open_metrics(y,pc["probs"],ood[domain],threshold)
        op.append({"view":view,"variant":variant,"seed":seed,"domain":domain,"n":len(frame),
                   "n_known":int((y!=f0.UNKNOWN_ID).sum()),"n_unknown":int((y==f0.UNKNOWN_ID).sum()),
                   "mean_gate":float(pc["gate"].mean()),
                   "std_gate":float(pc["gate"].std()),
                   "perturbation_coverage":pc["perturbation_coverage"],**met})
    pd.DataFrame(op).to_csv(run/"open_metrics.csv",index=False)

    jdump({"protocol":"01_failsafe_residual_v21","f0_script":f0_path,"table2":t2_path,"v8":v8_path,
           "anchor_checkpoint":anchor_path,"anchor":"PanDerm image-only F0-v3","anchor_frozen":True,
           "view":view,"text_col":text_col,"variant":variant,"seed":seed,
           "controlled_metadata_perturbations":[
               "exact frozen-text field-value masking; first available field",
               "exact frozen-text field-value masking; second available field"
           ],
           "loss":{
               "class_ce":1.0,
               "metadata_aux_ce":0.0 if variant=="full_failsafe_no_meta_aux" else LAMBDA_META,
               "safety_hinge":0.0 if variant in {"naive_concat","full_failsafe_no_safety"} else LAMBDA_SAFETY,
               "gate_penalty":0.0 if variant=="naive_concat" else LAMBDA_GATE
           },
           "reviewer_endpoints":[
               "delta Macro-F1 vs frozen PanDerm anchor",
               "harm rate: anchor correct -> final wrong",
               "rescue rate: anchor wrong -> final correct",
               "prediction override rate",
               "gate mean/std",
               "perturbation coverage"
           ],
           "selection":"PAD source_val Macro-F1 only","target_training":False,
           "openworld":"same frozen DermLIP-MCM q95 branch as F0"},run/"run_manifest.json")
    flag.write_text("complete\n",encoding="utf-8")
    del model,anchor,bundle,opt; cleanup()


def aggregate(root):
    base=root/"results_01_failsafe_residual_v21"
    for fn in ["closed_metrics.csv","open_metrics.csv"]:
        parts=list(base.glob(f"*/*/seed_*/{fn}"))
        if parts:
            df=pd.concat([pd.read_csv(p) for p in parts],ignore_index=True)
            df.to_csv(base/f"ALL_{fn}",index=False)
            nums=[c for c in df.columns if pd.api.types.is_numeric_dtype(df[c]) and c not in {"seed","n","n_known","n_unknown","best_epoch"}]
            keys=["view","variant","domain"]
            z=df.groupby(keys)[nums].agg(["mean","std"]).reset_index()
            z.columns=["_".join([str(x) for x in c if str(x)]) if isinstance(c,tuple) else str(c) for c in z.columns]
            z.to_csv(base/f"MEAN_STD_{fn}",index=False)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--root",type=Path,default=DEFAULT_ROOT)
    ap.add_argument("--views",default=",".join(VIEWS))
    ap.add_argument(
        "--primary-review",
        action="store_true",
        help="Reviewer-prioritized matrix: age, shared_robust, core, full. "
             "Location and missing-explicit remain available as diagnostics."
    )
    ap.add_argument("--variants",default=",".join(VARIANTS))
    ap.add_argument("--seeds",default="42,123,2026")
    ap.add_argument("--force",action="store_true")
    ap.add_argument("--export-predictions-only",action="store_true",help="Load completed best.pt checkpoints and export labeled development predictions; do not train.")
    ap.add_argument("--child-view",choices=VIEWS)
    ap.add_argument("--child-variant",choices=VARIANTS)
    ap.add_argument("--child-seed",type=int)
    args=ap.parse_args(); root=args.root.resolve()
    views=[x.strip() for x in args.views.split(",") if x.strip()]
    if args.primary_review:
        views=["age","shared_robust","core","full"]
    variants=[x.strip() for x in args.variants.split(",") if x.strip()]
    seeds=[int(x) for x in args.seeds.split(",") if x.strip()]
    if args.child_view:
        run_one(root,args.child_view,args.child_variant,args.child_seed,args.force,args.export_predictions_only); return

    # Preflight only reads source/dev files and verifies F0 image anchors.
    f0,p=import_f0(root); frames,t2,_=f0.load_study_frames(root,"development"); v8,_=f0.import_v8(root)
    for s in seeds:
        if not image_ckpt(root,s).exists(): raise FileNotFoundError(image_ckpt(root,s))
    jobs=[(v,a,s) for v in views for a in variants for s in seeds]
    base=root/"results_01_failsafe_residual_v21"; rem=[]; done=0
    for v,a,s in jobs:
        run_dir=base/v/a/f"seed_{s}"
        if args.export_predictions_only:
            if (run_dir/"RUN_COMPLETE.flag").exists() and (run_dir/"best.pt").exists(): rem.append((v,a,s))
            else: print(f"[01] incomplete or missing checkpoint; skipping export: {run_dir}")
        elif (run_dir/"RUN_COMPLETE.flag").exists() and not args.force: done+=1
        else: rem.append((v,a,s))
    print(f"[01] resume {done}/{len(jobs)} complete; {len(rem)} remaining")
    bar=tqdm(total=len(jobs),initial=done,desc="01 fail-safe runs",unit="run",dynamic_ncols=True)
    for v,a,s in rem:
        bar.set_postfix_str(f"{v}/{a}/s{s}")
        cmd=[sys.executable,str(Path(__file__).resolve()),"--root",str(root),
             "--child-view",v,"--child-variant",a,"--child-seed",str(s)]
        if args.force: cmd.append("--force")
        if args.export_predictions_only: cmd.append("--export-predictions-only")
        subprocess.check_call(cmd); bar.update(1)
    bar.close(); aggregate(root)


if __name__=="__main__":
    main()
