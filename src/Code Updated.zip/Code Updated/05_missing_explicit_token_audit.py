#!/usr/bin/env python
from __future__ import annotations

"""
05 — MISSING-EXPLICIT TOKEN / TRUNCATION DIAGNOSTIC
===================================================

Purpose
-------
This is a SMALL CPU-only diagnostic for the Script-04 anomaly where the
missing-explicit condition showed almost no prediction sensitivity despite its
metadata embedding being highly domain-identifying.

It tests two possible explanations without training anything:

1) RECONSTRUCTION MISMATCH
   Does the Script-04 reconstructed metadata sentence tokenize the same way as
   the frozen V2.1 text_missing_explicit / text_full column that F0 actually used?

2) TRUNCATION / FIELD VISIBILITY
   When one metadata field is changed/removed, does that change survive the same
   BioClinicalBERT MAX_TEXT_LEN=192 truncation used by F0?

Data protocol
-------------
Imports the already-run F0-v3 script and therefore uses the SAME:
  * OpenWorld V2.1 preprocessing
  * MIDAS V3.1 cohorts
  * frozen text columns
  * BioClinicalBERT tokenizer
  * F0 MAX_TEXT_LEN

No model is trained. No target-test data are read.
"""

import argparse
import importlib
import importlib.util
import json
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from transformers import AutoTokenizer
from tqdm.auto import tqdm


DEFAULT_ROOT = Path(r"C:\Users\Nebula PC\Downloads\Deep Learning")

FIELD_LABELS = [
    ("std_age", "age group"),
    ("std_sex", "sex"),
    ("std_location", "anatomical site"),
    ("std_diameter", "lesion diameter"),
    ("std_fitzpatrick", "Fitzpatrick type"),
    ("std_itch", "itching"),
    ("std_grew", "growth"),
    ("std_hurt", "pain"),
    ("std_changed", "change"),
    ("std_bleed", "bleeding"),
    ("std_elevation", "elevation"),
    ("std_personal_skin_cancer_history", "personal skin cancer history"),
    ("std_family_skin_cancer_history", "family skin cancer history"),
    ("std_general_cancer_history", "general cancer history"),
    ("std_smoking", "smoking"),
    ("std_alcohol", "alcohol"),
    ("std_pesticide_exposure", "pesticide exposure"),
    ("std_sunbed_use", "sunbed use"),
    ("std_organ_transplant", "organ transplant"),
    ("std_immunosuppression", "immunosuppression"),
    ("std_natural_hair_color", "natural hair color"),
    ("std_skin_reaction_to_sun", "skin reaction to sun"),
    ("std_moles_body_18", "moles on body at age 18"),
    ("std_moles_bigger_5mm", "moles larger than 5 mm"),
    ("std_moles_bigger_20cm", "moles field bigger 20 cm"),
    ("std_moles_body", "moles on body"),
    ("std_sunburn_number_group", "sunburn count group"),
]
FIELD_TO_LABEL = dict(FIELD_LABELS)
FULL_FIELDS = [f for f, _ in FIELD_LABELS]


def discover_f0(root: Path) -> Path:
    p = root / "run_f0_foundation_representation_sanity.py"
    if p.exists():
        return p
    hits = sorted(root.glob("run_f0_foundation_representation_sanity*.py"))
    if not hits:
        raise FileNotFoundError("F0-v3 script not found in project root.")
    return hits[0]


def import_f0(root: Path):
    p = discover_f0(root).resolve()
    if str(p.parent) not in sys.path:
        sys.path.insert(0, str(p.parent))
    if p.stem.isidentifier():
        importlib.invalidate_caches()
        m = importlib.import_module(p.stem)
    else:
        spec = importlib.util.spec_from_file_location("f0_v3_runtime_token_audit", p)
        if spec is None or spec.loader is None:
            raise RuntimeError(f"Could not import {p}")
        m = importlib.util.module_from_spec(spec)
        sys.modules["f0_v3_runtime_token_audit"] = m
        spec.loader.exec_module(m)
        if os.name == "nt":
            m.RUNTIME_NUM_WORKERS = 0
    return m, p


def is_missing(x) -> bool:
    if pd.isna(x):
        return True
    return str(x).strip().lower() in {"", "nan", "none", "null", "unknown", "n/a", "na"}


def clean_std(x) -> str:
    return "unknown" if is_missing(x) else str(x).strip().lower()


def build_text(row: pd.Series, fields, explicit_missing: bool) -> str:
    """
    This intentionally reproduces the reconstruction grammar used by Script 04.
    The point of this diagnostic is to compare it AGAINST the frozen V2.1 text.
    """
    parts = []
    for field in fields:
        val = clean_std(row.get(field, "unknown"))
        if val == "unknown" and not explicit_missing:
            continue
        if field == "std_age" and val != "unknown":
            val = f"{val} years"
        parts.append(f"{FIELD_TO_LABEL[field]}: {val}")
    return "Patient metadata unavailable." if not parts else "Patient metadata: " + "; ".join(parts) + "."


def token_ids(tokenizer, text: str, max_len=None):
    kwargs = dict(add_special_tokens=True)
    if max_len is None:
        kwargs["truncation"] = False
    else:
        kwargs.update(truncation=True, max_length=max_len)
    return tokenizer(str(text), **kwargs)["input_ids"]


def token_edit_distance(a, b):
    """Simple Levenshtein distance on token-id sequences; diagnostic only."""
    if len(a) < len(b):
        a, b = b, a
    prev = list(range(len(b) + 1))
    for i, x in enumerate(a, 1):
        cur = [i]
        for j, y in enumerate(b, 1):
            cur.append(min(
                cur[-1] + 1,
                prev[j] + 1,
                prev[j - 1] + (x != y),
            ))
        prev = cur
    return prev[-1]


def find_subsequence(seq, sub):
    if not sub or len(sub) > len(seq):
        return -1
    for i in range(len(seq) - len(sub) + 1):
        if seq[i:i+len(sub)] == sub:
            return i
    return -1


def get_frames(f0, root: Path):
    frames, _, _ = f0.load_study_frames(root, "development")
    out = {
        "PAD_source_train": frames.source_train,
        "PAD_source_val": frames.source_val,
    }
    for name, frame in frames.known_eval.items():
        out[name] = frame
    return out


def audit_view(tokenizer, f0, domain, frame, view, max_samples, seed):
    text_col = f0.TEXT_VARIANTS[view]
    explicit = (view == "missing_explicit")

    q = frame.reset_index(drop=True).copy()
    if len(q) > max_samples:
        q = q.sample(max_samples, random_state=seed).reset_index(drop=True)

    summary_raw = []
    field_rows = []

    for _, row in tqdm(
        q.iterrows(),
        total=len(q),
        desc=f"05 {view}/{domain}",
        leave=False,
        dynamic_ncols=True,
    ):
        frozen = f0.safe_text(row[text_col])
        recon = build_text(row, FULL_FIELDS, explicit)

        frozen_full = token_ids(tokenizer, frozen, None)
        recon_full = token_ids(tokenizer, recon, None)
        frozen_tr = token_ids(tokenizer, frozen, f0.MAX_TEXT_LEN)
        recon_tr = token_ids(tokenizer, recon, f0.MAX_TEXT_LEN)

        summary_raw.append({
            "domain": domain,
            "view": view,
            "raw_text_exact": int(frozen == recon),
            "truncated_tokens_exact": int(frozen_tr == recon_tr),
            "frozen_token_len_untruncated": len(frozen_full),
            "reconstructed_token_len_untruncated": len(recon_full),
            "frozen_would_truncate": int(len(frozen_full) > f0.MAX_TEXT_LEN),
            "reconstructed_would_truncate": int(len(recon_full) > f0.MAX_TEXT_LEN),
            "token_edit_distance_truncated": token_edit_distance(frozen_tr, recon_tr),
        })

        for field in FULL_FIELDS:
            if field not in q.columns:
                continue

            original_value = clean_std(row.get(field, "unknown"))

            # Reconstructed baseline vs one-field perturbation.
            perturbed = row.copy()
            perturbed[field] = "unknown"
            pert_text = build_text(perturbed, FULL_FIELDS, explicit)

            pert_full = token_ids(tokenizer, pert_text, None)
            pert_tr = token_ids(tokenizer, pert_text, f0.MAX_TEXT_LEN)

            # Locate the field label in the reconstructed untruncated sequence.
            # This tells us whether the field is physically before or after the
            # 192-token truncation boundary.
            label_ids = tokenizer(
                FIELD_TO_LABEL[field],
                add_special_tokens=False,
                truncation=False,
            )["input_ids"]
            start_pos = find_subsequence(recon_full, label_ids)
            field_label_visible = int(
                start_pos >= 0 and start_pos < max(f0.MAX_TEXT_LEN - 1, 1)
            )

            reconstructed_change_survives = int(recon_tr != pert_tr)
            frozen_vs_recon_equal = int(frozen_tr == recon_tr)
            frozen_vs_perturbed_equal = int(frozen_tr == pert_tr)

            field_rows.append({
                "domain": domain,
                "view": view,
                "field": field,
                "original_field_available": int(original_value != "unknown"),
                "field_label_start_token": start_pos,
                "field_label_before_truncation": field_label_visible,
                "reconstructed_perturbation_changes_truncated_tokens": reconstructed_change_survives,
                "frozen_equals_reconstructed_after_truncation": frozen_vs_recon_equal,
                "frozen_equals_perturbed_after_truncation": frozen_vs_perturbed_equal,
                "reconstructed_baseline_token_len": len(recon_full),
                "perturbed_token_len": len(pert_full),
                "reconstructed_vs_perturbed_token_edit_distance_truncated":
                    token_edit_distance(recon_tr, pert_tr),
            })

    return pd.DataFrame(summary_raw), pd.DataFrame(field_rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, default=DEFAULT_ROOT)
    ap.add_argument("--views", default="missing_explicit,full")
    ap.add_argument("--max-samples", type=int, default=300)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    root = args.root.resolve()
    f0, f0_path = import_f0(root)
    tokenizer = AutoTokenizer.from_pretrained(f0.BIOCLINICAL_MODEL)
    frames = get_frames(f0, root)

    views = [x.strip() for x in args.views.split(",") if x.strip()]
    for v in views:
        if v not in {"full", "missing_explicit"}:
            raise ValueError("This diagnostic is intentionally restricted to full/missing_explicit.")

    output = root / "results_05_missing_explicit_token_audit_v21"
    output.mkdir(parents=True, exist_ok=True)

    all_summary = []
    all_fields = []

    total = len(views) * len(frames)
    outer = tqdm(total=total, desc="05 token audit", unit="condition", dynamic_ncols=True)

    for view in views:
        for domain, frame in frames.items():
            outer.set_postfix_str(f"{view}/{domain}")
            s, f = audit_view(
                tokenizer, f0, domain, frame, view,
                args.max_samples, args.seed
            )
            all_summary.append(s)
            all_fields.append(f)
            outer.update(1)
    outer.close()

    raw = pd.concat(all_summary, ignore_index=True)
    fields = pd.concat(all_fields, ignore_index=True)

    raw.to_csv(output / "text_reconstruction_sample_audit.csv", index=False)
    fields.to_csv(output / "field_token_visibility_sample_audit.csv", index=False)

    summary = raw.groupby(["view", "domain"]).agg(
        n=("raw_text_exact", "size"),
        raw_text_exact_rate=("raw_text_exact", "mean"),
        truncated_tokens_exact_rate=("truncated_tokens_exact", "mean"),
        frozen_mean_untruncated_tokens=("frozen_token_len_untruncated", "mean"),
        recon_mean_untruncated_tokens=("reconstructed_token_len_untruncated", "mean"),
        frozen_truncation_rate=("frozen_would_truncate", "mean"),
        recon_truncation_rate=("reconstructed_would_truncate", "mean"),
        mean_frozen_recon_edit_distance=("token_edit_distance_truncated", "mean"),
    ).reset_index()
    summary.to_csv(output / "text_reconstruction_summary.csv", index=False)

    field_summary = fields.groupby(["view", "domain", "field"]).agg(
        n=("field", "size"),
        field_availability=("original_field_available", "mean"),
        field_label_before_truncation_rate=("field_label_before_truncation", "mean"),
        perturbation_visible_after_truncation_rate=(
            "reconstructed_perturbation_changes_truncated_tokens", "mean"
        ),
        frozen_reconstruction_exact_rate=(
            "frozen_equals_reconstructed_after_truncation", "mean"
        ),
        frozen_equals_perturbed_rate=(
            "frozen_equals_perturbed_after_truncation", "mean"
        ),
        mean_recon_perturb_edit_distance=(
            "reconstructed_vs_perturbed_token_edit_distance_truncated", "mean"
        ),
    ).reset_index()
    field_summary.to_csv(output / "field_token_visibility_summary.csv", index=False)

    manifest = {
        "protocol": "05_missing_explicit_token_audit_v21",
        "purpose": "diagnose Script-04 missing-explicit near-zero perturbation sensitivity",
        "f0_script": str(f0_path),
        "evaluation_mode": "development only",
        "views": views,
        "max_samples_per_domain": args.max_samples,
        "tokenizer": f0.BIOCLINICAL_MODEL,
        "max_text_len": int(f0.MAX_TEXT_LEN),
        "target_test_read": False,
        "no_model_training": True,
        "interpretation": {
            "low_truncated_tokens_exact_rate":
                "Script-04 reconstruction does not reproduce the frozen V2.1 text after tokenization.",
            "high_truncation_rate":
                "The frozen/reconstructed metadata sentence often exceeds F0's token limit.",
            "low_perturbation_visible_after_truncation_rate":
                "The changed field frequently does not alter the 192-token model input; perturbation sensitivity is not interpretable for that field.",
        },
    }
    (output / "audit_manifest.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8"
    )

    print("\n[05] TEXT RECONSTRUCTION SUMMARY")
    print(summary.to_string(index=False))
    print("\n[05] outputs ->", output)


if __name__ == "__main__":
    main()
