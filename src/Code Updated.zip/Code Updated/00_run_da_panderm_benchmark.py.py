#!/usr/bin/env python
from __future__ import annotations

"""
00 — PAN-DERM DOMAIN-ADAPTATION BENCHMARK ON FROZEN V2.1/V3.1 PREPROCESSING
===========================================================================

Reviewer-facing question
------------------------
Once PanDerm is the visual anchor, do classical/gradient-protected UDA methods
improve cross-dataset generalization, and does the answer depend on the exact
V2.1 metadata textualization?

THIS SCRIPT DOES NOT USE THE OLD V1/V5 PREPROCESSING.
It dynamically imports the already-run F0-v3 script and reuses its:
  * PAD source_train/source_val/source_test cache
  * OpenWorld V2.1 development/final-test cohorts
  * MIDAS V3.1 external cohorts
  * exact six metadata textualizations
  * PanDerm loader, transforms, normalization and F0 checkpoints
  * closed-set metrics
  * frozen DermLIP-MCM source-q95 open-world evaluation

UDA target inputs are physically label-stripped:
  preprocessed_outputs_openworld_v2_1_final/
      isic_target_adapt_ow_v2_1_model_unlabeled.csv
      mcr_target_adapt_ow_v2_1_model_unlabeled.csv

Methods
-------
continued_source
    Same continued optimization budget, source only. Essential control.

dann
    Standard marginal adversarial alignment.

cdan
    Conditional adversarial alignment using vec(feature outer softmax(class)).

shared_pcgrad_dann
    DANN with asymmetric PCGrad on SHARED feature parameters only. Classification
    head keeps classification gradients; domain head keeps domain gradients.

entropy_pcgrad_dann
    Same shared-PCGrad formulation but target domain loss is confidence weighted:
        w_t = 1 - H(p_t) / log(K)
    This is a predeclared uncertainty-aware extension, NOT tuned on target labels.

Experimental matrix
-------------------
PanDerm image-only + all six PanDerm+BioClinicalBERT F0 metadata views:
    age, location, shared_robust, core, full, missing_explicit
Seeds:
    42, 123, 2026
Targets:
    ISIC, MCR
Default evaluation mode:
    development (target validation only; locked target test remains untouched)

Checkpoint selection:
    PAD source_val Macro-F1 only.

Important
---------
Target adaptation rows contain known + unknown target samples, but the optimizer
never sees target class labels. The model-unlabeled CSVs do not contain them.
"""

import argparse
import contextlib
import gc
import io
import importlib
import importlib.util
import json
import math
import os
import random
import re
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Function
from torch.utils.data import DataLoader
from tqdm.auto import tqdm


DEFAULT_ROOT = Path(r"C:\Users\Nebula PC\Downloads\Deep Learning")
TARGETS = {
    "isic": ("ISIC 2019", "isic_target_adapt_ow_v2_1_model_unlabeled.csv"),
    "mcr": ("MCR-SL", "mcr_target_adapt_ow_v2_1_model_unlabeled.csv"),
}
METHODS = [
    "continued_source",
    "dann",
    "cdan",
    "shared_pcgrad_dann",
    "entropy_pcgrad_dann",
]
VIEWS = ["image", "age", "location", "shared_robust", "core", "full", "missing_explicit"]
SEEDS = [42, 123, 2026]

# Deliberately matched across all adaptation methods. This is continuation from a
# source-fine-tuned F0 checkpoint, so a conservative adaptation LR is used.
DA_LR = 5e-5
DA_WEIGHT_DECAY = 0.05
DA_EPOCHS = 15
EARLY_STOP_PATIENCE = 3
SCHEDULER_FACTOR = 0.5
SCHEDULER_PATIENCE = 3
DOMAIN_LOSS_WEIGHT = 0.005
GRL_MAX_LAMBDA = 1.0
BATCH_SIZE = 16
EVAL_BATCH_SIZE = 64
GRAD_CLIP = 3.0


def jdump(obj, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    def conv(x):
        if isinstance(x, Path):
            return str(x)
        if isinstance(x, (np.integer,)):
            return int(x)
        if isinstance(x, (np.floating,)):
            v = float(x)
            return None if not np.isfinite(v) else v
        if isinstance(x, np.ndarray):
            return x.tolist()
        if isinstance(x, dict):
            return {str(k): conv(v) for k, v in x.items()}
        if isinstance(x, (list, tuple)):
            return [conv(v) for v in x]
        return x
    path.write_text(json.dumps(conv(obj), indent=2), encoding="utf-8")


def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def cleanup_cuda():
    gc.collect()
    if torch.cuda.is_available():
        try:
            torch.cuda.synchronize()
        except Exception:
            pass
        torch.cuda.empty_cache()
        try:
            torch.cuda.ipc_collect()
        except Exception:
            pass


def discover_f0(root: Path) -> Path:
    preferred = root / "run_f0_foundation_representation_sanity.py"
    if preferred.exists():
        return preferred
    hits = sorted(root.glob("run_f0_foundation_representation_sanity*.py"))
    if not hits:
        raise FileNotFoundError(
            "F0-v3 script not found under ROOT. Put the already-run "
            "run_f0_foundation_representation_sanity.py in the project root."
        )
    return hits[0]


def import_f0(root: Path):
    path = discover_f0(root).resolve()
    parent = str(path.parent)
    if parent not in sys.path:
        sys.path.insert(0, parent)
    name = path.stem
    if name.isidentifier():
        importlib.invalidate_caches()
        mod = importlib.import_module(name)
    else:
        name = "f0_v3_runtime"
        spec = importlib.util.spec_from_file_location(name, path)
        if spec is None or spec.loader is None:
            raise RuntimeError(f"Could not import {path}")
        mod = importlib.util.module_from_spec(spec)
        sys.modules[name] = mod
        spec.loader.exec_module(mod)
        # Windows spawn cannot re-import a synthetic module name. Avoid worker crash.
        if os.name == "nt":
            mod.RUNTIME_NUM_WORKERS = 0
    return mod, path


def view_condition_name(view: str) -> str:
    if view == "image":
        return "image__panderm_base"
    return f"multimodal__panderm_base__{view}"


def f0_checkpoint(root: Path, view: str, seed: int) -> Path:
    return (
        root
        / "results_f0_backbone_metadata_benchmark"
        / "development"
        / "children"
        / view_condition_name(view)
        / f"seed_{seed}"
        / "best.pt"
    )


def load_target_adapt(f0, t2, root: Path, target_key: str) -> pd.DataFrame:
    dataset_name, filename = TARGETS[target_key]
    path = root / "preprocessed_outputs_openworld_v2_1_final" / filename
    if not path.exists():
        raise FileNotFoundError(path)
    q = pd.read_csv(path, low_memory=False)
    required = {"image_file", *f0.TEXT_VARIANTS.values()}
    missing = required - set(q.columns)
    if missing:
        raise RuntimeError(f"{path.name}: missing corrected V2.1 columns: {sorted(missing)}")
    # Strict leakage guard: model-unlabeled target input must not expose label-like fields.
    forbidden = [
        c for c in q.columns
        if any(tok in c.lower() for tok in (
            "label", "diagnos", "known_unknown", "unknown_type", "unknown_family",
            "ground_truth", "pathology", "histopath", "malignancy", "ontology_"
        ))
    ]
    if forbidden:
        raise RuntimeError(
            f"Target-adapt leakage guard failed for {path.name}; forbidden columns={forbidden}"
        )
    (resolved,) = f0._resolve_frame_paths(t2, [(dataset_name, q)])
    return resolved.reset_index(drop=True)



class GradReverse(Function):
    @staticmethod
    def forward(ctx, x, lambd: float):
        ctx.lambd = float(lambd)
        return x.view_as(x)

    @staticmethod
    def backward(ctx, grad_output):
        return -ctx.lambd * grad_output, None


class PanDermAdaptModel(nn.Module):
    """Wrap an exact F0 PanDerm source model and expose the shared representation."""
    def __init__(self, source_model: nn.Module, view: str, num_classes: int):
        super().__init__()
        self.source_model = source_model
        self.view = view
        self.num_classes = num_classes

        if view == "image":
            self.feature_dim = int(source_model.classifier.in_features)
        else:
            self.feature_dim = int(source_model.classifier.in_features)

    def shared_parameters(self):
        # Classification head is task-specific and intentionally excluded.
        cls_ids = {id(p) for p in self.source_model.classifier.parameters()}
        return [p for p in self.source_model.parameters() if p.requires_grad and id(p) not in cls_ids]

    def class_head_parameters(self):
        return [p for p in self.source_model.classifier.parameters() if p.requires_grad]

    def extract_features(self, pixel_values, input_ids=None, attention_mask=None):
        if self.view == "image":
            return self.source_model.encode(pixel_values)

        # Exact feature construction used by F0 ExternalTextMultimodalClassifier,
        # before dropout and the final classifier.
        zi = self.source_model.backbone
        zi = f0_global._encode_image_native(
            zi, self.source_model.image_feature_kind, pixel_values
        )
        tout = self.source_model.text_encoder(
            input_ids=input_ids, attention_mask=attention_mask
        )
        zt = getattr(tout, "pooler_output", None)
        if zt is None:
            zt = tout.last_hidden_state[:, 0]
        return torch.cat(
            [self.source_model.image_proj(zi), self.source_model.text_proj(zt)], dim=-1
        )

    def classify_features(self, features):
        if self.view == "image":
            return self.source_model.classifier(features)
        return self.source_model.classifier(self.source_model.dropout(features))

    def forward(self, pixel_values=None, input_ids=None, attention_mask=None, native_tokens=None):
        z = self.extract_features(pixel_values, input_ids, attention_mask)
        return self.classify_features(z)


class DomainAdapter(nn.Module):
    def __init__(self, base: PanDermAdaptModel, method: str, num_classes: int, dropout: float):
        super().__init__()
        self.base = base
        self.method = method
        self.num_classes = num_classes
        dom_in = base.feature_dim * num_classes if method == "cdan" else base.feature_dim
        hidden = min(max(base.feature_dim, 128), 512)
        self.domain_classifier = nn.Sequential(
            nn.Linear(dom_in, hidden),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, 2),
        )

    def shared_parameters(self):
        return self.base.shared_parameters()

    def class_head_parameters(self):
        return self.base.class_head_parameters()

    def domain_head_parameters(self):
        return [p for p in self.domain_classifier.parameters() if p.requires_grad]

    def feature_for_domain(self, z, class_logits):
        if self.method == "cdan":
            p = F.softmax(class_logits, dim=1)
            return torch.bmm(p.unsqueeze(2), z.unsqueeze(1)).flatten(1)
        return z

    def forward_adapt(self, pixel_values, input_ids=None, attention_mask=None, lambd=1.0):
        z = self.base.extract_features(pixel_values, input_ids, attention_mask)
        cls = self.base.classify_features(z)
        dfeat = self.feature_for_domain(z, cls)
        dom = self.domain_classifier(GradReverse.apply(dfeat, float(lambd)))
        return cls, dom, z

    def forward(self, pixel_values=None, input_ids=None, attention_mask=None, native_tokens=None):
        return self.base(pixel_values, input_ids, attention_mask)


def move_batch(batch, device):
    return {
        k: (v.to(device, non_blocking=torch.cuda.is_available()) if torch.is_tensor(v) else v)
        for k, v in batch.items()
    }


def crop_batch(batch, n):
    out = {}
    for k, v in batch.items():
        out[k] = v[:n] if torch.is_tensor(v) and v.ndim > 0 else v
    return out


def grl_schedule(step: int, total_steps: int) -> float:
    p = min(max(step / max(total_steps - 1, 1), 0.0), 1.0)
    return float(GRL_MAX_LAMBDA * (2.0 / (1.0 + math.exp(-10.0 * p)) - 1.0))


def normalized_entropy(logits: torch.Tensor) -> torch.Tensor:
    p = F.softmax(logits, dim=1).clamp_min(1e-8)
    h = -(p * p.log()).sum(dim=1)
    return h / math.log(logits.shape[1])


def weighted_target_domain_loss(target_domain_logits, target_class_logits):
    ce = F.cross_entropy(
        target_domain_logits,
        torch.ones(target_domain_logits.shape[0], dtype=torch.long, device=target_domain_logits.device),
        reduction="none",
    )
    w = (1.0 - normalized_entropy(target_class_logits).detach()).clamp(0.05, 1.0)
    return (w * ce).sum() / w.sum().clamp_min(1e-6), w.detach()


def _autograd_grads(loss, params, retain_graph):
    return torch.autograd.grad(
        loss, params, retain_graph=retain_graph, allow_unused=True
    )


def asymmetric_shared_pcgrad(
    class_loss,
    domain_loss,
    model: DomainAdapter,
):
    """
    Asymmetric PCGrad without per-batch CUDA->CPU synchronization:
      shared: class_grad + projected(domain_grad)
      class head: class_grad only
      domain head: domain_grad only

    Domain gradients already include GRL on the shared representation.
    Statistics are returned as CUDA scalar tensors and synchronized once per
    epoch by the caller.
    """
    shared = model.shared_parameters()
    class_head = model.class_head_parameters()
    domain_head = model.domain_head_parameters()

    gc = _autograd_grads(class_loss, shared + class_head, retain_graph=True)
    gd = _autograd_grads(domain_loss, shared + domain_head, retain_graph=False)

    n_shared = len(shared)
    gc_s = gc[:n_shared]
    gc_h = gc[n_shared:]
    gd_s = gd[:n_shared]
    gd_h = gd[n_shared:]

    device = class_loss.device
    dot = torch.zeros((), device=device)
    norm_c = torch.zeros((), device=device)
    norm_d = torch.zeros((), device=device)
    for a, b in zip(gc_s, gd_s):
        if a is not None:
            norm_c = norm_c + (a * a).sum()
        if b is not None:
            norm_d = norm_d + (b * b).sum()
        if a is not None and b is not None:
            dot = dot + (a * b).sum()

    conflict = (dot < 0.0) & (norm_c > 0.0)
    raw_scale = dot / norm_c.clamp_min(1e-12)
    scale = torch.where(conflict, raw_scale, torch.zeros_like(raw_scale))

    for p, a, b in zip(shared, gc_s, gd_s):
        ga = torch.zeros_like(p) if a is None else a
        gb = torch.zeros_like(p) if b is None else b
        # scale==0 for non-conflicting batches, so this is branch-free.
        gb = gb - scale * ga
        p.grad = (ga + gb).detach()

    for p, g in zip(class_head, gc_h):
        p.grad = None if g is None else g.detach()

    for p, g in zip(domain_head, gd_h):
        p.grad = None if g is None else g.detach()

    denom = torch.sqrt(norm_c.clamp_min(0.0) * norm_d.clamp_min(0.0))
    cosine = torch.where(
        denom > 0.0,
        dot / denom.clamp_min(1e-12),
        torch.full_like(dot, float("nan")),
    )
    return {
        "conflict": conflict.to(dtype=torch.float32),
        "shared_cosine": cosine,
        "projection_scale": scale.detach(),
    }


@torch.no_grad()
def evaluate_source_val(f0, model, loader, device):
    cache = f0.predict(model, loader, device)
    return f0.closed_metrics(cache["y_true"], cache["probs"])


def condition_and_source_model(f0, root, frames, t2, v8, view, seed, device):
    condition = f0.condition_map()[view_condition_name(view)]
    # Official PanDerm/F0 loaders print the entire ViT repeatedly. Capture stdout
    # during construction; stderr warnings/errors remain visible.
    print(f"[00-DA] loading {view_condition_name(view)} seed={seed} on {device} ...", flush=True)
    with contextlib.redirect_stdout(io.StringIO()):
        source_model, old_optimizer, train_tf, eval_tf, tokenizer, bundle, opt_audit = f0.build_condition_model(
            root, t2, v8, condition, seed, device, frames.source_train
        )
    del old_optimizer
    ckpt_path = f0_checkpoint(root, view, seed)
    if not ckpt_path.exists():
        raise FileNotFoundError(
            f"Missing F0 source checkpoint: {ckpt_path}\n"
            "Run the F0-v3 image/multimodal benchmark first."
        )
    payload = torch.load(ckpt_path, map_location=device)
    state = payload.get("state_dict", payload)
    source_model.load_state_dict(state, strict=True)
    return condition, source_model, train_tf, eval_tf, tokenizer, bundle, opt_audit, ckpt_path


def make_loader(f0, condition, frame, train_tf, eval_tf, tokenizer, training, return_label, batch_size):
    ds = f0.make_dataset(
        condition, frame, train_tf, eval_tf, tokenizer, training, return_label
    )
    kw = f0.loader_kwargs(batch_size, shuffle=training)
    # For target adaptation, full target batches are preferable; F0 helper already
    # uses drop_last=False, and we crop target to the source batch size.
    return DataLoader(ds, **kw)


def _assert_same_known_membership(known_frame: pd.DataFrame, open_frame: pd.DataFrame, y_open: np.ndarray, domain: str):
    """
    Safety check for evaluation reuse: F0 known_eval must equal the known subset
    of the corresponding open_eval cohort. If this is not true, fall back to
    separate closed evaluation rather than silently changing membership.
    """
    known_mask = (y_open != f0_global.UNKNOWN_ID)
    if int(known_mask.sum()) != len(known_frame):
        return False
    key = "image_path" if "image_path" in known_frame.columns and "image_path" in open_frame.columns else (
        "image_file" if "image_file" in known_frame.columns and "image_file" in open_frame.columns else None
    )
    if key is None:
        return True
    a = set(known_frame[key].astype(str).tolist())
    b = set(open_frame.loc[known_mask, key].astype(str).tolist())
    return a == b



def run_one(
    root: Path,
    target_key: str,
    method: str,
    view: str,
    seed: int,
    evaluation_mode: str,
    force: bool,
):
    out_root = root / "results_00_panderm_da_v21" / evaluation_mode
    run_dir = out_root / target_key / method / view / f"seed_{seed}"
    done = run_dir / "RUN_COMPLETE.flag"
    if done.exists() and not force:
        print(f"[00-DA] skip complete {target_key}/{method}/{view}/seed{seed}")
        return

    run_dir.mkdir(parents=True, exist_ok=True)
    f0, f0_path = import_f0(root)
    global f0_global
    f0_global = f0
    frames, t2, table2_path = f0.load_study_frames(root, evaluation_mode)
    v8, v8_path = f0.import_v8(root)
    needs_domain = method in {"dann", "cdan", "shared_pcgrad_dann", "entropy_pcgrad_dann"}
    target_adapt = load_target_adapt(f0, t2, root, target_key) if needs_domain else None

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    set_seed(seed)

    (
        condition, source_model, train_tf, eval_tf, tokenizer, bundle,
        opt_audit, source_ckpt
    ) = condition_and_source_model(f0, root, frames, t2, v8, view, seed, device)

    base = PanDermAdaptModel(source_model, view, len(f0.KNOWN_CLASSES)).to(device)
    model = (
        DomainAdapter(base, "cdan" if method == "cdan" else "dann",
                      len(f0.KNOWN_CLASSES), f0.DROPOUT).to(device)
        if needs_domain else base
    )

    source_train_loader = make_loader(
        f0, condition, frames.source_train, train_tf, eval_tf, tokenizer,
        True, True, BATCH_SIZE
    )
    source_val_loader = make_loader(
        f0, condition, frames.source_val, train_tf, eval_tf, tokenizer,
        False, True, EVAL_BATCH_SIZE
    )
    target_loader = None
    if needs_domain:
        target_loader = make_loader(
            f0, condition, target_adapt, train_tf, eval_tf, tokenizer,
            True, False, BATCH_SIZE
        )

    class_weights, class_counts = f0.effective_number_loss_weights(frames.source_train, device)
    class_criterion = nn.CrossEntropyLoss(weight=class_weights)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=DA_LR, weight_decay=DA_WEIGHT_DECAY
    )
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="max", factor=SCHEDULER_FACTOR, patience=SCHEDULER_PATIENCE
    )

    best_f1 = -1.0
    best_epoch = -1
    patience = 0
    best_path = run_dir / "best.pt"
    history = []
    total_steps = DA_EPOCHS * max(len(source_train_loader), 1)
    global_step = 0

    # Accumulate bookkeeping on-device and synchronize once per epoch. The
    # previous implementation called .cpu()/.item() several times per batch,
    # which serialized CUDA work and produced low utilization.
    epoch_bar = tqdm(
        range(1, DA_EPOCHS + 1),
        desc=f"00 {target_key}/{method}/{view}/s{seed}",
        unit="epoch", dynamic_ncols=True
    )
    for epoch in epoch_bar:
        model.train()
        target_iter = iter(target_loader) if target_loader is not None else None

        agg_loss = torch.zeros((), device=device)
        agg_cls = torch.zeros((), device=device)
        agg_dom = torch.zeros((), device=device)
        agg_n = 0
        agg_conflict = torch.zeros((), device=device)
        agg_cos_sum = torch.zeros((), device=device)
        agg_cos_n = torch.zeros((), device=device)
        agg_weight_sum = torch.zeros((), device=device)
        agg_weight_n = torch.zeros((), device=device)

        batch_bar = tqdm(
            source_train_loader,
            total=len(source_train_loader),
            desc=f"  train e{epoch:02d}",
            unit="batch",
            leave=False,
            dynamic_ncols=True,
        )
        for src in batch_bar:
            src = move_batch(src, device)
            optimizer.zero_grad(set_to_none=True)

            if method == "continued_source":
                logits = model(
                    src["pixel_values"], src.get("input_ids"), src.get("attention_mask")
                )
                class_loss = class_criterion(logits, src["label"])
                domain_loss = torch.zeros((), device=device)
                loss = class_loss
                loss.backward()
            else:
                try:
                    tgt = next(target_iter)
                except StopIteration:
                    target_iter = iter(target_loader)
                    tgt = next(target_iter)
                tgt = crop_batch(move_batch(tgt, device), int(src["label"].shape[0]))

                lambd = grl_schedule(global_step, total_steps)
                src_cls, src_dom, _ = model.forward_adapt(
                    src["pixel_values"], src.get("input_ids"), src.get("attention_mask"), lambd
                )
                tgt_cls, tgt_dom, _ = model.forward_adapt(
                    tgt["pixel_values"], tgt.get("input_ids"), tgt.get("attention_mask"), lambd
                )
                class_loss = class_criterion(src_cls, src["label"])
                src_dom_loss = F.cross_entropy(
                    src_dom, torch.zeros(src_dom.shape[0], dtype=torch.long, device=device)
                )

                if method == "entropy_pcgrad_dann":
                    tgt_dom_loss, w = weighted_target_domain_loss(tgt_dom, tgt_cls)
                    agg_weight_sum = agg_weight_sum + w.mean()
                    agg_weight_n = agg_weight_n + 1.0
                else:
                    tgt_dom_loss = F.cross_entropy(
                        tgt_dom, torch.ones(tgt_dom.shape[0], dtype=torch.long, device=device)
                    )

                domain_loss = 0.5 * (src_dom_loss + tgt_dom_loss)
                weighted_domain = DOMAIN_LOSS_WEIGHT * domain_loss
                loss = class_loss + weighted_domain

                if method in {"shared_pcgrad_dann", "entropy_pcgrad_dann"}:
                    stats = asymmetric_shared_pcgrad(class_loss, weighted_domain, model)
                    agg_conflict = agg_conflict + stats["conflict"]
                    finite_cos = torch.isfinite(stats["shared_cosine"])
                    agg_cos_sum = agg_cos_sum + torch.where(
                        finite_cos, stats["shared_cosine"], torch.zeros_like(stats["shared_cosine"])
                    )
                    agg_cos_n = agg_cos_n + finite_cos.to(dtype=torch.float32)
                else:
                    loss.backward()

            torch.nn.utils.clip_grad_norm_(model.parameters(), GRAD_CLIP)
            optimizer.step()

            bs = int(src["label"].shape[0])
            # Keep metric accumulation on CUDA; one synchronization occurs below.
            agg_loss = agg_loss + loss.detach() * bs
            agg_cls = agg_cls + class_loss.detach() * bs
            agg_dom = agg_dom + domain_loss.detach() * bs
            agg_n += bs
            global_step += 1

        # One compact synchronization for the training statistics.
        stat_tensor = torch.stack([
            agg_loss,
            agg_cls,
            agg_dom,
            agg_conflict,
            agg_cos_sum,
            agg_cos_n,
            agg_weight_sum,
            agg_weight_n,
        ]).detach().cpu()
        (
            loss_sum, cls_sum, dom_sum, conflict_sum,
            cos_sum, cos_n, weight_sum, weight_n
        ) = [float(x) for x in stat_tensor]

        vm = evaluate_source_val(f0, model, source_val_loader, device)
        val_f1 = vm["macro_f1"]
        scheduler.step(val_f1)
        improved = val_f1 > best_f1 + 1e-12
        if improved:
            best_f1, best_epoch, patience = val_f1, epoch, 0
            torch.save({
                "protocol": "00_panderm_da_v21",
                "target": target_key,
                "method": method,
                "view": view,
                "seed": seed,
                "epoch": epoch,
                "best_source_val_macro_f1": best_f1,
                "state_dict": model.state_dict(),
            }, best_path)
        else:
            patience += 1

        mean_cos = (cos_sum / cos_n) if cos_n > 0 else np.nan
        mean_weight = (weight_sum / weight_n) if weight_n > 0 else np.nan
        history.append({
            "epoch": epoch,
            "train_loss": loss_sum/max(agg_n,1),
            "class_loss": cls_sum/max(agg_n,1),
            "domain_loss": dom_sum/max(agg_n,1),
            "source_val_macro_f1": val_f1,
            "source_val_balanced_accuracy": vm["balanced_accuracy"],
            "pcgrad_conflicts": int(round(conflict_sum)),
            "pcgrad_mean_shared_cosine": mean_cos,
            "target_mean_confidence_weight": mean_weight,
            "lr": min(float(g["lr"]) for g in optimizer.param_groups),
            "improved": improved,
            "patience": patience,
        })
        epoch_bar.set_postfix(
            val_f1=f"{val_f1:.3f}",
            best=f"{best_f1:.3f}",
            patience=patience,
            refresh=False,
        )
        if patience >= EARLY_STOP_PATIENCE:
            break
    epoch_bar.close()

    pd.DataFrame(history).to_csv(run_dir / "history.csv", index=False)
    payload = torch.load(best_path, map_location=device)
    model.load_state_dict(payload["state_dict"], strict=True)

    # Evaluation optimization:
    # For the four external domains, open_eval contains the known cohort plus
    # unknowns. Predict it once, derive closed metrics from its known subset when
    # membership exactly matches known_eval, and use the same probabilities for
    # open-world metrics. PAD source-test remains a separate closed evaluation.
    closed_rows = []
    open_rows = []

    # PAD source-test (and any future known-only cohort with no open counterpart).
    evaluated_closed_domains = set()

    ood_threshold, ood_scores = f0.prepare_ood_cache(root, out_root, frames, v8)

    eval_bar = tqdm(
        list(frames.open_eval.items()),
        desc="  external eval",
        unit="domain",
        leave=False,
        dynamic_ncols=True,
    )
    for domain, frame in eval_bar:
        loader = make_loader(
            f0, condition, frame, train_tf, eval_tf, tokenizer,
            False, False, EVAL_BATCH_SIZE
        )
        cache = f0.predict(model, loader, device)
        y_open = f0.make_open_targets(frame)

        open_met = f0.open_metrics(
            y_open, cache["probs"], ood_scores[domain], ood_threshold
        )
        open_rows.append({
            "target_adaptation_domain": (target_key if needs_domain else "none"),
            "method": method,
            "view": view,
            "seed": seed,
            "domain": domain,
            "n": len(frame),
            "n_known": int((y_open != f0.UNKNOWN_ID).sum()),
            "n_unknown": int((y_open == f0.UNKNOWN_ID).sum()),
            "ood_threshold_source_val_q95": ood_threshold,
            **open_met,
        })

        if domain in frames.known_eval and _assert_same_known_membership(
            frames.known_eval[domain], frame, y_open, domain
        ):
            mask = (y_open != f0.UNKNOWN_ID)
            closed_met = f0.closed_metrics(y_open[mask], cache["probs"][mask])
            closed_rows.append({
                "target_adaptation_domain": (target_key if needs_domain else "none"),
                "method": method,
                "view": view,
                "seed": seed,
                "domain": domain,
                "n": int(mask.sum()),
                "best_epoch": best_epoch,
                "best_source_val_macro_f1": best_f1,
                **closed_met,
            })
            evaluated_closed_domains.add(domain)

    # Evaluate any known cohort that could not be safely reused (normally only
    # PAD_source_test; also serves as a conservative fallback if membership differs).
    remaining_known = [
        (domain, frame) for domain, frame in frames.known_eval.items()
        if domain not in evaluated_closed_domains
    ]
    known_bar = tqdm(
        remaining_known,
        desc="  known-only eval",
        unit="domain",
        leave=False,
        dynamic_ncols=True,
    )
    for domain, frame in known_bar:
        loader = make_loader(
            f0, condition, frame, train_tf, eval_tf, tokenizer,
            False, True, EVAL_BATCH_SIZE
        )
        cache = f0.predict(model, loader, device)
        met = f0.closed_metrics(cache["y_true"], cache["probs"])
        closed_rows.append({
            "target_adaptation_domain": (target_key if needs_domain else "none"),
            "method": method,
            "view": view,
            "seed": seed,
            "domain": domain,
            "n": len(frame),
            "best_epoch": best_epoch,
            "best_source_val_macro_f1": best_f1,
            **met,
        })

    pd.DataFrame(closed_rows).to_csv(run_dir / "closed_metrics.csv", index=False)
    pd.DataFrame(open_rows).to_csv(run_dir / "open_metrics.csv", index=False)

    jdump({
        "protocol": "00_panderm_da_v21",
        "f0_script": f0_path,
        "table2_loader": table2_path,
        "v8_loader": v8_path,
        "source_checkpoint": source_ckpt,
        "source_checkpoint_selection": "PAD source_val Macro-F1 only",
        "target_adapt_file": (
            root / "preprocessed_outputs_openworld_v2_1_final" / TARGETS[target_key][1]
            if needs_domain else None
        ),
        "target_labels_available_to_optimizer": False,
        "target_adapt_rows": (len(target_adapt) if target_adapt is not None else 0),
        "evaluation_mode": evaluation_mode,
        "condition": condition.__dict__,
        "method": method,
        "view": view,
        "seed": seed,
        "optimizer": {"name": "AdamW", "lr": DA_LR, "weight_decay": DA_WEIGHT_DECAY},
        "domain_loss_weight": DOMAIN_LOSS_WEIGHT,
        "grl_schedule": "2/(1+exp(-10p))-1",
        "pcgrad": (
            "asymmetric projection of conflicting domain gradient on shared parameters only"
            if "pcgrad" in method else None
        ),
        "entropy_weight": (
            "1 - H(p_target)/log(K), detached, clipped [0.05,1]"
            if method == "entropy_pcgrad_dann" else None
        ),
        "source_train_class_counts": class_counts.tolist(),
        "open_world": "same frozen DermLIP-MCM source_val q95 branch as F0-v3",
        "execution_optimizations": [
            "quiet stdout during model construction",
            "batch-level tqdm",
            "GPU-resident epoch statistic accumulation",
            "branch-free PCGrad conflict bookkeeping with epoch-level synchronization",
            "single-pass external open/known evaluation when cohort membership matches exactly",
        ],
        "locked_target_test_guard": evaluation_mode != "final_test",
    }, run_dir / "run_manifest.json")

    done.write_text("complete\n", encoding="utf-8")
    del model, optimizer, source_model, bundle
    cleanup_cuda()


def aggregate(root: Path, evaluation_mode: str):
    base = root / "results_00_panderm_da_v21" / evaluation_mode
    for fname in ["closed_metrics.csv", "open_metrics.csv"]:
        parts = list(base.glob(f"*/*/*/seed_*/{fname}"))
        if parts:
            df = pd.concat([pd.read_csv(p) for p in parts], ignore_index=True)
            df.to_csv(base / f"ALL_{fname}", index=False)
            metric_cols = [
                c for c in df.columns
                if c not in {
                    "target_adaptation_domain","method","view","seed","domain",
                    "n","n_known","n_unknown","best_epoch"
                } and pd.api.types.is_numeric_dtype(df[c])
            ]
            if metric_cols:
                keys = ["target_adaptation_domain","method","view","domain"]
                agg = df.groupby(keys)[metric_cols].agg(["mean","std"]).reset_index()
                agg.columns = [
                    "_".join([str(x) for x in col if str(x)])
                    if isinstance(col, tuple) else str(col)
                    for col in agg.columns
                ]
                agg.to_csv(base / f"MEAN_STD_{fname}", index=False)


def preflight(root: Path, targets: List[str], views: List[str], seeds: List[int], evaluation_mode: str):
    f0, f0_path = import_f0(root)
    frames, t2, table2_path = f0.load_study_frames(root, evaluation_mode)
    v8, v8_path = f0.import_v8(root)
    rows = []
    for target in targets:
        q = load_target_adapt(f0, t2, root, target)
        rows.append({"target": target, "adapt_rows": len(q)})
    missing = []
    for view in views:
        for seed in seeds:
            p = f0_checkpoint(root, view, seed)
            if not p.exists():
                missing.append(str(p))
    if missing:
        raise FileNotFoundError("Missing F0 checkpoints:\n" + "\n".join(missing[:30]))
    print("[00-DA] PRE-FLIGHT PASS")
    print(f"F0: {f0_path}")
    print(f"Table2: {table2_path}")
    print(f"V8: {v8_path}")
    print(pd.DataFrame(rows).to_string(index=False))
    print(f"Views={views}")
    print(f"Seeds={seeds}")
    print("Target adaptation files are label-stripped and V2.1-only.")


def parse_csv_arg(x: str):
    return [z.strip() for z in x.split(",") if z.strip()]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, default=DEFAULT_ROOT)
    ap.add_argument("--evaluation-mode", choices=["development","final_test"], default="development")
    ap.add_argument("--confirm-method-frozen", action="store_true")
    ap.add_argument("--targets", default="isic,mcr")
    ap.add_argument("--methods", default=",".join(METHODS))
    ap.add_argument("--views", default=",".join(VIEWS))
    ap.add_argument("--seeds", default="42,123,2026")
    ap.add_argument("--preflight-only", action="store_true")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--child-target", choices=list(TARGETS))
    ap.add_argument("--child-method", choices=METHODS)
    ap.add_argument("--child-view", choices=VIEWS)
    ap.add_argument("--child-seed", type=int)
    args = ap.parse_args()

    root = args.root.resolve()
    if args.evaluation_mode == "final_test" and not args.confirm_method_frozen:
        raise RuntimeError(
            "Refusing target-test evaluation during method development. "
            "Use --confirm-method-frozen only after the complete method set is frozen."
        )

    targets = parse_csv_arg(args.targets)
    methods = parse_csv_arg(args.methods)
    views = parse_csv_arg(args.views)
    seeds = [int(x) for x in parse_csv_arg(args.seeds)]
    for x in targets:
        if x not in TARGETS: raise ValueError(f"Unknown target {x}")
    for x in methods:
        if x not in METHODS: raise ValueError(f"Unknown method {x}")
    for x in views:
        if x not in VIEWS: raise ValueError(f"Unknown view {x}")

    if args.child_target:
        if args.child_method is None or args.child_view is None or args.child_seed is None:
            raise ValueError("child target/method/view/seed must be supplied together")
        run_one(
            root, args.child_target, args.child_method, args.child_view,
            args.child_seed, args.evaluation_mode, args.force
        )
        return

    preflight(root, targets, views, seeds, args.evaluation_mode)
    if args.preflight_only:
        return

    jobs = []
    for m in methods:
        method_targets = [targets[0]] if m == "continued_source" else targets
        jobs.extend((t,m,v,s) for t in method_targets for v in views for s in seeds)
    out_root = root / "results_00_panderm_da_v21" / args.evaluation_mode
    remaining = []
    done_n = 0
    for t,m,v,s in jobs:
        flag = out_root / t / m / v / f"seed_{s}" / "RUN_COMPLETE.flag"
        if flag.exists() and not args.force:
            done_n += 1
        else:
            remaining.append((t,m,v,s))
    print(f"[00-DA] resume: {done_n}/{len(jobs)} complete; {len(remaining)} remaining")

    bar = tqdm(total=len(jobs), initial=done_n, desc="00 PanDerm DA runs", unit="run", dynamic_ncols=True)
    for t,m,v,s in remaining:
        bar.set_postfix_str(f"{t}/{m}/{v}/s{s}")
        cmd = [
            sys.executable, str(Path(__file__).resolve()),
            "--root", str(root),
            "--evaluation-mode", args.evaluation_mode,
            "--child-target", t,
            "--child-method", m,
            "--child-view", v,
            "--child-seed", str(s),
        ]
        if args.evaluation_mode == "final_test":
            cmd.append("--confirm-method-frozen")
        if args.force:
            cmd.append("--force")
        subprocess.check_call(cmd)
        bar.update(1)
    bar.close()
    aggregate(root, args.evaluation_mode)


if __name__ == "__main__":
    main()
