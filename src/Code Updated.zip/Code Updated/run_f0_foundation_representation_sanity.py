#!/usr/bin/env python
"""
F0 v3 — BACKBONE × METADATA GENERALIZATION BENCHMARK
=====================================================

Reviewer-facing purpose
-----------------------
This is NOT a generic model leaderboard. It asks how clinical metadata behaves
when each pretrained architecture is used according to its actual modality
capabilities, under the same PAD-UFES source-only development protocol.

A) IMAGE-ONLY REPRESENTATION CONTROL
   Fully fine-tune six pretrained image encoders on PAD-UFES source_train:
       PanDerm Base, MONET, DINOv2-B/14, BiomedCLIP, DermLIP-B/16, MobileViT.
   No text is supplied. This isolates visual representation quality.

B) METADATA-ONLY CONTROL
   The same six frozen V2.1 textualizations are evaluated without image input:
       text_age_only
       text_location_only
       text_shared_robust          (age + location)
       text_core                   (age + sex + location)
       text_full                   (heterogeneous full schema)
       text_missing_explicit       (explicit-missingness stress test)

   Text encoders are CAPABILITY AWARE:
     - MONET, BiomedCLIP, DermLIP -> their OWN released native text encoders.
     - PanDerm, DINOv2, MobileViT have no native text tower -> one shared
       BioClinicalBERT text-only baseline is used rather than duplicating the
       exact same BioClinicalBERT run three times.

C) MULTIMODAL CONTROL
   Every image backbone receives the same textualized metadata view, but the
   text path respects what the architecture natively provides:
     - MONET / BiomedCLIP / DermLIP:
         native image tower + native text tower; no BioClinicalBERT inserted.
         Their aligned image/text embeddings are unit-normalized and averaged
         in the native shared space before the source-trained classifier head.
     - PanDerm / DINOv2:
         image backbone + fully fine-tuned BioClinicalBERT, with a simple
         projected-concatenation fusion head.
     - MobileViT:
         established MobileViT + BioClinicalBERT cross-attention implementation
         from Table 2, preserving the study's original multimodal model.

This decomposition lets us distinguish:
    visual representation quality
    vs metadata-only signal
    vs native/external text-encoder behavior
    vs multimodal fusion interaction.

The metadata question therefore remains CENTRAL rather than being replaced by a
backbone leaderboard. text_core/text_full/text_missing_explicit remain explicit
experimental conditions.

Training / selection
--------------------
- PAD-UFES source_train: ALL gradient updates.
- PAD-UFES source_val: checkpoint selection, LR scheduling, early stopping.
- No target labels affect training, checkpoint selection, scheduler, thresholds,
  prompt choice, hyperparameters, or preprocessing.
- Seeds: 42, 123, 2026.
- Effective-number weighted CE with the frozen beta.
- Strong-no-blur augmentation for image-containing models.
- Pretrained initialization is retained; all relevant encoders are trainable.

Evaluation modes
----------------
DEFAULT = development
    ISIC target_val_ow and MCR target_val_ow are used for diagnostics only.

FINAL TEST = guarded
    --evaluation-mode final_test --confirm-method-frozen

The guard is intentional.  Running many candidate backbones/metadata variants on
locked target-test labels and then choosing among them would convert the test set
into a model-selection set.  Use final_test only after the method/condition set
is frozen.  The script records this choice in the manifest.

MIDAS note
----------
The PAD-source setup has modality-specific MIDAS external cohorts rather than an
ISIC-style target_val/target_test partition.  Therefore MIDAS is always reported
as an external cohort (6-inch and dermoscopy), not mislabeled as a held-out
"target test" split.  Both known-only and semantic-open-world cohorts are used.

Metrics (CVPR/reviewer-oriented)
--------------------------------
1) CLOSED-SET KNOWN-CLASS CLASSIFICATION (primary backbone/metadata comparison)
   Primary:
     - Macro-F1
     - Balanced Accuracy
   Secondary:
     - Accuracy
     - Macro AUROC (OvR; when all six classes are present)
     - Macro Precision / Macro Recall
     - Per-class F1 / precision / recall / support

   Macro-F1 and Balanced Accuracy are primary because the six-class problem is
   highly imbalanced (especially PAD melanoma).

2) INTEGRATED OPEN-WORLD SYSTEM (secondary end-to-end evaluation)
   A single frozen OOD branch is shared across ALL classifiers:
       DermLIP-B/16 + clinical class prompts + MCM
       threshold = PAD source_val q95(MCM)
   This keeps OOD detection decoupled from known-class classifier selection.

   Primary integrated metrics:
     - Open Macro-F1
     - HOS = harmonic mean(OS*, unknown recall)
   Diagnostic/supporting:
     - OS* (known-class macro recall after rejection)
     - Unknown Recall
     - OSCR-AUC using the frozen DermLIP-MCM knownness score
     - OOD AUROC
     - AUPR-OUT / AUPR-IN
     - FPR95
     - Known False-Rejection Rate

   OSCR is useful here as a threshold-free *integrated recognition* diagnostic,
   but it is not used for training/model selection.  OOD AUROC/AUPR/FPR95 assess
   the rejector itself; Open Macro-F1/HOS assess the actual deployed operating
   point.

DermLIP contamination caveat
----------------------------
DermLIP/Derm1M has a known public-data overlap risk with ISIC.  The script marks
DermLIP backbone and DermLIP-MCM ISIC results as overlap-risk evidence.  Do not
present those ISIC values as a contamination-free DG estimate.

Recommended commands
--------------------
Preflight only:
    python run_f0_foundation_representation_sanity.py --preflight-only

Development benchmark (recommended while methods are still being compared):
    python run_f0_foundation_representation_sanity.py

Run only selected condition families:
    python run_f0_foundation_representation_sanity.py --families image
    python run_f0_foundation_representation_sanity.py --families metadata
    python run_f0_foundation_representation_sanity.py --families multimodal

Guarded final-test evaluation AFTER the condition/model set is frozen:
    python run_f0_foundation_representation_sanity.py \
        --evaluation-mode final_test --confirm-method-frozen

Outputs
-------
results_f0_backbone_metadata_benchmark/<evaluation_mode>/
    f0_closed_metrics_all.csv
    f0_closed_mean_std.csv
    f0_open_metrics_all.csv
    f0_open_mean_std.csv
    f0_per_class_metrics_all.csv
    f0_condition_summary.csv
    f0_manifest.json
    ood_cache/...
    children/<condition>/seed_<seed>/...
"""

from __future__ import annotations

import argparse
import gc
import hashlib
import importlib.util
import inspect
import json
import math
import os
import random
import re
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple
from tqdm.auto import tqdm

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from PIL import Image
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    balanced_accuracy_score,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms
from torchvision.transforms import InterpolationMode
from transformers import AutoModel, AutoTokenizer


# =============================================================================
# FROZEN STUDY CONSTANTS
# =============================================================================

DEFAULT_ROOT = Path(r"C:\Users\Nebula PC\Downloads\Deep Learning")
KNOWN_CLASSES = ["AK", "BCC", "MEL", "NEV", "SCC", "SK"]
LABEL_TO_ID = {c: i for i, c in enumerate(KNOWN_CLASSES)}
UNKNOWN_ID = len(KNOWN_CLASSES)
SEEDS = [42, 123, 2026]

TEXT_VARIANTS = {
    "age": "text_age_only",
    "location": "text_location_only",
    "shared_robust": "text_shared_robust",
    "core": "text_core",
    "full": "text_full",
    "missing_explicit": "text_missing_explicit",
}

IMAGE_MODELS = [
    "panderm_base",
    "monet",
    "dinov2_vitb14",
    "biomedclip",
    "dermlip_vitb16",
    "mobilevit",
]

# Models that are intrinsically image-text VLMs. For these models, metadata text
# is processed by the model's OWN released text encoder; BioClinicalBERT is not
# inserted between the metadata and the VLM.
NATIVE_VLM_MODELS = {"monet", "biomedclip", "dermlip_vitb16"}

# Models without a native text tower. Whenever these models participate in a
# multimodal condition, BioClinicalBERT is the external metadata encoder.
EXTERNAL_TEXT_MODELS = {"panderm_base", "dinov2_vitb14", "mobilevit"}

FAMILIES = ["image", "metadata", "multimodal"]

# Shared source protocol.
IMAGE_SIZE = 224
BATCH_SIZE = 16
EVAL_BATCH_SIZE = 64
NUM_WORKERS = 4
# May be reduced to 0 on Windows only when the discovered V8 loader file cannot
# be imported by a normal module name. This avoids multiprocessing-spawn pickle
# failures for transform wrapper classes while preserving multi-worker loading
# for the normal/canonical V8 filename.
RUNTIME_NUM_WORKERS = NUM_WORKERS
V8_IMPORT_MODE = "uninitialized"
PERSISTENT_WORKERS = True
PREFETCH_FACTOR = 2
PIN_MEMORY = True
MAX_EPOCHS = 50
EARLY_STOP_PATIENCE = 8
SCHEDULER_FACTOR = 0.5
SCHEDULER_PATIENCE = 3
BALANCE_BETA = 0.9596031602585381
GRAD_CLIP_NORM = 3.0
USE_AMP = True
MAX_TEXT_LEN = 192

# Frozen Table-2 MobileViT/BioClinicalBERT settings.
MOBILEVIT_LR = 6e-5
MOBILEVIT_WD = 5.829384542994739e-04
FUSION_DIM = 128
NUM_HEADS = 4
DROPOUT = 0.1353970008207678
BIOCLINICAL_MODEL = "emilyalsentzer/Bio_ClinicalBERT"

# Image-foundation full-finetuning recipes.  Training/selection/data/loss are
# identical; only model-appropriate optimizer scales and normalization differ.
# VLM visual encoders use one conservative predeclared scale to avoid target-HPO.
MODEL_RECIPES = {
    "dinov2_vitb14": dict(backbone_lr=1e-5, head_lr=1e-4, layer_decay=0.75, weight_decay=0.05),
    "panderm_base": dict(backbone_lr=5e-4, head_lr=5e-4, layer_decay=0.65, weight_decay=0.05),
    "monet": dict(backbone_lr=1e-5, head_lr=1e-4, layer_decay=0.75, weight_decay=0.05),
    "biomedclip": dict(backbone_lr=1e-5, head_lr=1e-4, layer_decay=0.75, weight_decay=0.05),
    "dermlip_vitb16": dict(backbone_lr=1e-5, head_lr=1e-4, layer_decay=0.75, weight_decay=0.05),
    "mobilevit": dict(backbone_lr=MOBILEVIT_LR, head_lr=MOBILEVIT_LR, layer_decay=1.0, weight_decay=MOBILEVIT_WD),
}

# Common OOD branch fixed from the earlier semantic-OOD study.
OOD_MODEL = "dermlip_vitb16"
OOD_PROMPT_TEMPLATE = "This is a skin image of {}"
OOD_CLASS_DISPLAY = {
    "AK": "actinic keratosis",
    "BCC": "basal cell carcinoma",
    "MEL": "melanoma",
    "NEV": "nevus",
    "SCC": "squamous cell carcinoma",
    "SK": "seborrheic keratosis",
}
OOD_QUANTILE = 0.95


# =============================================================================
# GENERIC UTILITIES
# =============================================================================

def jdump(obj, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)

    def conv(x):
        if isinstance(x, Path):
            return str(x)
        if isinstance(x, (np.integer,)):
            return int(x)
        if isinstance(x, (np.floating,)):
            x = float(x)
            return None if not np.isfinite(x) else x
        if isinstance(x, np.ndarray):
            return x.tolist()
        if isinstance(x, dict):
            return {str(k): conv(v) for k, v in x.items()}
        if isinstance(x, (list, tuple)):
            return [conv(v) for v in x]
        return x

    path.write_text(json.dumps(conv(obj), indent=2), encoding="utf-8")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def import_from_path(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not import {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    try:
        spec.loader.exec_module(module)
    except Exception:
        sys.modules.pop(name, None)
        raise
    return module


def discover_script(root: Path, preferred: List[Path], glob_pattern: str) -> Path:
    for p in preferred:
        if p.exists():
            return p
    hits = sorted(root.glob(glob_pattern))
    if hits:
        return hits[0]
    raise FileNotFoundError(f"Required script not found. tried={preferred}; glob={glob_pattern}")


def find_table2_script(root: Path) -> Path:
    return discover_script(
        root,
        [
            root / "04_table2_metadata_contribution_ablation.py",
            root / "research_protocol_1_to_4" / "04_table2_metadata_contribution_ablation.py",
        ],
        "**/04_table2_metadata_contribution_ablation.py",
    )


def find_v8_script(root: Path) -> Path:
    return discover_script(
        root,
        [
            root / "run_v8_2_2_pretrained_representation_benchmark.py",
            root / "run_v8_2_2_pretrained_representation_benchmark(4).py",
            root / "run_v8_2_2_pretrained_representation_benchmark(2).py",
        ],
        "run_v8_2_2_pretrained_representation_benchmark*.py",
    )


def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def cleanup_cuda():
    """Best-effort in-process cleanup; child-process exit remains the hard CUDA reset."""
    gc.collect()
    if torch.cuda.is_available():
        try:
            torch.cuda.synchronize()
        except Exception:
            pass
        torch.cuda.empty_cache()
        try:
            torch.cuda.ipc_collect()
        except Exception:
            pass


def as_bool(series: pd.Series) -> pd.Series:
    if pd.api.types.is_bool_dtype(series):
        return series.fillna(False)
    return series.astype(str).str.strip().str.lower().isin({"true", "1", "yes", "y"})


def safe_text(x) -> str:
    if pd.isna(x):
        return "Patient metadata unavailable."
    s = str(x).strip()
    return s if s else "Patient metadata unavailable."


def ensure_known_label_ids(df: pd.DataFrame, name: str) -> pd.DataFrame:
    q = df.copy().reset_index(drop=True)
    if "label_harmonized" not in q.columns:
        raise RuntimeError(f"{name}: missing label_harmonized")
    mapped = q["label_harmonized"].map(LABEL_TO_ID)
    if mapped.isna().any():
        bad = q.loc[mapped.isna(), "label_harmonized"].value_counts(dropna=False)
        raise RuntimeError(f"{name}: non-known labels in known cohort:\n{bad}")
    q["label_id"] = mapped.astype(int)
    return q


def make_open_targets(df: pd.DataFrame) -> np.ndarray:
    labels = df["label_harmonized"].astype(str)
    out = np.full(len(df), UNKNOWN_ID, dtype=int)
    for cls, idx in LABEL_TO_ID.items():
        out[labels.eq(cls).to_numpy()] = idx
    return out


def common_required_text_columns(df: pd.DataFrame, name: str):
    required = set(TEXT_VARIANTS.values()) | {"image_file", "label_harmonized"}
    missing = required - set(df.columns)
    if missing:
        raise RuntimeError(f"{name}: missing corrected V2.1/V3.1 columns: {sorted(missing)}")


# =============================================================================
# COHORT LOADING (DEV VS GUARDED FINAL TEST)
# =============================================================================

@dataclass
class StudyFrames:
    source_train: pd.DataFrame
    source_val: pd.DataFrame
    source_test: pd.DataFrame
    known_eval: Dict[str, pd.DataFrame]
    open_eval: Dict[str, pd.DataFrame]
    evaluation_mode: str


def _resolve_frame_paths(t2, frames_with_dataset: List[Tuple[str, pd.DataFrame]]) -> List[pd.DataFrame]:
    raw_frames = [f for _, f in frames_with_dataset]
    exact_idx, stem_idx = t2._build_image_index(raw_frames)
    out = []
    for dataset_name, frame in frames_with_dataset:
        out.append(t2.resolve_paths(frame, dataset_name, exact_idx, stem_idx))
    return out


def load_study_frames(root: Path, evaluation_mode: str) -> Tuple[StudyFrames, object, Path]:
    table2_path = find_table2_script(root)
    t2 = import_from_path("f0v3_table2_loader", table2_path)
    if Path(t2.ROOT) != root:
        raise RuntimeError(f"Table-2 ROOT mismatch: {t2.ROOT} != {root}")

    # Source data always come from the final V2.1 Table-2 cache.
    cache = t2.prepare_input_cache(force=False)
    pad_train = pd.read_csv(cache["pad_train"], low_memory=False)
    pad_val = pd.read_csv(cache["pad_val"], low_memory=False)
    pad_test = pd.read_csv(cache["pad_test"], low_memory=False)

    v2_dir = root / "preprocessed_outputs_openworld_v2_1_final"
    v3_dir = root / "preprocessed_outputs_midas_v3_1_final"

    if evaluation_mode == "development":
        isic_path = v2_dir / "isic_target_val_ow_v2_1_primary_eligible.csv"
        mcr_path = v2_dir / "mcr_target_val_ow_v2_1_primary_eligible.csv"
        isic_tag = "ISIC_target_val"
        mcr_tag = "MCR_target_val"
    elif evaluation_mode == "final_test":
        isic_path = v2_dir / "isic_target_test_ow_v2_1_primary_eligible.csv"
        mcr_path = v2_dir / "mcr_target_test_ow_v2_1_primary_eligible.csv"
        isic_tag = "ISIC_target_test"
        mcr_tag = "MCR_target_test"
    else:
        raise ValueError(evaluation_mode)

    midas6_known_path = v3_dir / "midas_external_6in_known.csv"
    midasd_known_path = v3_dir / "midas_external_dscope_known.csv"
    midas6_open_path = v3_dir / "midas_external_6in_openworld.csv"
    midasd_open_path = v3_dir / "midas_external_dscope_openworld.csv"

    required_files = [
        isic_path, mcr_path,
        midas6_known_path, midasd_known_path,
        midas6_open_path, midasd_open_path,
    ]
    for p in required_files:
        if not p.exists():
            raise FileNotFoundError(p)

    isic_open = pd.read_csv(isic_path, low_memory=False)
    mcr_open = pd.read_csv(mcr_path, low_memory=False)
    midas6_known = pd.read_csv(midas6_known_path, low_memory=False)
    midasd_known = pd.read_csv(midasd_known_path, low_memory=False)
    midas6_open = pd.read_csv(midas6_open_path, low_memory=False)
    midasd_open = pd.read_csv(midasd_open_path, low_memory=False)

    # Centralized MCR eligibility remains enforced even if a future export changes.
    if "primary_eval_eligible" in mcr_open.columns:
        mcr_open = mcr_open[as_bool(mcr_open["primary_eval_eligible"])].reset_index(drop=True)

    # Validate semantic/text columns BEFORE resolving images.
    for name, frame in [
        ("pad_train", pad_train), ("pad_val", pad_val), ("pad_test", pad_test),
        ("isic_open", isic_open), ("mcr_open", mcr_open),
        ("midas6_known", midas6_known), ("midasd_known", midasd_known),
        ("midas6_open", midas6_open), ("midasd_open", midasd_open),
    ]:
        common_required_text_columns(frame, name)

    # Source cache already contains resolved image_path.  Final/dev external CSVs
    # are resolved here using the same audited Table-2 resolver.
    to_resolve = [
        ("ISIC 2019", isic_open),
        ("MCR-SL", mcr_open),
        ("MRA-MIDAS", midas6_known),
        ("MRA-MIDAS", midasd_known),
        ("MRA-MIDAS", midas6_open),
        ("MRA-MIDAS", midasd_open),
    ]
    resolved = _resolve_frame_paths(t2, to_resolve)
    isic_open, mcr_open, midas6_known, midasd_known, midas6_open, midasd_open = resolved

    # Known-only cohorts for closed-set classification.
    isic_known = isic_open[isic_open["label_harmonized"].isin(KNOWN_CLASSES)].reset_index(drop=True)
    mcr_known = mcr_open[mcr_open["label_harmonized"].isin(KNOWN_CLASSES)].reset_index(drop=True)

    pad_train = ensure_known_label_ids(pad_train, "source_train")
    pad_val = ensure_known_label_ids(pad_val, "source_val")
    pad_test = ensure_known_label_ids(pad_test, "source_test")
    isic_known = ensure_known_label_ids(isic_known, f"{isic_tag}_known")
    mcr_known = ensure_known_label_ids(mcr_known, f"{mcr_tag}_known")
    midas6_known = ensure_known_label_ids(midas6_known, "MIDAS_6in_known")
    midasd_known = ensure_known_label_ids(midasd_known, "MIDAS_dscope_known")

    # Basic source-membership invariants.
    if (len(pad_train), len(pad_val), len(pad_test)) != (1593, 349, 356):
        raise RuntimeError(
            f"Unexpected PAD counts: train={len(pad_train)} val={len(pad_val)} test={len(pad_test)}"
        )

    known_eval = {
        "PAD_source_test": pad_test,
        f"{isic_tag}_known": isic_known,
        f"{mcr_tag}_known_primary": mcr_known,
        "MIDAS_6in_external_known": midas6_known,
        "MIDAS_dscope_external_known": midasd_known,
    }
    open_eval = {
        f"{isic_tag}_open": isic_open,
        f"{mcr_tag}_open_primary": mcr_open,
        "MIDAS_6in_external_open": midas6_open,
        "MIDAS_dscope_external_open": midasd_open,
    }

    return StudyFrames(
        source_train=pad_train,
        source_val=pad_val,
        source_test=pad_test,
        known_eval=known_eval,
        open_eval=open_eval,
        evaluation_mode=evaluation_mode,
    ), t2, table2_path


# =============================================================================
# DATASETS / TRANSFORMS
# =============================================================================

class ImageDataset(Dataset):
    def __init__(self, frame: pd.DataFrame, transform, return_label=True):
        self.frame = frame.reset_index(drop=True)
        self.transform = transform
        self.return_label = bool(return_label)

    def __len__(self):
        return len(self.frame)

    def __getitem__(self, idx):
        row = self.frame.iloc[idx]
        image = self.transform(Image.open(row["image_path"]).convert("RGB"))
        out = {"pixel_values": image, "index": torch.tensor(idx, dtype=torch.long)}
        if self.return_label:
            out["label"] = torch.tensor(int(row["label_id"]), dtype=torch.long)
        return out


class TextDataset(Dataset):
    """Hugging Face/BioClinicalBERT tokenized text-only dataset."""
    def __init__(self, frame: pd.DataFrame, tokenizer, text_col: str, max_len: int, return_label=True):
        self.frame = frame.reset_index(drop=True)
        self.return_label = bool(return_label)
        enc = tokenizer(
            [safe_text(x) for x in self.frame[text_col].tolist()],
            padding="max_length",
            truncation=True,
            max_length=max_len,
            return_tensors="pt",
        )
        self.input_ids = enc["input_ids"].contiguous()
        self.attention_mask = enc["attention_mask"].contiguous()

    def __len__(self):
        return len(self.frame)

    def __getitem__(self, idx):
        out = {
            "input_ids": self.input_ids[idx],
            "attention_mask": self.attention_mask[idx],
            "index": torch.tensor(idx, dtype=torch.long),
        }
        if self.return_label:
            out["label"] = torch.tensor(int(self.frame.iloc[idx]["label_id"]), dtype=torch.long)
        return out


def _native_tokenize_all(tokenizer, texts: List[str]):
    """
    Tokenize a native VLM text tower in one deterministic pass.

    Native tokenizer contracts differ across the audited models:
      * BiomedCLIP / DermLIP OpenCLIP tokenizers return an integer NxL tensor.
      * MONET's Hugging Face tokenizer returns a BatchEncoding / mapping and its
        adapter.encode_text() explicitly requires that mapping so attention_mask
        (and any other supported fields) are preserved.

    Do NOT collapse a Hugging Face BatchEncoding to input_ids only.
    """
    texts = [safe_text(x) for x in texts]
    tokens = tokenizer(texts)

    # OpenCLIP-style token tensor.
    if torch.is_tensor(tokens):
        if tokens.ndim != 2:
            raise RuntimeError(
                f"Expected native token tensor NxL, got {tuple(tokens.shape)}"
            )
        if int(tokens.shape[0]) != len(texts):
            raise RuntimeError(
                f"Native token batch mismatch: expected {len(texts)}, got {tokens.shape[0]}"
            )
        return tokens.contiguous()

    # Hugging Face BatchEncoding and ordinary dict/mapping objects expose items().
    if hasattr(tokens, "items"):
        out = {}
        for key, value in tokens.items():
            if value is None:
                continue
            if not torch.is_tensor(value):
                try:
                    value = torch.as_tensor(value)
                except Exception as e:
                    raise RuntimeError(
                        f"Native tokenizer field {key!r} could not be converted to a tensor: "
                        f"{type(value)}"
                    ) from e
            if value.ndim == 0:
                continue
            if int(value.shape[0]) != len(texts):
                raise RuntimeError(
                    f"Native tokenizer field {key!r} batch mismatch: "
                    f"expected {len(texts)}, got {value.shape[0]}"
                )
            out[str(key)] = value.contiguous()

        if "input_ids" not in out:
            keys = list(out.keys())
            raise RuntimeError(
                f"Native tokenizer mapping missing input_ids; tensor fields={keys}"
            )
        return out

    # Last-resort support for simple numeric list/array tokenizers.
    try:
        tokens = torch.as_tensor(tokens)
    except Exception as e:
        raise RuntimeError(
            f"Unsupported native tokenizer output type: {type(tokens)}"
        ) from e
    if tokens.ndim != 2:
        raise RuntimeError(f"Expected native token tensor NxL, got {tuple(tokens.shape)}")
    if int(tokens.shape[0]) != len(texts):
        raise RuntimeError(
            f"Native token batch mismatch: expected {len(texts)}, got {tokens.shape[0]}"
        )
    return tokens.contiguous()


def _native_tokens_item(tokens, idx: int):
    """Return one sample from tensor-style or mapping-style native tokens."""
    if torch.is_tensor(tokens):
        return tokens[idx]
    if isinstance(tokens, dict):
        return {k: v[idx] for k, v in tokens.items()}
    raise TypeError(f"Unsupported stored native token type: {type(tokens)}")


def _native_tokens_to_device(tokens, device):
    """Move tensor-style or mapping-style native tokens to the selected device."""
    non_blocking = torch.cuda.is_available()
    if torch.is_tensor(tokens):
        return tokens.to(device, non_blocking=non_blocking)
    if isinstance(tokens, dict):
        return {
            k: (v.to(device, non_blocking=non_blocking) if torch.is_tensor(v) else v)
            for k, v in tokens.items()
        }
    # BatchEncoding-like object can appear in direct (non-DataLoader) calls.
    if hasattr(tokens, "items"):
        return {
            str(k): (v.to(device, non_blocking=non_blocking) if torch.is_tensor(v) else v)
            for k, v in tokens.items()
        }
    raise TypeError(f"Unsupported native token type for device transfer: {type(tokens)}")


class NativeTextDataset(Dataset):
    """Text-only dataset for MONET/BiomedCLIP/DermLIP native text towers."""
    def __init__(self, frame: pd.DataFrame, tokenizer, text_col: str, return_label=True):
        self.frame = frame.reset_index(drop=True)
        self.return_label = bool(return_label)
        self.native_tokens = _native_tokenize_all(
            tokenizer, self.frame[text_col].tolist()
        )

    def __len__(self):
        return len(self.frame)

    def __getitem__(self, idx):
        out = {
            "native_tokens": _native_tokens_item(self.native_tokens, idx),
            "index": torch.tensor(idx, dtype=torch.long),
        }
        if self.return_label:
            out["label"] = torch.tensor(int(self.frame.iloc[idx]["label_id"]), dtype=torch.long)
        return out


class MultiModalDataset(Dataset):
    """Image + BioClinicalBERT text dataset."""
    def __init__(self, frame: pd.DataFrame, transform, tokenizer, text_col: str, max_len: int, return_label=True):
        self.frame = frame.reset_index(drop=True)
        self.transform = transform
        self.return_label = bool(return_label)
        enc = tokenizer(
            [safe_text(x) for x in self.frame[text_col].tolist()],
            padding="max_length",
            truncation=True,
            max_length=max_len,
            return_tensors="pt",
        )
        self.input_ids = enc["input_ids"].contiguous()
        self.attention_mask = enc["attention_mask"].contiguous()

    def __len__(self):
        return len(self.frame)

    def __getitem__(self, idx):
        row = self.frame.iloc[idx]
        out = {
            "pixel_values": self.transform(Image.open(row["image_path"]).convert("RGB")),
            "input_ids": self.input_ids[idx],
            "attention_mask": self.attention_mask[idx],
            "index": torch.tensor(idx, dtype=torch.long),
        }
        if self.return_label:
            out["label"] = torch.tensor(int(row["label_id"]), dtype=torch.long)
        return out


class NativeMultiModalDataset(Dataset):
    """Image + the SAME VLM's native text tokenizer/encoder."""
    def __init__(self, frame: pd.DataFrame, transform, tokenizer, text_col: str, return_label=True):
        self.frame = frame.reset_index(drop=True)
        self.transform = transform
        self.return_label = bool(return_label)
        self.native_tokens = _native_tokenize_all(
            tokenizer, self.frame[text_col].tolist()
        )

    def __len__(self):
        return len(self.frame)

    def __getitem__(self, idx):
        row = self.frame.iloc[idx]
        out = {
            "pixel_values": self.transform(Image.open(row["image_path"]).convert("RGB")),
            "native_tokens": _native_tokens_item(self.native_tokens, idx),
            "index": torch.tensor(idx, dtype=torch.long),
        }
        if self.return_label:
            out["label"] = torch.tensor(int(row["label_id"]), dtype=torch.long)
        return out


def loader_kwargs(batch_size: int, shuffle: bool):
    workers = int(RUNTIME_NUM_WORKERS)
    kwargs = dict(
        batch_size=batch_size,
        shuffle=shuffle,
        drop_last=False,
        num_workers=workers,
        pin_memory=PIN_MEMORY and torch.cuda.is_available(),
    )
    if workers > 0:
        kwargs["persistent_workers"] = PERSISTENT_WORKERS
        kwargs["prefetch_factor"] = PREFETCH_FACTOR
    return kwargs


def _find_normalize(transform_obj) -> Optional[Tuple[Tuple[float, ...], Tuple[float, ...]]]:
    """Recursively extract torchvision Normalize stats when exposed."""
    if isinstance(transform_obj, transforms.Normalize):
        return tuple(transform_obj.mean), tuple(transform_obj.std)
    children = getattr(transform_obj, "transforms", None)
    if children is not None:
        for child in children:
            found = _find_normalize(child)
            if found is not None:
                return found
    return None


def model_norm(model_name: str, bundle=None):
    if model_name in {"dinov2_vitb14", "mobilevit", "monet"}:
        return (0.485, 0.456, 0.406), (0.229, 0.224, 0.225)
    if model_name == "panderm_base":
        return (0.485, 0.456, 0.406), (0.228, 0.224, 0.225)
    if bundle is not None:
        found = _find_normalize(bundle.image_transform)
        if found is not None:
            return found
    # OpenCLIP default fallback; used only when the official transform does not
    # expose Normalize as a torchvision node.
    return (0.48145466, 0.4578275, 0.40821073), (0.26862954, 0.26130258, 0.27577711)


def make_train_transform(model_name: str, bundle=None):
    mean, std = model_norm(model_name, bundle)
    return transforms.Compose([
        transforms.Resize((256, 256), interpolation=InterpolationMode.BICUBIC),
        transforms.RandomResizedCrop(
            IMAGE_SIZE, scale=(0.65, 1.0), ratio=(0.8, 1.25), interpolation=InterpolationMode.BICUBIC
        ),
        transforms.RandomHorizontalFlip(p=0.5),
        transforms.RandomVerticalFlip(p=0.5),
        transforms.RandomRotation(degrees=30),
        transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2, hue=0.05),
        transforms.RandomGrayscale(p=0.05),
        transforms.ToTensor(),
        transforms.Normalize(mean=mean, std=std),
        transforms.RandomErasing(p=0.1, scale=(0.02, 0.1)),
    ])


def make_eval_transform(model_name: str, bundle=None, t2=None):
    if model_name == "mobilevit":
        if t2 is None:
            raise ValueError("t2 required for MobileViT eval transform")
        # Same ImageNet evaluation geometry as Table 2.
        sys.path.insert(0, str(t2.PACKAGE_DIR))
        from final_training_pipeline_reviewed.transforms import get_eval_transform
        return get_eval_transform(IMAGE_SIZE)
    if bundle is not None and bundle.image_transform is not None:
        return bundle.image_transform
    mean, std = model_norm(model_name, bundle)
    return transforms.Compose([
        transforms.Resize(256, interpolation=InterpolationMode.BICUBIC),
        transforms.CenterCrop(IMAGE_SIZE),
        transforms.ToTensor(),
        transforms.Normalize(mean=mean, std=std),
    ])


# =============================================================================
# MODELS
# =============================================================================

def import_v8(root: Path):
    """
    Import the audited V8 loader in a Windows-multiprocessing-safe way.

    Why this matters:
      V8 defines a small Hugging Face image-transform wrapper used by MONET.
      DataLoader workers on Windows use ``spawn`` and must be able to import the
      module that owns every pickled class. Importing V8 under a synthetic name
      such as ``f0v3_v8_loaders`` makes that name unavailable in the spawned
      interpreter and causes:

          ModuleNotFoundError: No module named 'f0v3_v8_loaders'

    Preferred path:
      Import V8 by its real Python module name (the canonical filename without
      ``.py``). This keeps num_workers>0 and therefore preserves fast loading.

    Fallback:
      If the discovered filename is not a valid Python identifier (for example
      ``run_v8_...(4).py``), dynamically import it but force DataLoader workers
      to 0 on Windows. Scientific behavior is unchanged; only I/O parallelism
      is reduced.
    """
    global RUNTIME_NUM_WORKERS, V8_IMPORT_MODE

    path = find_v8_script(root).resolve()
    parent = str(path.parent)
    if parent not in sys.path:
        sys.path.insert(0, parent)

    module_name = path.stem
    if module_name.isidentifier():
        importlib.invalidate_caches()
        module = importlib.import_module(module_name)
        loaded_path = Path(getattr(module, "__file__", "")).resolve()
        if loaded_path != path:
            raise RuntimeError(
                f"V8 module-name collision: expected {path}, imported {loaded_path}"
            )
        V8_IMPORT_MODE = f"importable:{module_name}"
        RUNTIME_NUM_WORKERS = NUM_WORKERS
        print(
            f"[F0-v3] V8 import={V8_IMPORT_MODE}; "
            f"DataLoader workers={RUNTIME_NUM_WORKERS}",
            flush=True,
        )
        return module, path

    module = import_from_path("f0v3_v8_loaders", path)
    V8_IMPORT_MODE = f"dynamic:{module_name}"
    if os.name == "nt":
        RUNTIME_NUM_WORKERS = 0
        print(
            "[F0-v3] WARNING: V8 filename is not importable by Windows spawned "
            f"workers ({path.name}). Falling back to num_workers=0. "
            "Rename/copy it to run_v8_2_2_pretrained_representation_benchmark.py "
            "to restore multi-worker loading.",
            flush=True,
        )
    return module, path


def _encode_image_native(backbone, feature_kind: str, x: torch.Tensor) -> torch.Tensor:
    if feature_kind == "dinov2_cls":
        out = backbone(x)
        if isinstance(out, dict):
            out = out.get("x_norm_clstoken")
            if out is None:
                raise RuntimeError("DINO output missing x_norm_clstoken")
    elif feature_kind == "panderm_forward_features":
        out = backbone.forward_features(x, is_train=False)
    elif feature_kind == "openclip_encode_image":
        try:
            out = backbone.encode_image(x, normalize=False)
        except TypeError:
            out = backbone.encode_image(x)
    else:
        raise RuntimeError(f"Unsupported feature kind: {feature_kind}")

    if isinstance(out, (tuple, list)):
        out = out[0]
    if isinstance(out, dict) or not torch.is_tensor(out):
        raise RuntimeError(f"Unresolved image output: {type(out)}")
    if out.ndim > 2:
        out = out.mean(dim=tuple(range(1, out.ndim - 1))) if out.shape[-1] > 8 else out.flatten(1)
    if out.ndim != 2:
        out = out.flatten(1)
    return out.float()


def _encode_native_text(backbone, native_text_kind: str, tokens: torch.Tensor) -> torch.Tensor:
    if native_text_kind == "openclip_encode_text":
        try:
            out = backbone.encode_text(tokens, normalize=False)
        except TypeError:
            out = backbone.encode_text(tokens)
    elif native_text_kind == "openai_clip_encode_text":
        out = backbone.encode_text(tokens)
    else:
        raise RuntimeError(f"Unsupported native text kind: {native_text_kind}")
    if isinstance(out, (tuple, list)):
        out = out[0]
    if not torch.is_tensor(out):
        raise RuntimeError(f"Unresolved native text output: {type(out)}")
    if out.ndim != 2:
        out = out.flatten(1)
    return out.float()


class TrainableFoundationClassifier(nn.Module):
    def __init__(self, bundle, feature_dim: int, num_classes: int):
        super().__init__()
        self.backbone = bundle.model
        self.feature_kind = str(bundle.image_feature_kind)
        self.classifier = nn.Linear(feature_dim, num_classes)
        for p in self.backbone.parameters():
            p.requires_grad_(True)

    def encode(self, x):
        return _encode_image_native(self.backbone, self.feature_kind, x)

    def forward(self, pixel_values, input_ids=None, attention_mask=None, native_tokens=None):
        return self.classifier(self.encode(pixel_values))


class NativeVLMTextClassifier(nn.Module):
    """Fine-tune a VLM's OWN text tower on textualized clinical metadata."""
    def __init__(self, bundle, text_dim: int, num_classes: int):
        super().__init__()
        self.backbone = bundle.model
        self.native_text_kind = str(bundle.native_text_kind)
        self.classifier = nn.Linear(text_dim, num_classes)
        for p in self.backbone.parameters():
            p.requires_grad_(True)

    def encode_text(self, native_tokens):
        return _encode_native_text(self.backbone, self.native_text_kind, native_tokens)

    def forward(self, pixel_values=None, input_ids=None, attention_mask=None, native_tokens=None):
        if native_tokens is None:
            raise RuntimeError("NativeVLMTextClassifier requires native_tokens")
        return self.classifier(self.encode_text(native_tokens))


class NativeVLMMultimodalClassifier(nn.Module):
    """Use a VLM's native aligned image and text towers directly.

    The two unit-normalized native embeddings are averaged in their shared
    representation space, then a fresh 6-class head is source-trained. This
    avoids inserting BioClinicalBERT into models that already own a text tower.
    """
    def __init__(self, bundle, feature_dim: int, num_classes: int):
        super().__init__()
        self.backbone = bundle.model
        self.image_feature_kind = str(bundle.image_feature_kind)
        self.native_text_kind = str(bundle.native_text_kind)
        self.classifier = nn.Linear(feature_dim, num_classes)
        for p in self.backbone.parameters():
            p.requires_grad_(True)

    def forward(self, pixel_values=None, input_ids=None, attention_mask=None, native_tokens=None):
        if pixel_values is None or native_tokens is None:
            raise RuntimeError("Native VLM multimodal model requires image + native text tokens")
        zi = _encode_image_native(self.backbone, self.image_feature_kind, pixel_values)
        zt = _encode_native_text(self.backbone, self.native_text_kind, native_tokens)
        if zi.shape[1] != zt.shape[1]:
            raise RuntimeError(f"Native VLM image/text dims differ: {zi.shape} vs {zt.shape}")
        fused = 0.5 * (F.normalize(zi, dim=-1) + F.normalize(zt, dim=-1))
        fused = F.normalize(fused, dim=-1)
        return self.classifier(fused)


class ImageModelAdapter(nn.Module):
    """Adapts the Table-2 MobileViT image-only model to the common signature."""
    def __init__(self, model):
        super().__init__()
        self.model = model

    def forward(self, pixel_values, input_ids=None, attention_mask=None, native_tokens=None):
        return self.model(pixel_values, None, None)


class BioClinicalBERTClassifier(nn.Module):
    def __init__(self, model_name: str, num_classes: int, dropout: float = DROPOUT):
        super().__init__()
        self.encoder = AutoModel.from_pretrained(model_name)
        hidden = int(self.encoder.config.hidden_size)
        self.dropout = nn.Dropout(dropout)
        self.classifier = nn.Linear(hidden, num_classes)
        for p in self.encoder.parameters():
            p.requires_grad_(True)

    def forward(self, pixel_values=None, input_ids=None, attention_mask=None, native_tokens=None):
        out = self.encoder(input_ids=input_ids, attention_mask=attention_mask)
        pooled = getattr(out, "pooler_output", None)
        if pooled is None:
            pooled = out.last_hidden_state[:, 0]
        return self.classifier(self.dropout(pooled))


class ExternalTextMultimodalClassifier(nn.Module):
    """Image backbone + BioClinicalBERT for models without a native text tower."""
    def __init__(self, bundle, image_dim: int, text_model_name: str, num_classes: int):
        super().__init__()
        self.backbone = bundle.model
        self.image_feature_kind = str(bundle.image_feature_kind)
        self.text_encoder = AutoModel.from_pretrained(text_model_name)
        text_dim = int(self.text_encoder.config.hidden_size)
        self.image_proj = nn.Sequential(nn.Linear(image_dim, FUSION_DIM), nn.GELU(), nn.LayerNorm(FUSION_DIM))
        self.text_proj = nn.Sequential(nn.Linear(text_dim, FUSION_DIM), nn.GELU(), nn.LayerNorm(FUSION_DIM))
        self.dropout = nn.Dropout(DROPOUT)
        self.classifier = nn.Linear(2 * FUSION_DIM, num_classes)
        for p in self.backbone.parameters():
            p.requires_grad_(True)
        for p in self.text_encoder.parameters():
            p.requires_grad_(True)

    def forward(self, pixel_values=None, input_ids=None, attention_mask=None, native_tokens=None):
        zi = _encode_image_native(self.backbone, self.image_feature_kind, pixel_values)
        tout = self.text_encoder(input_ids=input_ids, attention_mask=attention_mask)
        zt = getattr(tout, "pooler_output", None)
        if zt is None:
            zt = tout.last_hidden_state[:, 0]
        fused = torch.cat([self.image_proj(zi), self.text_proj(zt)], dim=-1)
        return self.classifier(self.dropout(fused))


class MultiModalAdapter(nn.Module):
    """Exact established MobileViT + BioClinicalBERT Table-2 fusion model."""
    def __init__(self, model):
        super().__init__()
        self.model = model

    def forward(self, pixel_values=None, input_ids=None, attention_mask=None, native_tokens=None):
        return self.model(pixel_values, input_ids, attention_mask)


def infer_foundation_dim(bundle, eval_transform, frame: pd.DataFrame, device) -> int:
    image = eval_transform(Image.open(frame.iloc[0]["image_path"]).convert("RGB")).unsqueeze(0).to(device)
    model = TrainableFoundationClassifier(bundle, 1, len(KNOWN_CLASSES)).to(device)
    # Temporarily bypass the dummy classifier.
    with torch.no_grad():
        z = model.encode(image)
    del model
    return int(z.shape[1])


def infer_native_text_dim(bundle, text: str, device) -> int:
    if bundle.native_tokenizer is None or bundle.native_text_kind is None:
        raise RuntimeError(f"{bundle.name} has no native text encoder")
    tokens = _native_tokens_to_device(
        _native_tokenize_all(bundle.native_tokenizer, [text]), device
    )
    with torch.no_grad():
        z = _encode_native_text(bundle.model, bundle.native_text_kind, tokens)
    return int(z.shape[1])


def build_mobilevit_table2_model(root: Path, t2, family: str, device):
    sys.path.insert(0, str(root))
    sys.path.insert(0, str(t2.PACKAGE_DIR))
    from config import ExperimentConfig
    from final_training_pipeline_reviewed.models import build_model

    cfg = ExperimentConfig(seed=42)
    image_model_name = cfg.image_model_name
    build_sig = inspect.signature(build_model)
    if "dropout" not in build_sig.parameters:
        raise RuntimeError("Active build_model lacks dropout; package mismatch")

    model = build_model(
        family,
        image_model_name,
        cfg.text_model_name,
        len(KNOWN_CLASSES),
        fusion_dim=FUSION_DIM,
        num_heads=NUM_HEADS,
        freeze_backbones=False,
        dropout=DROPOUT,
    ).to(device)
    return model, str(cfg.text_model_name)


# =============================================================================
# CONDITION MATRIX
# =============================================================================

@dataclass(frozen=True)
class Condition:
    name: str
    family: str
    model_name: str
    text_col: Optional[str]
    text_encoder: Optional[str]
    description: str


def all_conditions() -> List[Condition]:
    rows: List[Condition] = []

    # A) Image-only: every image-capable model is directly fine-tuned.
    for m in IMAGE_MODELS:
        rows.append(Condition(
            name=f"image__{m}", family="image", model_name=m, text_col=None,
            text_encoder=None,
            description=f"fully fine-tuned image-only pretrained backbone: {m}",
        ))

    # B1) One shared BioClinicalBERT text-only baseline for models that do not
    # possess a native text encoder. We do NOT duplicate identical BERT runs
    # separately for PanDerm, DINOv2, and MobileViT.
    for short, col in TEXT_VARIANTS.items():
        rows.append(Condition(
            name=f"metadata__bioclinicalbert__{short}", family="metadata",
            model_name="bioclinicalbert", text_col=col,
            text_encoder="bioclinicalbert",
            description=f"BioClinicalBERT-only metadata baseline: {col}",
        ))

    # B2) Native text-only baselines for self-sufficient VLMs.
    for m in sorted(NATIVE_VLM_MODELS):
        for short, col in TEXT_VARIANTS.items():
            rows.append(Condition(
                name=f"metadata__{m}__{short}", family="metadata",
                model_name=m, text_col=col, text_encoder="native_vlm",
                description=f"{m} native text encoder only: {col}",
            ))

    # C) Multimodal: self-sufficient VLMs use their OWN image+text towers.
    # Models without a native text tower are paired with BioClinicalBERT.
    for m in IMAGE_MODELS:
        text_encoder = "native_vlm" if m in NATIVE_VLM_MODELS else "bioclinicalbert"
        for short, col in TEXT_VARIANTS.items():
            rows.append(Condition(
                name=f"multimodal__{m}__{short}", family="multimodal",
                model_name=m, text_col=col, text_encoder=text_encoder,
                description=(
                    f"{m} native image + native text: {col}" if text_encoder == "native_vlm"
                    else f"{m} image + BioClinicalBERT metadata: {col}"
                ),
            ))
    return rows


def condition_map() -> Dict[str, Condition]:
    return {c.name: c for c in all_conditions()}


def select_conditions(families: List[str], names: Optional[List[str]]) -> List[Condition]:
    cmap = condition_map()
    if names:
        missing = [x for x in names if x not in cmap]
        if missing:
            raise ValueError(f"Unknown conditions: {missing}\nAllowed={list(cmap)}")
        return [cmap[x] for x in names]
    return [c for c in all_conditions() if c.family in families]


# =============================================================================
# OPTIMIZER / LOSS
# =============================================================================

def _discover_max_block_index(model: nn.Module) -> int:
    indices = []
    pats = [
        re.compile(r"(?:^|\.)(?:blocks|layers|resblocks)\.(\d+)(?:\.|$)"),
        re.compile(r"(?:^|\.)encoder\.layer\.(\d+)(?:\.|$)"),
    ]
    for name, _ in model.named_parameters():
        for pat in pats:
            m = pat.search(name)
            if m:
                indices.append(int(m.group(1)))
                break
    return max(indices) if indices else -1


def _layer_id_from_name(name: str, max_block: int) -> int:
    for pat in [
        re.compile(r"(?:^|\.)(?:blocks|layers|resblocks)\.(\d+)(?:\.|$)"),
        re.compile(r"(?:^|\.)encoder\.layer\.(\d+)(?:\.|$)"),
    ]:
        m = pat.search(name)
        if m:
            return int(m.group(1)) + 1
    early = ("patch_embed", "pos_embed", "cls_token", "embeddings", "stem", "conv1")
    if any(tok in name for tok in early):
        return 0
    return max_block + 2


def build_foundation_optimizer(model: TrainableFoundationClassifier, model_name: str):
    recipe = MODEL_RECIPES[model_name]
    base_lr = float(recipe["backbone_lr"])
    head_lr = float(recipe["head_lr"])
    decay = float(recipe["layer_decay"])
    wd = float(recipe["weight_decay"])
    max_block = _discover_max_block_index(model.backbone)
    max_layer_id = max_block + 2
    groups = {}
    for name, p in model.backbone.named_parameters():
        if not p.requires_grad:
            continue
        lid = _layer_id_from_name(name, max_block)
        scale = decay ** max(0, max_layer_id - lid)
        no_decay = p.ndim == 1 or name.endswith(".bias") or "norm" in name.lower()
        key = (lid, no_decay)
        groups.setdefault(key, {
            "params": [], "lr": base_lr * scale,
            "weight_decay": 0.0 if no_decay else wd,
            "group_name": f"backbone_layer_{lid}_{'no_decay' if no_decay else 'decay'}",
        })
        groups[key]["params"].append(p)
    param_groups = list(groups.values()) + [{
        "params": list(model.classifier.parameters()),
        "lr": head_lr,
        "weight_decay": wd,
        "group_name": "classifier_head",
    }]
    opt = torch.optim.AdamW(param_groups)
    audit = {
        "max_backbone_block_index": max_block,
        "n_optimizer_groups": len(param_groups),
        "backbone_top_lr": base_lr,
        "head_lr": head_lr,
        "layer_decay": decay,
        "weight_decay": wd,
        "min_backbone_group_lr": float(min(g["lr"] for g in param_groups if g["group_name"].startswith("backbone"))),
    }
    return opt, audit


def build_external_text_optimizer(model: ExternalTextMultimodalClassifier, model_name: str):
    """Layer-decayed image backbone + BioClinicalBERT + fusion-head groups."""
    recipe = MODEL_RECIPES[model_name]
    base_lr = float(recipe["backbone_lr"])
    head_lr = float(recipe["head_lr"])
    decay = float(recipe["layer_decay"])
    wd = float(recipe["weight_decay"])
    max_block = _discover_max_block_index(model.backbone)
    max_layer_id = max_block + 2
    groups = {}
    for name, p in model.backbone.named_parameters():
        if not p.requires_grad:
            continue
        lid = _layer_id_from_name(name, max_block)
        scale = decay ** max(0, max_layer_id - lid)
        no_decay = p.ndim == 1 or name.endswith(".bias") or "norm" in name.lower()
        key = (lid, no_decay)
        groups.setdefault(key, {
            "params": [], "lr": base_lr * scale,
            "weight_decay": 0.0 if no_decay else wd,
            "group_name": f"image_backbone_layer_{lid}_{'no_decay' if no_decay else 'decay'}",
        })
        groups[key]["params"].append(p)

    param_groups = list(groups.values())
    param_groups.append({
        "params": list(model.text_encoder.parameters()),
        "lr": MOBILEVIT_LR, "weight_decay": MOBILEVIT_WD,
        "group_name": "bioclinicalbert",
    })
    head_params = list(model.image_proj.parameters()) + list(model.text_proj.parameters()) + list(model.classifier.parameters())
    param_groups.append({
        "params": head_params, "lr": head_lr, "weight_decay": wd,
        "group_name": "fusion_head",
    })
    opt = torch.optim.AdamW(param_groups)
    return opt, {
        "optimizer": "AdamW capability-aware multimodal",
        "image_backbone_top_lr": base_lr,
        "image_layer_decay": decay,
        "bioclinicalbert_lr": MOBILEVIT_LR,
        "fusion_head_lr": head_lr,
        "weight_decay": wd,
        "n_optimizer_groups": len(param_groups),
    }


def effective_number_loss_weights(train_df: pd.DataFrame, device):
    y = train_df["label_id"].astype(int).to_numpy()
    counts = np.bincount(y, minlength=len(KNOWN_CLASSES)).astype(np.float64)
    if np.any(counts <= 0):
        raise RuntimeError(f"Absent source class: {counts.tolist()}")
    weights = (1.0 - BALANCE_BETA) / np.maximum(1.0 - BALANCE_BETA ** counts, 1e-12)
    weights /= weights.mean()
    return torch.tensor(weights, dtype=torch.float32, device=device), counts.astype(int)


# =============================================================================
# FORWARD / METRICS
# =============================================================================

def forward_batch(model, batch, device):
    pixels = batch.get("pixel_values")
    ids = batch.get("input_ids")
    mask = batch.get("attention_mask")
    native_tokens = batch.get("native_tokens")
    if pixels is not None:
        pixels = pixels.to(device, non_blocking=torch.cuda.is_available())
    if ids is not None:
        ids = ids.to(device, non_blocking=torch.cuda.is_available())
    if mask is not None:
        mask = mask.to(device, non_blocking=torch.cuda.is_available())
    if native_tokens is not None:
        native_tokens = _native_tokens_to_device(native_tokens, device)
    return model(
        pixel_values=pixels, input_ids=ids, attention_mask=mask, native_tokens=native_tokens
    )


@torch.no_grad()
def predict(model, loader, device):
    model.eval()
    probs, ys, indices = [], [], []
    for batch in loader:
        logits = forward_batch(model, batch, device)
        probs.append(torch.softmax(logits.float(), dim=1).cpu().numpy())
        indices.append(batch["index"].cpu().numpy())
        if "label" in batch:
            ys.append(batch["label"].cpu().numpy())
    return {
        "probs": np.concatenate(probs, axis=0),
        "y_true": np.concatenate(ys).astype(int) if ys else None,
        "index": np.concatenate(indices).astype(int),
    }


def closed_metrics(y_true, probs) -> Dict[str, float]:
    y = np.asarray(y_true, dtype=int)
    probs = np.asarray(probs, dtype=float)
    pred = probs.argmax(axis=1)
    labels = list(range(len(KNOWN_CLASSES)))
    out = {
        "macro_f1": float(f1_score(y, pred, labels=labels, average="macro", zero_division=0)),
        "balanced_accuracy": float(balanced_accuracy_score(y, pred)),
        "accuracy": float(accuracy_score(y, pred)),
        "macro_precision": float(precision_score(y, pred, labels=labels, average="macro", zero_division=0)),
        "macro_recall": float(recall_score(y, pred, labels=labels, average="macro", zero_division=0)),
    }
    try:
        # Multiclass OvR macro AUROC is meaningful only when all classes are represented.
        if set(labels).issubset(set(np.unique(y).tolist())):
            out["macro_auroc_ovr"] = float(
                roc_auc_score(y, probs, labels=labels, multi_class="ovr", average="macro")
            )
        else:
            out["macro_auroc_ovr"] = float("nan")
    except Exception:
        out["macro_auroc_ovr"] = float("nan")
    return out


def per_class_rows(y_true, probs, condition: Condition, seed: int, domain: str):
    y = np.asarray(y_true, dtype=int)
    pred = np.asarray(probs).argmax(axis=1)
    rows = []
    for idx, cls in enumerate(KNOWN_CLASSES):
        true_bin = (y == idx).astype(int)
        pred_bin = (pred == idx).astype(int)
        rows.append({
            "condition": condition.name,
            "family": condition.family,
            "model": condition.model_name,
            "text_col": condition.text_col or "",
            "text_encoder": condition.text_encoder or "",
            "seed": seed,
            "domain": domain,
            "class": cls,
            "support": int(true_bin.sum()),
            "f1": float(f1_score(true_bin, pred_bin, zero_division=0)),
            "precision": float(precision_score(true_bin, pred_bin, zero_division=0)),
            "recall": float(recall_score(true_bin, pred_bin, zero_division=0)),
        })
    return rows


def harmonic(a: float, b: float) -> float:
    return 0.0 if (not np.isfinite(a) or not np.isfinite(b) or a + b <= 0) else float(2 * a * b / (a + b))


def fpr95_unknown_positive(is_unknown: np.ndarray, score: np.ndarray) -> float:
    y = np.asarray(is_unknown, dtype=int)
    if len(np.unique(y)) != 2:
        return float("nan")
    fpr, tpr, _ = roc_curve(y, np.asarray(score, dtype=float), pos_label=1)
    mask = tpr >= 0.95
    return float(np.min(fpr[mask])) if np.any(mask) else float("nan")


def oscr_auc(y_open: np.ndarray, known_pred: np.ndarray, ood_score: np.ndarray) -> float:
    """
    OSCR-AUC with lower OOD score = more likely known.
    CCR(t) = fraction of ALL known samples that are both correctly classified and accepted.
    FPR(t) = fraction of unknown samples accepted.
    """
    y = np.asarray(y_open, dtype=int)
    pred = np.asarray(known_pred, dtype=int)
    score = np.asarray(ood_score, dtype=float)
    known = y != UNKNOWN_ID
    unknown = ~known
    if not known.any() or not unknown.any():
        return float("nan")
    correct_known = known & (pred == y)
    thresholds = np.r_[-np.inf, np.sort(np.unique(score)), np.inf]
    fprs, ccrs = [], []
    for t in thresholds:
        accepted = score <= t
        fprs.append(float((accepted & unknown).sum() / unknown.sum()))
        ccrs.append(float((accepted & correct_known).sum() / known.sum()))
    order = np.argsort(fprs)
    x = np.asarray(fprs)[order]
    yv = np.asarray(ccrs)[order]
    # For duplicate FPR values retain the maximum achievable CCR.
    ux = np.unique(x)
    uy = np.asarray([yv[x == xx].max() for xx in ux])
    return float(np.trapezoid(uy, ux))


def open_metrics(y_open, known_probs, ood_score, threshold) -> Dict[str, float]:
    y = np.asarray(y_open, dtype=int)
    probs = np.asarray(known_probs, dtype=float)
    score = np.asarray(ood_score, dtype=float)
    known_pred = probs.argmax(axis=1)
    unknown = y == UNKNOWN_ID
    known = ~unknown
    reject = score > float(threshold)
    pred_open = known_pred.copy()
    pred_open[reject] = UNKNOWN_ID

    out = {
        "open_macro_f1": float(
            f1_score(y, pred_open, labels=list(range(UNKNOWN_ID + 1)), average="macro", zero_division=0)
        ),
        "os_star": float(
            recall_score(y[known], pred_open[known], labels=list(range(UNKNOWN_ID)), average="macro", zero_division=0)
        ) if known.any() else float("nan"),
        "unknown_recall": float((pred_open[unknown] == UNKNOWN_ID).mean()) if unknown.any() else float("nan"),
        "known_false_reject_fraction": float(reject[known].mean()) if known.any() else float("nan"),
        "predicted_unknown_fraction": float(reject.mean()),
        "oscr_auc": oscr_auc(y, known_pred, score),
    }
    out["hos"] = harmonic(out["os_star"], out["unknown_recall"])

    binary = unknown.astype(int)
    if len(np.unique(binary)) == 2:
        out["ood_auroc"] = float(roc_auc_score(binary, score))
        out["aupr_out"] = float(average_precision_score(binary, score))
        out["aupr_in"] = float(average_precision_score(known.astype(int), -score))
        out["fpr95"] = fpr95_unknown_positive(binary, score)
    else:
        out.update(ood_auroc=float("nan"), aupr_out=float("nan"), aupr_in=float("nan"), fpr95=float("nan"))
    return out


# =============================================================================
# OOD CACHE — FROZEN DERMLIP-B16 + CLINICAL PROMPT + MCM
# =============================================================================

class OODImageDataset(Dataset):
    def __init__(self, frame, transform):
        self.frame = frame.reset_index(drop=True)
        self.transform = transform
    def __len__(self): return len(self.frame)
    def __getitem__(self, idx):
        return self.transform(Image.open(self.frame.iloc[idx]["image_path"]).convert("RGB")), idx


def _softmax_np(x):
    x = np.asarray(x, dtype=np.float64)
    x = x - x.max(axis=1, keepdims=True)
    ex = np.exp(x)
    return ex / ex.sum(axis=1, keepdims=True)


def compute_dermlip_mcm_scores(v8, bundle, text_features: np.ndarray, frame: pd.DataFrame) -> np.ndarray:
    ds = OODImageDataset(frame, bundle.image_transform)
    loader = DataLoader(ds, **loader_kwargs(EVAL_BATCH_SIZE, shuffle=False))
    feats = []
    bundle.model.eval()
    with torch.inference_mode():
        for images, _ in loader:
            images = images.to(bundle.device, non_blocking=torch.cuda.is_available())
            z = v8.encode_image_batch(bundle, images)
            if torch.is_tensor(z):
                z = z.detach().float().cpu().numpy()
            feats.append(np.asarray(z, dtype=np.float32))
    img = np.concatenate(feats, axis=0)
    img /= np.maximum(np.linalg.norm(img, axis=1, keepdims=True), 1e-12)
    txt = np.asarray(text_features, dtype=np.float32)
    txt /= np.maximum(np.linalg.norm(txt, axis=1, keepdims=True), 1e-12)
    logits = img @ txt.T
    return (1.0 - _softmax_np(logits).max(axis=1)).astype(np.float64)


def prepare_ood_cache(root: Path, output_root: Path, frames: StudyFrames, v8) -> Tuple[float, Dict[str, np.ndarray]]:
    cache_dir = output_root / "ood_cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = cache_dir / "ood_cache_manifest.json"
    threshold_path = cache_dir / "source_val_threshold.npy"

    expected_domains = list(frames.open_eval.keys())
    score_paths = {d: cache_dir / f"{re.sub(r'[^A-Za-z0-9_.-]+', '_', d)}_mcm.npy" for d in expected_domains}
    if manifest_path.exists() and threshold_path.exists() and all(p.exists() for p in score_paths.values()):
        threshold = float(np.load(threshold_path)[0])
        return threshold, {d: np.load(p) for d, p in score_paths.items()}

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    bundle = v8.load_encoder(OOD_MODEL, device)
    class_names = [OOD_CLASS_DISPLAY[c] for c in KNOWN_CLASSES]
    prompts = [OOD_PROMPT_TEMPLATE.format(c) for c in class_names]
    tokens = bundle.native_tokenizer(prompts).to(device)
    bundle.model.eval()
    with torch.inference_mode():
        try:
            txt = bundle.model.encode_text(tokens, normalize=False)
        except TypeError:
            txt = bundle.model.encode_text(tokens)
    txt = txt.detach().float().cpu().numpy()

    source_scores = compute_dermlip_mcm_scores(v8, bundle, txt, frames.source_val)
    threshold = float(np.quantile(source_scores, OOD_QUANTILE))
    np.save(threshold_path, np.asarray([threshold], dtype=np.float64))

    all_scores = {}
    for domain, frame in frames.open_eval.items():
        s = compute_dermlip_mcm_scores(v8, bundle, txt, frame)
        np.save(score_paths[domain], s)
        all_scores[domain] = s

    jdump({
        "ood_model": OOD_MODEL,
        "prompt_template": OOD_PROMPT_TEMPLATE,
        "score": "MCM = 1 - max softmax(cosine logits), T=1",
        "threshold_rule": "PAD source_val q95",
        "threshold": threshold,
        "source_val_reject_fraction": float((source_scores > threshold).mean()),
        "evaluation_mode": frames.evaluation_mode,
        "domains": {d: int(len(frames.open_eval[d])) for d in expected_domains},
        "isic_pretraining_overlap_caveat": True,
        "role": "common frozen OOD branch; never used for classifier training/selection",
    }, manifest_path)

    del bundle
    cleanup_cuda()
    return threshold, all_scores


# =============================================================================
# BUILD A CONDITION
# =============================================================================

def build_condition_model(
    root: Path,
    t2,
    v8,
    condition: Condition,
    seed: int,
    device,
    source_train: pd.DataFrame,
):
    set_seed(seed)
    tokenizer = None
    bundle = None
    opt_audit = {}

    # ------------------------------------------------------------------
    # IMAGE ONLY
    # ------------------------------------------------------------------
    if condition.family == "image":
        if condition.model_name == "mobilevit":
            base, _ = build_mobilevit_table2_model(root, t2, "image_only", device)
            model = ImageModelAdapter(base).to(device)
            train_tf = make_train_transform("mobilevit", None)
            eval_tf = make_eval_transform("mobilevit", None, t2=t2)
            optimizer = torch.optim.AdamW(model.parameters(), lr=MOBILEVIT_LR, weight_decay=MOBILEVIT_WD)
            opt_audit = {"optimizer": "AdamW flat", "lr": MOBILEVIT_LR, "weight_decay": MOBILEVIT_WD}
        else:
            bundle = v8.load_encoder(condition.model_name, device)
            for p in bundle.model.parameters():
                p.requires_grad_(True)
            train_tf = make_train_transform(condition.model_name, bundle)
            eval_tf = make_eval_transform(condition.model_name, bundle, t2=t2)
            feature_dim = infer_foundation_dim(bundle, eval_tf, source_train, device)
            model = TrainableFoundationClassifier(bundle, feature_dim, len(KNOWN_CLASSES)).to(device)
            optimizer, opt_audit = build_foundation_optimizer(model, condition.model_name)
        return model, optimizer, train_tf, eval_tf, tokenizer, bundle, opt_audit

    # ------------------------------------------------------------------
    # TEXT / METADATA ONLY
    # ------------------------------------------------------------------
    if condition.family == "metadata":
        if condition.text_encoder == "bioclinicalbert":
            tokenizer = AutoTokenizer.from_pretrained(BIOCLINICAL_MODEL)
            model = BioClinicalBERTClassifier(BIOCLINICAL_MODEL, len(KNOWN_CLASSES)).to(device)
            optimizer = torch.optim.AdamW(model.parameters(), lr=MOBILEVIT_LR, weight_decay=MOBILEVIT_WD)
            opt_audit = {
                "optimizer": "AdamW flat", "lr": MOBILEVIT_LR,
                "weight_decay": MOBILEVIT_WD, "text_encoder": "BioClinicalBERT",
            }
            return model, optimizer, None, None, tokenizer, None, opt_audit

        if condition.text_encoder == "native_vlm":
            bundle = v8.load_encoder(condition.model_name, device)
            if bundle.native_tokenizer is None or bundle.native_text_kind is None:
                raise RuntimeError(f"{condition.model_name} does not expose a native text encoder")
            for p in bundle.model.parameters():
                p.requires_grad_(True)
            tokenizer = bundle.native_tokenizer
            text_dim = infer_native_text_dim(
                bundle, safe_text(source_train.iloc[0][condition.text_col]), device
            )
            model = NativeVLMTextClassifier(bundle, text_dim, len(KNOWN_CLASSES)).to(device)
            optimizer, opt_audit = build_foundation_optimizer(model, condition.model_name)
            opt_audit["text_encoder"] = f"{condition.model_name}:native"
            return model, optimizer, None, None, tokenizer, bundle, opt_audit

        raise RuntimeError(f"Unsupported metadata text_encoder={condition.text_encoder}")

    # ------------------------------------------------------------------
    # MULTIMODAL
    # ------------------------------------------------------------------
    if condition.family == "multimodal":
        # Self-sufficient image-text VLMs: use their OWN aligned image+text towers.
        if condition.text_encoder == "native_vlm":
            bundle = v8.load_encoder(condition.model_name, device)
            if bundle.native_tokenizer is None or bundle.native_text_kind is None:
                raise RuntimeError(f"{condition.model_name} does not expose native text")
            for p in bundle.model.parameters():
                p.requires_grad_(True)
            tokenizer = bundle.native_tokenizer
            train_tf = make_train_transform(condition.model_name, bundle)
            eval_tf = make_eval_transform(condition.model_name, bundle, t2=t2)
            image_dim = infer_foundation_dim(bundle, eval_tf, source_train, device)
            text_dim = infer_native_text_dim(
                bundle, safe_text(source_train.iloc[0][condition.text_col]), device
            )
            if image_dim != text_dim:
                raise RuntimeError(
                    f"{condition.model_name}: native image/text dims differ {image_dim} vs {text_dim}"
                )
            model = NativeVLMMultimodalClassifier(bundle, image_dim, len(KNOWN_CLASSES)).to(device)
            optimizer, opt_audit = build_foundation_optimizer(model, condition.model_name)
            opt_audit.update({
                "text_encoder": f"{condition.model_name}:native",
                "fusion": "mean of unit-normalized native aligned image/text embeddings",
            })
            return model, optimizer, train_tf, eval_tf, tokenizer, bundle, opt_audit

        # MobileViT retains the established source-fine-tuned Table-2
        # MobileViT + BioClinicalBERT cross-attention implementation.
        if condition.model_name == "mobilevit":
            base, text_model_name = build_mobilevit_table2_model(
                root, t2, "mobilevit_cross_attention", device
            )
            model = MultiModalAdapter(base).to(device)
            tokenizer = AutoTokenizer.from_pretrained(text_model_name)
            train_tf = make_train_transform("mobilevit", None)
            eval_tf = make_eval_transform("mobilevit", None, t2=t2)
            optimizer = torch.optim.AdamW(model.parameters(), lr=MOBILEVIT_LR, weight_decay=MOBILEVIT_WD)
            opt_audit = {
                "optimizer": "AdamW flat", "lr": MOBILEVIT_LR,
                "weight_decay": MOBILEVIT_WD, "text_encoder": "BioClinicalBERT",
                "fusion": "established Table-2 cross-attention",
            }
            return model, optimizer, train_tf, eval_tf, tokenizer, None, opt_audit

        # PanDerm/DINOv2 have no native text tower: pair the image backbone with
        # fully fine-tuned BioClinicalBERT and a simple projected-concat head.
        if condition.text_encoder == "bioclinicalbert":
            bundle = v8.load_encoder(condition.model_name, device)
            for p in bundle.model.parameters():
                p.requires_grad_(True)
            tokenizer = AutoTokenizer.from_pretrained(BIOCLINICAL_MODEL)
            train_tf = make_train_transform(condition.model_name, bundle)
            eval_tf = make_eval_transform(condition.model_name, bundle, t2=t2)
            image_dim = infer_foundation_dim(bundle, eval_tf, source_train, device)
            model = ExternalTextMultimodalClassifier(
                bundle, image_dim, BIOCLINICAL_MODEL, len(KNOWN_CLASSES)
            ).to(device)
            optimizer, opt_audit = build_external_text_optimizer(model, condition.model_name)
            opt_audit.update({
                "text_encoder": "BioClinicalBERT",
                "fusion": "projected concat (image + BioClinicalBERT)",
            })
            return model, optimizer, train_tf, eval_tf, tokenizer, bundle, opt_audit

        raise RuntimeError(f"Unsupported multimodal condition: {condition}")

    raise ValueError(condition.family)


def make_dataset(condition: Condition, frame: pd.DataFrame, train_tf, eval_tf, tokenizer, training: bool, return_label: bool):
    tf = train_tf if training else eval_tf
    if condition.family == "image":
        return ImageDataset(frame, tf, return_label=return_label)
    if condition.family == "metadata":
        if condition.text_encoder == "native_vlm":
            return NativeTextDataset(frame, tokenizer, condition.text_col, return_label=return_label)
        return TextDataset(frame, tokenizer, condition.text_col, MAX_TEXT_LEN, return_label=return_label)
    if condition.family == "multimodal":
        if condition.text_encoder == "native_vlm":
            return NativeMultiModalDataset(frame, tf, tokenizer, condition.text_col, return_label=return_label)
        return MultiModalDataset(frame, tf, tokenizer, condition.text_col, MAX_TEXT_LEN, return_label=return_label)
    raise ValueError(condition.family)


# =============================================================================
# TRAIN / EVALUATE ONE CONDITION-SEED
# =============================================================================

def train_one_epoch(model, loader, optimizer, criterion, device, scaler, amp_enabled):
    model.train()
    total, n_seen = 0.0, 0
    for batch in loader:
        labels = batch["label"].to(device, non_blocking=torch.cuda.is_available())
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast(
            device_type="cuda" if device.type == "cuda" else "cpu",
            dtype=torch.float16 if device.type == "cuda" else torch.bfloat16,
            enabled=amp_enabled,
        ):
            logits = forward_batch(model, batch, device)
            loss = criterion(logits, labels)
        if scaler is not None:
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), GRAD_CLIP_NORM)
            scaler.step(optimizer)
            scaler.update()
        else:
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), GRAD_CLIP_NORM)
            optimizer.step()
        bs = int(labels.shape[0])
        total += float(loss.detach().cpu()) * bs
        n_seen += bs
    return total / max(n_seen, 1)


def run_one_seed(
    root: Path,
    output_root: Path,
    condition: Condition,
    seed: int,
    evaluation_mode: str,
    force: bool = False,
):
    run_dir = output_root / "children" / condition.name / f"seed_{seed}"
    metrics_path = run_dir / "closed_metrics.csv"
    if metrics_path.exists() and not force:
        print(f"[F0-v3] Skip completed {condition.name}/seed{seed}")
        return
    run_dir.mkdir(parents=True, exist_ok=True)

    frames, t2, table2_path = load_study_frames(root, evaluation_mode)
    v8, v8_path = import_v8(root)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[F0-v3] {condition.name}/seed{seed} device={device}")

    model, optimizer, train_tf, eval_tf, tokenizer, bundle, opt_audit = build_condition_model(
        root, t2, v8, condition, seed, device, frames.source_train
    )

    # Audit trainability.  All condition-specific pretrained encoders are intended
    # to adapt to PAD source_train in this experiment.
    n_params = sum(p.numel() for p in model.parameters())
    n_trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    if n_trainable <= 0:
        raise RuntimeError(f"{condition.name}: no trainable parameters")

    train_ds = make_dataset(condition, frames.source_train, train_tf, eval_tf, tokenizer, True, True)
    val_ds = make_dataset(condition, frames.source_val, train_tf, eval_tf, tokenizer, False, True)
    train_loader = DataLoader(train_ds, **loader_kwargs(BATCH_SIZE, shuffle=True))
    val_loader = DataLoader(val_ds, **loader_kwargs(EVAL_BATCH_SIZE, shuffle=False))

    weights, source_counts = effective_number_loss_weights(frames.source_train, device)
    criterion = nn.CrossEntropyLoss(weight=weights)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="max", factor=SCHEDULER_FACTOR, patience=SCHEDULER_PATIENCE
    )
    amp_enabled = bool(USE_AMP and device.type == "cuda")
    try:
        scaler = torch.amp.GradScaler("cuda", enabled=amp_enabled)
    except Exception:
        scaler = torch.cuda.amp.GradScaler(enabled=amp_enabled) if device.type == "cuda" else None

    best_f1, best_epoch, patience = -1.0, -1, 0
    best_path = run_dir / "best.pt"
    history = []

    epoch_bar = tqdm(
        range(1, MAX_EPOCHS + 1),
        desc=f"{condition.name} | seed {seed}",
        unit="epoch",
        dynamic_ncols=True,
        leave=True,
    )
    for epoch in epoch_bar:
        loss = train_one_epoch(model, train_loader, optimizer, criterion, device, scaler, amp_enabled)
        val_cache = predict(model, val_loader, device)
        vm = closed_metrics(val_cache["y_true"], val_cache["probs"])
        val_f1 = vm["macro_f1"]
        scheduler.step(val_f1)
        improved = val_f1 > best_f1 + 1e-12
        if improved:
            best_f1, best_epoch, patience = val_f1, epoch, 0
            torch.save({
                "protocol": "F0_v3_backbone_metadata_benchmark",
                "condition": condition.name,
                "seed": seed,
                "epoch": epoch,
                "best_source_val_macro_f1": best_f1,
                "state_dict": model.state_dict(),
                "known_classes": KNOWN_CLASSES,
            }, best_path)
        else:
            patience += 1
        history.append({
            "epoch": epoch,
            "train_loss": loss,
            "source_val_macro_f1": val_f1,
            "source_val_balanced_accuracy": vm["balanced_accuracy"],
            "source_val_accuracy": vm["accuracy"],
            "lr_min": min(float(g["lr"]) for g in optimizer.param_groups),
            "lr_max": max(float(g["lr"]) for g in optimizer.param_groups),
            "improved": bool(improved),
            "patience": patience,
        })
        epoch_bar.set_postfix(
            loss=f"{loss:.4f}",
            val_f1=f"{val_f1:.4f}",
            best=f"{best_f1:.4f}@{best_epoch}",
            patience=f"{patience}/{EARLY_STOP_PATIENCE}",
            refresh=True,
        )
        if patience >= EARLY_STOP_PATIENCE:
            epoch_bar.set_description(
                f"{condition.name} | seed {seed} | early-stop@{epoch}"
            )
            break
    epoch_bar.close()

    pd.DataFrame(history).to_csv(run_dir / "history.csv", index=False)
    if not best_path.exists():
        raise RuntimeError(f"{condition.name}: no best checkpoint")
    ckpt = torch.load(best_path, map_location=device)
    model.load_state_dict(ckpt["state_dict"], strict=True)

    closed_rows, class_rows = [], []
    for domain, frame in frames.known_eval.items():
        ds = make_dataset(condition, frame, train_tf, eval_tf, tokenizer, False, True)
        loader = DataLoader(ds, **loader_kwargs(EVAL_BATCH_SIZE, shuffle=False))
        cache = predict(model, loader, device)
        met = closed_metrics(cache["y_true"], cache["probs"])
        closed_rows.append({
            "condition": condition.name,
            "family": condition.family,
            "model": condition.model_name,
            "text_col": condition.text_col or "",
            "text_encoder": condition.text_encoder or "",
            "seed": seed,
            "evaluation_mode": evaluation_mode,
            "domain": domain,
            "n": int(len(frame)),
            "best_epoch": best_epoch,
            "best_source_val_macro_f1": best_f1,
            **met,
            "isic_overlap_risk": bool("ISIC" in domain and condition.model_name == "dermlip_vitb16"),
        })
        class_rows.extend(per_class_rows(cache["y_true"], cache["probs"], condition, seed, domain))

    pd.DataFrame(closed_rows).to_csv(metrics_path, index=False)
    pd.DataFrame(class_rows).to_csv(run_dir / "per_class_metrics.csv", index=False)

    # Integrated open-world metrics use the SAME frozen DermLIP-MCM rejector for
    # every known-class classifier.  This is secondary end-to-end evaluation.
    threshold, ood_scores = prepare_ood_cache(root, output_root, frames, v8)
    open_rows = []
    for domain, frame in frames.open_eval.items():
        # Unknown rows do not have a six-class training label; classifier labels
        # are omitted from the Dataset but known-class probabilities are produced.
        ds = make_dataset(condition, frame, train_tf, eval_tf, tokenizer, False, False)
        loader = DataLoader(ds, **loader_kwargs(EVAL_BATCH_SIZE, shuffle=False))
        cache = predict(model, loader, device)
        y_open = make_open_targets(frame)
        score = ood_scores[domain]
        if len(score) != len(frame):
            raise RuntimeError(f"OOD alignment failure {domain}: {len(score)} != {len(frame)}")
        met = open_metrics(y_open, cache["probs"], score, threshold)
        open_rows.append({
            "condition": condition.name,
            "family": condition.family,
            "model": condition.model_name,
            "text_col": condition.text_col or "",
            "text_encoder": condition.text_encoder or "",
            "seed": seed,
            "evaluation_mode": evaluation_mode,
            "domain": domain,
            "n": int(len(frame)),
            "n_known": int((y_open != UNKNOWN_ID).sum()),
            "n_unknown": int((y_open == UNKNOWN_ID).sum()),
            "ood_model": OOD_MODEL,
            "ood_threshold_source_val_q95": threshold,
            **met,
            "isic_ood_overlap_risk": bool("ISIC" in domain),
        })
    pd.DataFrame(open_rows).to_csv(run_dir / "open_metrics.csv", index=False)

    jdump({
        "protocol": "F0_v3_backbone_metadata_benchmark",
        "condition": condition.__dict__,
        "seed": seed,
        "evaluation_mode": evaluation_mode,
        "source_gradient_updates": "PAD source_train only",
        "checkpoint_selection": "PAD source_val Macro-F1 only",
        "pretrained_initialization": True,
        "total_parameters": int(n_params),
        "trainable_parameters": int(n_trainable),
        "source_train_class_counts": source_counts.tolist(),
        "optimizer_audit": opt_audit,
        "loss": "effective-number weighted cross entropy",
        "balance_beta": BALANCE_BETA,
        "augmentation": "strong-no-blur for image-containing conditions; none for metadata-only",
        "dataloader_workers": int(RUNTIME_NUM_WORKERS),
        "v8_import_mode": V8_IMPORT_MODE,
        "best_epoch": best_epoch,
        "best_source_val_macro_f1": best_f1,
        "target_optimization": False,
        "table2_loader_script": str(table2_path),
        "v8_loader_script": str(v8_path),
        "openworld_rejector": {
            "model": OOD_MODEL,
            "score": "MCM",
            "threshold": "PAD source_val q95",
            "role": "common frozen rejector; secondary integrated evaluation",
        },
    }, run_dir / "run_manifest.json")

    del model, optimizer, scheduler, bundle
    cleanup_cuda()


# =============================================================================
# AGGREGATION
# =============================================================================

def aggregate(output_root: Path, conditions: List[Condition], evaluation_mode: str, table2_path: Path, v8_path: Path):
    closed_parts, open_parts, class_parts, manifests = [], [], [], []
    for c in conditions:
        for seed in SEEDS:
            d = output_root / "children" / c.name / f"seed_{seed}"
            for fn, bag in [
                ("closed_metrics.csv", closed_parts),
                ("open_metrics.csv", open_parts),
                ("per_class_metrics.csv", class_parts),
            ]:
                p = d / fn
                if not p.exists():
                    raise FileNotFoundError(f"Missing completed run output: {p}")
                bag.append(pd.read_csv(p))
            mp = d / "run_manifest.json"
            manifests.append(json.loads(mp.read_text(encoding="utf-8")))

    closed = pd.concat(closed_parts, ignore_index=True)
    opened = pd.concat(open_parts, ignore_index=True)
    pcs = pd.concat(class_parts, ignore_index=True)
    closed.to_csv(output_root / "f0_closed_metrics_all.csv", index=False)
    opened.to_csv(output_root / "f0_open_metrics_all.csv", index=False)
    pcs.to_csv(output_root / "f0_per_class_metrics_all.csv", index=False)

    closed_metric_cols = [
        "macro_f1", "balanced_accuracy", "accuracy", "macro_precision", "macro_recall", "macro_auroc_ovr"
    ]
    closed_agg = closed.groupby(
        ["condition", "family", "model", "text_col", "text_encoder", "domain"], dropna=False, as_index=False
    )[closed_metric_cols].agg(["mean", "std"])
    closed_agg.columns = ["_".join([x for x in col if x]).rstrip("_") for col in closed_agg.columns.to_flat_index()]
    closed_agg.to_csv(output_root / "f0_closed_mean_std.csv", index=False)

    open_metric_cols = [
        "open_macro_f1", "hos", "os_star", "unknown_recall", "oscr_auc",
        "ood_auroc", "aupr_out", "aupr_in", "fpr95", "known_false_reject_fraction",
        "predicted_unknown_fraction",
    ]
    open_agg = opened.groupby(
        ["condition", "family", "model", "text_col", "text_encoder", "domain"], dropna=False, as_index=False
    )[open_metric_cols].agg(["mean", "std"])
    open_agg.columns = ["_".join([x for x in col if x]).rstrip("_") for col in open_agg.columns.to_flat_index()]
    open_agg.to_csv(output_root / "f0_open_mean_std.csv", index=False)

    # Equal-domain means are summary conveniences, never substitutes for the
    # domain-specific table.  Exclude PAD source from external mean.
    external_closed = closed[~closed["domain"].eq("PAD_source_test")].copy()
    per_seed = external_closed.groupby(
        ["condition", "family", "model", "text_col", "text_encoder", "seed"], dropna=False, as_index=False
    ).agg(
        external_macro_f1=("macro_f1", "mean"),
        external_balanced_accuracy=("balanced_accuracy", "mean"),
    )
    summary = per_seed.groupby(
        ["condition", "family", "model", "text_col", "text_encoder"], dropna=False, as_index=False
    ).agg(
        n_seeds=("seed", "nunique"),
        external_macro_f1_mean=("external_macro_f1", "mean"),
        external_macro_f1_std=("external_macro_f1", "std"),
        external_balanced_accuracy_mean=("external_balanced_accuracy", "mean"),
        external_balanced_accuracy_std=("external_balanced_accuracy", "std"),
    ).sort_values("external_macro_f1_mean", ascending=False)
    summary.to_csv(output_root / "f0_condition_summary.csv", index=False)

    manifest = {
        "protocol": "F0_v3_backbone_metadata_benchmark",
        "scientific_decomposition": {
            "image_backbones": IMAGE_MODELS,
            "metadata_views": TEXT_VARIANTS,
            "native_vlm_models": sorted(NATIVE_VLM_MODELS),
            "non_vlm_models_using_bioclinicalbert": sorted(EXTERNAL_TEXT_MODELS),
            "metadata_only_encoders": [
                "BioClinicalBERT shared baseline",
                "MONET native text",
                "BiomedCLIP native text",
                "DermLIP native text",
            ],
            "multimodal_rule": (
                "MONET/BiomedCLIP/DermLIP use their own native text towers; "
                "PanDerm/DINOv2/MobileViT use BioClinicalBERT"
            ),
        },
        "evaluation_mode": evaluation_mode,
        "final_test_labels_read": evaluation_mode == "final_test",
        "seeds": SEEDS,
        "conditions": [c.__dict__ for c in conditions],
        "primary_closed_metrics": ["Macro-F1", "Balanced Accuracy"],
        "secondary_closed_metrics": ["Accuracy", "Macro AUROC OvR", "Macro Precision", "Macro Recall"],
        "primary_open_metrics": ["Open Macro-F1", "HOS"],
        "secondary_open_metrics": [
            "OS*", "Unknown Recall", "OSCR-AUC", "OOD AUROC", "AUPR-OUT", "AUPR-IN", "FPR95", "Known FR"
        ],
        "openworld_rejector": {
            "model": OOD_MODEL,
            "prompt": OOD_PROMPT_TEMPLATE,
            "score": "MCM",
            "threshold": "PAD source_val q95",
            "shared_across_all_classifiers": True,
            "isic_overlap_risk": True,
        },
        "selection_rule": "PAD source_val Macro-F1 only",
        "target_optimization": False,
        "table2_loader_script": str(table2_path),
        "table2_loader_sha256": sha256_file(table2_path),
        "v8_loader_script": str(v8_path),
        "v8_loader_sha256": sha256_file(v8_path),
        "run_manifests": manifests,
    }
    jdump(manifest, output_root / "f0_manifest.json")

    print("\n" + "=" * 120)
    print("F0 v3 — CONDITION SUMMARY (equal-domain external development/test mean)")
    print("=" * 120)
    print(summary.to_string(index=False))


# =============================================================================
# PREFLIGHT / ORCHESTRATION
# =============================================================================

def weight_and_dependency_plan(root: Path, conditions: List[Condition]):
    """Describe/validate how every requested pretrained component is obtained."""
    requested_models = {c.model_name for c in conditions}
    requested_text_encoders = {c.text_encoder for c in conditions if c.text_encoder}
    # The shared open-world evaluation always uses DermLIP-B/16 as the frozen OOD rejector.
    requested_models.add(OOD_MODEL)

    panderm_repo = root / "external_models" / "PanDerm"
    panderm_classification = panderm_repo / "classification"
    panderm_ckpt = panderm_repo / "weights" / "panderm_bb_data6_checkpoint-499.pth"

    plan = {
        "dinov2_vitb14": {
            "required": "dinov2_vitb14" in requested_models,
            "pretrained": True,
            "acquisition": "automatic",
            "loader": "torch.hub.load('facebookresearch/dinov2','dinov2_vitb14')",
            "manual_download": False,
        },
        "panderm_base": {
            "required": "panderm_base" in requested_models,
            "pretrained": True,
            "acquisition": "local official repository + local official checkpoint",
            "repo_path": str(panderm_repo),
            "checkpoint_path": str(panderm_ckpt),
            "repo_present": panderm_classification.exists(),
            "checkpoint_present": panderm_ckpt.exists(),
            "manual_download": True,
        },
        "monet": {
            "required": "monet" in requested_models,
            "pretrained": True,
            "acquisition": "automatic Hugging Face download/cache",
            "model_id": "suinleelab/monet",
            "manual_download": False,
        },
        "biomedclip": {
            "required": "biomedclip" in requested_models,
            "pretrained": True,
            "acquisition": "automatic Hugging Face download/cache through OpenCLIP",
            "model_id": "microsoft/BiomedCLIP-PubMedBERT_256-vit_base_patch16_224",
            "manual_download": False,
        },
        "dermlip_vitb16": {
            "required": "dermlip_vitb16" in requested_models,
            "pretrained": True,
            "acquisition": "Derm1M repository auto-cloned if absent; checkpoint auto-downloaded/cached from Hugging Face",
            "model_id": "redlessone/DermLIP_ViT-B-16",
            "manual_download": False,
            "note": "Requires git and the Derm1M repository-bundled open_clip implementation.",
        },
        "mobilevit": {
            "required": "mobilevit" in requested_models,
            "pretrained": True,
            "acquisition": "automatic through the existing Table-2 timm pretrained=True loader/cache",
            "manual_download": False,
        },
        "bioclinicalbert": {
            "required": "bioclinicalbert" in requested_text_encoders or "mobilevit" in requested_models,
            "pretrained": True,
            "acquisition": "automatic Hugging Face download/cache",
            "model_id": BIOCLINICAL_MODEL,
            "manual_download": False,
        },
    }

    if plan["panderm_base"]["required"]:
        if not panderm_classification.exists():
            raise FileNotFoundError(
                "Missing official PanDerm repository/classification directory: "
                f"{panderm_classification}. Clone https://github.com/SiyuanYan1/PanDerm "
                f"to {panderm_repo}."
            )
        if not panderm_ckpt.exists():
            raise FileNotFoundError(
                "Missing PanDerm Base pretrained checkpoint: "
                f"{panderm_ckpt}. Download the official PanDerm_Base weight "
                "panderm_bb_data6_checkpoint-499.pth and place it there."
            )

    # Fail early on Python dependencies for conditions actually requested.
    missing = []
    if plan["mobilevit"]["required"]:
        try:
            import timm  # noqa: F401
        except Exception:
            missing.append("timm")
    if plan["monet"]["required"] or plan["bioclinicalbert"]["required"]:
        try:
            import transformers  # noqa: F401
        except Exception:
            missing.append("transformers")
    if plan["biomedclip"]["required"]:
        try:
            import open_clip  # noqa: F401
        except Exception:
            missing.append("open_clip_torch")
    if missing:
        raise RuntimeError("Missing required Python package(s): " + ", ".join(sorted(set(missing))))

    return plan


def preflight(root: Path, output_root: Path, evaluation_mode: str, conditions: List[Condition], confirm_method_frozen: bool):
    if evaluation_mode == "final_test" and not confirm_method_frozen:
        raise RuntimeError(
            "Refusing to read target-test labels while methods are still being compared. "
            "If and only if the condition/model set is frozen, rerun with: "
            "--evaluation-mode final_test --confirm-method-frozen"
        )

    frames, t2, table2_path = load_study_frames(root, evaluation_mode)
    v8_path = find_v8_script(root)
    v2_manifest = root / "preprocessed_outputs_openworld_v2_1_final" / "protocol_manifest_v2_1.json"
    v3_manifest = root / "preprocessed_outputs_midas_v3_1_final" / "midas_protocol_manifest_v3_1.json"
    with v2_manifest.open("r", encoding="utf-8") as f: v2 = json.load(f)
    with v3_manifest.open("r", encoding="utf-8") as f: v3 = json.load(f)
    if v2.get("protocol_name") != "openworld_v2_1_final" or not v2.get("final_frozen_protocol", False):
        raise RuntimeError("OpenWorld V2.1 is not final/frozen")
    if v3.get("protocol") != "mra_midas_v3_1_final" or not v3.get("final_frozen_protocol", False):
        raise RuntimeError("MIDAS V3.1 is not final/frozen")

    # Model-weight/dependency preflight. Remote public weights are downloaded by
    # their official loaders and cached; PanDerm is the one model that requires
    # an explicit local repository + checkpoint in this study setup.
    weight_plan = weight_and_dependency_plan(root, conditions)

    report = {
        "status": "PASS",
        "protocol": "F0_v3_backbone_metadata_benchmark",
        "root": str(root),
        "evaluation_mode": evaluation_mode,
        "final_test_guard_confirmed": bool(confirm_method_frozen),
        "conditions": [c.__dict__ for c in conditions],
        "seeds": SEEDS,
        "pretrained_weight_plan": weight_plan,
        "gpu_isolation": {
            "one_fresh_python_subprocess_per_condition_seed": True,
            "hard_reset": "CUDA context is destroyed when each child process exits",
            "in_process_cleanup": "del model/optimizer + gc.collect + cuda synchronize/empty_cache/ipc_collect",
            "persistent_dataloader_workers": PERSISTENT_WORKERS,
            "note": "Persistent workers improve epoch throughput but terminate with the child process before the next seed.",
        },
        "source_rows": {
            "train": len(frames.source_train), "val": len(frames.source_val), "test": len(frames.source_test)
        },
        "known_eval_rows": {k: len(v) for k, v in frames.known_eval.items()},
        "open_eval_rows": {k: len(v) for k, v in frames.open_eval.items()},
        "openworld_membership_sha256": v2.get("membership_sha256"),
        "openworld_semantic_sha256": v2.get("semantic_sha256"),
        "midas_lesion_semantic_sha256": v3.get("lesion_semantic_sha256"),
        "table2_script": str(table2_path),
        "v8_script": str(v8_path),
        "metadata_only_rule": (
            "BioClinicalBERT is the shared text-only baseline for non-VLMs; "
            "MONET/BiomedCLIP/DermLIP additionally use their own native text encoders"
        ),
        "vlm_metadata_rule": (
            "Self-sufficient VLMs use native text directly; BioClinicalBERT is not inserted into them"
        ),
        "non_vlm_multimodal_rule": (
            "PanDerm/DINOv2/MobileViT use BioClinicalBERT whenever text is required"
        ),
        "metrics": {
            "closed_primary": ["macro_f1", "balanced_accuracy"],
            "closed_secondary": ["accuracy", "macro_auroc_ovr", "macro_precision", "macro_recall"],
            "open_primary": ["open_macro_f1", "hos"],
            "open_secondary": ["os_star", "unknown_recall", "oscr_auc", "ood_auroc", "aupr_out", "aupr_in", "fpr95", "known_false_reject_fraction"],
        },
    }
    output_root.mkdir(parents=True, exist_ok=True)
    jdump(report, output_root / "f0_preflight.json")
    print(json.dumps(report, indent=2))
    return frames, t2, table2_path, v8_path


def self_test():
    # Metric-level regression checks independent of external model downloads.
    y = np.asarray([0, 1, 2, 3, 4, 5] * 3)
    probs = np.eye(6, dtype=float)[y] * 0.9 + 0.1 / 6
    cm = closed_metrics(y, probs)
    assert cm["macro_f1"] > 0.99
    assert cm["balanced_accuracy"] > 0.99

    y_open = np.asarray([0, 1, 2, 3, 4, 5, 6, 6])
    probs_open = np.vstack([np.eye(6)[i] if i < 6 else np.ones(6) / 6 for i in y_open])
    scores = np.asarray([0.1] * 6 + [0.9, 0.95])
    om = open_metrics(y_open, probs_open, scores, threshold=0.5)
    assert om["open_macro_f1"] > 0.99
    assert om["unknown_recall"] == 1.0
    assert om["oscr_auc"] > 0.99
    print("F0-v3 SELF-TEST PASSED")
    print(json.dumps({"closed": cm, "open": om}, indent=2))


def parse_csv_arg(value: Optional[str]) -> Optional[List[str]]:
    if not value:
        return None
    return [x.strip() for x in value.split(",") if x.strip()]


def completed_run_files(run_dir: Path) -> List[Path]:
    """Files that define a scientifically complete condition/seed run."""
    return [
        run_dir / "closed_metrics.csv",
        run_dir / "open_metrics.csv",
        run_dir / "per_class_metrics.csv",
        run_dir / "run_manifest.json",
        run_dir / "history.csv",
        run_dir / "best.pt",
    ]


def is_run_complete(run_dir: Path) -> bool:
    return all(p.exists() for p in completed_run_files(run_dir))


def orchestrate(args):
    root = Path(args.root)

    # Family selection supports both the original --families interface and
    # convenient shortcut flags such as --metadata.  When shortcuts are used,
    # they are unioned with anything supplied through --families.
    requested_families = []
    explicit = parse_csv_arg(args.families) or []
    requested_families.extend(explicit)
    if getattr(args, "image", False):
        requested_families.append("image")
    if getattr(args, "metadata", False):
        requested_families.append("metadata")
    if getattr(args, "multimodal", False):
        requested_families.append("multimodal")

    if requested_families:
        # Preserve canonical family order and remove duplicates.
        families = [f for f in FAMILIES if f in set(requested_families)]
    else:
        families = list(FAMILIES)

    bad = [x for x in requested_families if x not in FAMILIES]
    if bad:
        raise ValueError(f"Unknown families {bad}; allowed={FAMILIES}")

    names = parse_csv_arg(args.conditions)
    conditions = select_conditions(families, names)

    output_root = root / "results_f0_backbone_metadata_benchmark" / args.evaluation_mode
    _, _, table2_path, v8_path = preflight(
        root, output_root, args.evaluation_mode, conditions, args.confirm_method_frozen
    )
    if args.preflight_only:
        return

    script = Path(__file__).resolve()
    jobs = [(c, seed) for c in conditions for seed in SEEDS]

    completed_before = 0
    pending = []
    for c, seed in jobs:
        run_dir = output_root / "children" / c.name / f"seed_{seed}"
        if is_run_complete(run_dir) and not args.force_runs:
            completed_before += 1
        else:
            pending.append((c, seed))

    print(
        f"[F0-v3] Resume summary: {completed_before}/{len(jobs)} runs already complete; "
        f"{len(pending)} remaining.",
        flush=True,
    )

    overall = tqdm(
        total=len(jobs),
        initial=completed_before,
        desc="F0-v3 total runs",
        unit="run",
        dynamic_ncols=True,
        leave=True,
    )

    try:
        # Report skipped jobs without replaying them. tqdm's initial counter already
        # includes these in the overall completion percentage.
        if completed_before and not args.force_runs:
            tqdm.write(f"[F0-v3] Skipping {completed_before} fully completed condition/seed runs.")

        for c, seed in pending:
            run_dir = output_root / "children" / c.name / f"seed_{seed}"

            # If an earlier run crashed after writing only some outputs, do not treat
            # it as complete. Re-running this child safely rebuilds the incomplete run.
            partial = [p.name for p in completed_run_files(run_dir) if p.exists()]
            if partial:
                tqdm.write(
                    f"[F0-v3] Incomplete prior run detected for {c.name}/seed{seed}; "
                    f"existing={partial}. Re-running it."
                )

            overall.set_postfix_str(f"next={c.name}/seed{seed}", refresh=True)
            cmd = [
                sys.executable, str(script),
                "--root", str(root),
                "--evaluation-mode", args.evaluation_mode,
                "--child-condition", c.name,
                "--child-seed", str(seed),
            ]
            if args.confirm_method_frozen:
                cmd.append("--confirm-method-frozen")
            if args.force_runs:
                cmd.append("--force-runs")

            tqdm.write("\n[F0-v3] Launch: " + " ".join(cmd))
            subprocess.check_call(cmd)

            # Require the child to have produced all final artifacts before the
            # parent counts it as completed. This prevents a partial/crashed run
            # from being skipped on resume.
            if not is_run_complete(run_dir):
                missing = [
                    p.name for p in completed_run_files(run_dir) if not p.exists()
                ]
                raise RuntimeError(
                    f"Child exited but run is incomplete: {c.name}/seed{seed}; "
                    f"missing={missing}"
                )

            overall.update(1)
            overall.set_postfix_str(f"done={c.name}/seed{seed}", refresh=True)
            tqdm.write(
                f"[F0-v3] Completed {c.name}/seed{seed}; "
                "child exited, GPU context reset."
            )
    finally:
        overall.close()

    aggregate(output_root, conditions, args.evaluation_mode, table2_path, v8_path)


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=str(DEFAULT_ROOT))
    ap.add_argument("--evaluation-mode", choices=["development", "final_test"], default="development")
    ap.add_argument("--confirm-method-frozen", action="store_true")
    ap.add_argument(
        "--families",
        default=None,
        help="Comma-separated subset: image,metadata,multimodal",
    )
    # Convenience aliases.  Examples:
    #   --metadata
    #   --image
    #   --multimodal
    #   --image --multimodal
    ap.add_argument("--image", action="store_true", help="Shortcut for --families image")
    ap.add_argument("--metadata", action="store_true", help="Shortcut for --families metadata")
    ap.add_argument("--multimodal", action="store_true", help="Shortcut for --families multimodal")
    ap.add_argument("--conditions", default=None, help="Comma-separated exact condition names; overrides family filtering")
    ap.add_argument("--preflight-only", action="store_true")
    ap.add_argument("--force-runs", action="store_true")
    ap.add_argument("--child-condition", default=None, choices=list(condition_map()))
    ap.add_argument("--child-seed", type=int, default=None, choices=SEEDS)
    ap.add_argument("--self-test", action="store_true")
    return ap.parse_args()


def main():
    args = parse_args()
    if args.self_test:
        self_test(); return

    root = Path(args.root)
    output_root = root / "results_f0_backbone_metadata_benchmark" / args.evaluation_mode

    if args.child_condition is not None:
        if args.child_seed is None:
            raise ValueError("--child-seed required with --child-condition")
        if args.evaluation_mode == "final_test" and not args.confirm_method_frozen:
            raise RuntimeError("final_test child requires --confirm-method-frozen")
        c = condition_map()[args.child_condition]
        run_one_seed(
            root, output_root, c, args.child_seed, args.evaluation_mode, force=args.force_runs
        )
        return

    orchestrate(args)


if __name__ == "__main__":
    main()
