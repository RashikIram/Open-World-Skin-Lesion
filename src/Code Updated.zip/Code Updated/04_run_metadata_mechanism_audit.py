#!/usr/bin/env python
from __future__ import annotations

"""
04 — METADATA MECHANISM AUDIT ON F0-v3 PAN-DERM REPRESENTATIONS
===============================================================

Run this BEFORE designing the new method.

Questions
---------
1) Does metadata/fused representation encode dataset identity more strongly as
   textualization becomes richer/heterogeneous?
2) How much class information is present in frozen image/text/fused spaces under
   source->external kNN and linear probing?
3) Holding the image fixed, how sensitive are predictions to controlled
   single-field removals and metadata-field swaps?
4) Are Full / Explicit-missingness views substantially more unstable than Age /
   Shared, supporting the source-specific metadata-reliance hypothesis?

Data / preprocessing
--------------------
This script imports the already-run F0-v3 script and therefore uses exactly:
  * OpenWorld V2.1 source/ISIC/MCR preprocessing
  * MIDAS V3.1 external cohorts
  * the six frozen textualization columns
  * F0 PanDerm+BioClinicalBERT same-seed checkpoints
  * the F0 PanDerm transform and normalization

NO old preprocessing file is read.

Outputs
-------
results_04_metadata_mechanism_audit_v21/
    representation_transfer.csv
    domain_predictability.csv
    counterfactual_field_audit.csv
    representation_summary.csv
    audit_manifest.json
"""

import argparse
import gc
import importlib
import importlib.util
import io
import json
import os
import random
import sys
from contextlib import redirect_stdout
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from PIL import Image
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score, f1_score
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from torch.utils.data import DataLoader
from tqdm.auto import tqdm


DEFAULT_ROOT = Path(r"C:\Users\Nebula PC\Downloads\Deep Learning")
SEEDS = [42, 123, 2026]
VIEWS = ["age", "location", "shared_robust", "core", "full", "missing_explicit"]

FIELD_LABELS = [
    ("std_age", "age group"),
    ("std_sex", "sex"),
    ("std_location", "anatomical site"),
    ("std_diameter", "lesion diameter"),
    ("std_fitzpatrick", "Fitzpatrick type"),
    ("std_itch", "itching"),
    ("std_grew", "growth"),
    ("std_hurt", "pain"),
    ("std_changed", "change"),
    ("std_bleed", "bleeding"),
    ("std_elevation", "elevation"),
    ("std_personal_skin_cancer_history", "personal skin cancer history"),
    ("std_family_skin_cancer_history", "family skin cancer history"),
    ("std_general_cancer_history", "general cancer history"),
    ("std_smoking", "smoking"),
    ("std_alcohol", "alcohol"),
    ("std_pesticide_exposure", "pesticide exposure"),
    ("std_sunbed_use", "sunbed use"),
    ("std_organ_transplant", "organ transplant"),
    ("std_immunosuppression", "immunosuppression"),
    ("std_natural_hair_color", "natural hair color"),
    ("std_skin_reaction_to_sun", "skin reaction to sun"),
    ("std_moles_body_18", "moles on body at age 18"),
    ("std_moles_bigger_5mm", "moles larger than 5 mm"),
    ("std_moles_bigger_20cm", "moles field bigger 20 cm"),
    ("std_moles_body", "moles on body"),
    ("std_sunburn_number_group", "sunburn count group"),
]
FIELD_TO_LABEL = dict(FIELD_LABELS)
FULL_FIELDS = [x[0] for x in FIELD_LABELS]
VIEW_FIELDS = {
    "age": ["std_age"],
    "location": ["std_location"],
    "shared_robust": ["std_age", "std_location"],
    "core": ["std_age", "std_sex", "std_location"],
    "full": FULL_FIELDS,
    "missing_explicit": FULL_FIELDS,
}


def jdump(obj, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    def cv(x):
        if isinstance(x, Path): return str(x)
        if isinstance(x, (np.integer,)): return int(x)
        if isinstance(x, (np.floating,)):
            v=float(x); return None if not np.isfinite(v) else v
        if isinstance(x, np.ndarray): return x.tolist()
        if isinstance(x, dict): return {str(k):cv(v) for k,v in x.items()}
        if isinstance(x, (list,tuple)): return [cv(v) for v in x]
        return x
    path.write_text(json.dumps(cv(obj), indent=2), encoding="utf-8")


def set_seed(seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)


def cleanup():
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        try: torch.cuda.ipc_collect()
        except Exception: pass


def discover_f0(root: Path) -> Path:
    p=root/"run_f0_foundation_representation_sanity.py"
    if p.exists(): return p
    hits=sorted(root.glob("run_f0_foundation_representation_sanity*.py"))
    if not hits: raise FileNotFoundError("F0-v3 script not found in project root")
    return hits[0]


def import_f0(root: Path):
    p=discover_f0(root).resolve()
    if str(p.parent) not in sys.path: sys.path.insert(0,str(p.parent))
    if p.stem.isidentifier():
        importlib.invalidate_caches(); m=importlib.import_module(p.stem)
    else:
        spec=importlib.util.spec_from_file_location("f0_v3_runtime",p)
        m=importlib.util.module_from_spec(spec); sys.modules["f0_v3_runtime"]=m; spec.loader.exec_module(m)
        if os.name=="nt": m.RUNTIME_NUM_WORKERS=0
    return m,p


def ckpt_path(root, view, seed):
    return (root/"results_f0_backbone_metadata_benchmark"/"development"/"children"/
            f"multimodal__panderm_base__{view}"/f"seed_{seed}"/"best.pt")


def is_missing(x):
    if pd.isna(x): return True
    return str(x).strip().lower() in {"","nan","none","null","unknown","n/a","na"}


def clean_std(x):
    return "unknown" if is_missing(x) else str(x).strip().lower()


def build_text(row: pd.Series, fields: List[str], explicit_missing: bool) -> str:
    parts=[]
    for field in fields:
        val=clean_std(row.get(field,"unknown"))
        if val=="unknown" and not explicit_missing:
            continue
        if field=="std_age" and val!="unknown":
            val=f"{val} years"
        parts.append(f"{FIELD_TO_LABEL[field]}: {val}")
    return "Patient metadata unavailable." if not parts else "Patient metadata: "+"; ".join(parts)+"."


def move_batch(batch, device):
    return {k:(v.to(device,non_blocking=torch.cuda.is_available()) if torch.is_tensor(v) else v)
            for k,v in batch.items()}


@torch.no_grad()
def extract_representations(f0, model, loader, device):
    model.eval()
    imgs=[]; txts=[]; fused=[]; probs=[]; ys=[]; idx=[]
    for batch in loader:
        idx.append(batch["index"].numpy())
        b=move_batch(batch,device)
        zi=f0._encode_image_native(model.backbone, model.image_feature_kind, b["pixel_values"])
        tout=model.text_encoder(input_ids=b["input_ids"],attention_mask=b["attention_mask"])
        zt=getattr(tout,"pooler_output",None)
        if zt is None: zt=tout.last_hidden_state[:,0]
        zf=torch.cat([model.image_proj(zi),model.text_proj(zt)],dim=-1)
        logits=model.classifier(model.dropout(zf))
        imgs.append(zi.float().cpu().numpy())
        txts.append(zt.float().cpu().numpy())
        fused.append(zf.float().cpu().numpy())
        probs.append(F.softmax(logits.float(),dim=1).cpu().numpy())
        if "label" in batch: ys.append(batch["label"].numpy())
    return {
        "image":np.concatenate(imgs),
        "text":np.concatenate(txts),
        "fused":np.concatenate(fused),
        "probs":np.concatenate(probs),
        "y":np.concatenate(ys).astype(int) if ys else None,
        "idx":np.concatenate(idx).astype(int),
    }


def fit_source_probes(source_cache, target_cache, domain, view, seed):
    rows=[]
    ytr=source_cache["y"]; yte=target_cache["y"]
    for rep in ["image","text","fused"]:
        Xtr=source_cache[rep]; Xte=target_cache[rep]
        for k in [1,5,15]:
            clf=KNeighborsClassifier(n_neighbors=k,metric="cosine",weights="distance")
            clf.fit(Xtr,ytr); pred=clf.predict(Xte)
            rows.append({
                "view":view,"seed":seed,"domain":domain,"representation":rep,
                "probe":f"knn{k}_cosine",
                "macro_f1":f1_score(yte,pred,average="macro",zero_division=0),
                "balanced_accuracy":balanced_accuracy_score(yte,pred),
            })
        lr=make_pipeline(
            StandardScaler(),
            LogisticRegression(max_iter=3000,class_weight="balanced",C=1.0)
        )
        lr.fit(Xtr,ytr); pred=lr.predict(Xte)
        rows.append({
            "view":view,"seed":seed,"domain":domain,"representation":rep,
            "probe":"linear_logreg",
            "macro_f1":f1_score(yte,pred,average="macro",zero_division=0),
            "balanced_accuracy":balanced_accuracy_score(yte,pred),
        })
    return rows


def domain_predictability(caches: Dict[str,dict], view, seed, max_per_domain=350):
    rng=np.random.default_rng(seed)
    domains=list(caches)
    rows=[]
    balanced_take=min(max_per_domain,min(len(caches[d]["image"]) for d in domains))
    for rep in ["image","text","fused"]:
        Xs=[]; ys=[]
        for did,d in enumerate(domains):
            X=caches[d][rep]
            take=balanced_take
            ix=rng.choice(len(X),size=take,replace=False) if len(X)>take else np.arange(len(X))
            Xs.append(X[ix]); ys.append(np.full(take,did))
        X=np.concatenate(Xs); y=np.concatenate(ys)
        cv=StratifiedKFold(n_splits=5,shuffle=True,random_state=seed)
        clf=make_pipeline(
            StandardScaler(),
            LogisticRegression(max_iter=3000,class_weight="balanced",C=1.0)
        )
        scores=cross_val_score(clf,X,y,cv=cv,scoring="balanced_accuracy",n_jobs=1)
        rows.append({
            "view":view,"seed":seed,"representation":rep,
            "n_domains":len(domains),"n_total":len(y),
            "domain_balanced_accuracy_mean":scores.mean(),
            "domain_balanced_accuracy_std":scores.std(ddof=1),
            "chance":1.0/len(domains),
        })
    return rows


def js_prob(p,q,eps=1e-8):
    p=np.clip(np.asarray(p),eps,1); q=np.clip(np.asarray(q),eps,1)
    m=.5*(p+q)
    return .5*np.sum(p*np.log(p/m),axis=1)+.5*np.sum(q*np.log(q/m),axis=1)


@torch.no_grad()
def precompute_image_projection(f0, model, eval_tf, frame, device, batch_size=64):
    """Image branch is invariant to metadata perturbations; compute it once."""
    model.eval()
    outs=[]
    for start in range(0,len(frame),batch_size):
        end=min(start+batch_size,len(frame))
        imgs=torch.stack([
            eval_tf(Image.open(p).convert("RGB"))
            for p in frame.iloc[start:end]["image_path"].tolist()
        ]).to(device)
        zi=f0._encode_image_native(model.backbone,model.image_feature_kind,imgs)
        outs.append(model.image_proj(zi).float().cpu())
    return torch.cat(outs,dim=0)

@torch.no_grad()
def predict_with_texts(f0, model, tokenizer, image_proj, texts, device, batch_size=64):
    model.eval()
    outs=[]
    for start in range(0,len(texts),batch_size):
        end=min(start+batch_size,len(texts))
        enc=tokenizer(
            [f0.safe_text(x) for x in texts[start:end]],
            padding="max_length",truncation=True,max_length=f0.MAX_TEXT_LEN,
            return_tensors="pt"
        )
        ids=enc["input_ids"].to(device); mask=enc["attention_mask"].to(device)
        tout=model.text_encoder(input_ids=ids,attention_mask=mask)
        zt=getattr(tout,"pooler_output",None)
        if zt is None:
            zt=tout.last_hidden_state[:,0]
        zt=model.text_proj(zt)
        zi=image_proj[start:end].to(device)
        fused=torch.cat([zi,zt],dim=1)
        logits=model.classifier(model.dropout(fused))
        outs.append(F.softmax(logits.float(),dim=1).cpu().numpy())
    return np.concatenate(outs)


def donor_indices(frame, field, same_class: bool, seed: int):
    """
    Choose donor rows whose FIELD VALUE is genuinely different from the
    recipient's value. Returns -1 when no valid donor exists.

    This prevents nominal "swaps" such as trunk -> trunk from being counted as
    perturbations and biasing sensitivity estimates toward zero.
    """
    rng=np.random.default_rng(seed)
    labels=frame["label_harmonized"].astype(str).to_numpy()
    vals=np.array(
        [clean_std(x) for x in (
            frame[field].to_numpy()
            if field in frame.columns
            else np.array(["unknown"]*len(frame))
        )],
        dtype=object,
    )
    out=np.full(len(frame), -1, dtype=int)
    all_idx=np.arange(len(frame))
    for i in range(len(frame)):
        different_value=(vals != vals[i])
        not_self=(all_idx != i)
        if same_class:
            eligible=(labels == labels[i]) & different_value & not_self
        else:
            eligible=(labels != labels[i]) & different_value & not_self
        cand=np.where(eligible)[0]
        if len(cand):
            out[i]=int(rng.choice(cand))
    return out


def perturbation_metrics(p0, p1, effective_mask):
    """
    Evaluate sensitivity only where the requested intervention actually changed
    the metadata value. Coverage is reported explicitly for auditability.
    """
    effective_mask=np.asarray(effective_mask, dtype=bool)
    n_total=int(len(effective_mask))
    n_effective=int(effective_mask.sum())
    coverage=float(n_effective / n_total) if n_total else float("nan")
    if n_effective == 0:
        return {
            "n": n_total,
            "n_effective": 0,
            "perturbation_coverage": coverage,
            "mean_l1_prob_shift": float("nan"),
            "mean_js_prob_shift": float("nan"),
            "top1_flip_rate": float("nan"),
        }
    a=np.asarray(p0)[effective_mask]
    b=np.asarray(p1)[effective_mask]
    return {
        "n": n_total,
        "n_effective": n_effective,
        "perturbation_coverage": coverage,
        "mean_l1_prob_shift": float(np.abs(a-b).sum(axis=1).mean()),
        "mean_js_prob_shift": float(js_prob(a,b).mean()),
        "top1_flip_rate": float((a.argmax(1) != b.argmax(1)).mean()),
    }


def counterfactual_audit(f0, model, tokenizer, eval_tf, frame, view, seed, domain, max_samples, device):
    q=frame.copy().reset_index(drop=True)
    if len(q)>max_samples:
        q=q.sample(max_samples,random_state=seed).reset_index(drop=True)
    text_col=f0.TEXT_VARIANTS[view]
    original=q[text_col].astype(str).tolist()
    image_proj=precompute_image_projection(f0,model,eval_tf,q,device)
    p0=predict_with_texts(f0,model,tokenizer,image_proj,original,device)

    rows=[]
    fields=[f for f in VIEW_FIELDS[view] if f in q.columns]
    explicit=(view=="missing_explicit")

    for field in fields:
        # A) remove exactly one field while preserving the V2.1 textualization grammar.
        removed=[]
        for _,r in q.iterrows():
            rr=r.copy(); rr[field]="unknown"
            removed.append(build_text(rr,VIEW_FIELDS[view],explicit))
        p1=predict_with_texts(f0,model,tokenizer,image_proj,removed,device)
        effective=np.array([clean_std(x)!="unknown" for x in q[field].tolist()],dtype=bool)
        rows.append({
            "view":view,"seed":seed,"domain":domain,"field":field,"perturbation":"remove_field",
            **perturbation_metrics(p0,p1,effective),
        })

        # B) same-class donor value: tests sensitivity to nuisance variation not class change.
        same=donor_indices(q,field,True,seed+101)
        texts=[]
        effective=(same>=0)
        for i,r in q.iterrows():
            rr=r.copy()
            if same[i] >= 0:
                rr[field]=q.iloc[same[i]].get(field,"unknown")
            texts.append(build_text(rr,VIEW_FIELDS[view],explicit))
        ps=predict_with_texts(f0,model,tokenizer,image_proj,texts,device)
        rows.append({
            "view":view,"seed":seed,"domain":domain,"field":field,"perturbation":"same_class_field_swap",
            **perturbation_metrics(p0,ps,effective),
        })

        # C) different-class donor value: upper-bound class-associated metadata sensitivity.
        diff=donor_indices(q,field,False,seed+202)
        texts=[]
        effective=(diff>=0)
        for i,r in q.iterrows():
            rr=r.copy()
            if diff[i] >= 0:
                rr[field]=q.iloc[diff[i]].get(field,"unknown")
            texts.append(build_text(rr,VIEW_FIELDS[view],explicit))
        pdiff=predict_with_texts(f0,model,tokenizer,image_proj,texts,device)
        rows.append({
            "view":view,"seed":seed,"domain":domain,"field":field,"perturbation":"different_class_field_swap",
            **perturbation_metrics(p0,pdiff,effective),
        })
    return rows


def load_view_model(f0,root,frames,t2,v8,view,seed,device):
    cond=f0.condition_map()[f"multimodal__panderm_base__{view}"]

    # PanDerm's official loader prints the complete VisionTransformer structure
    # every time an encoder is constructed.  That output is useful when debugging
    # the loader itself but overwhelms this 18-condition audit.  Suppress only
    # ordinary stdout from model construction; Python warnings/errors on stderr
    # remain visible.  No model/preprocessing/scientific behavior is changed.
    with redirect_stdout(io.StringIO()):
        model,opt,train_tf,eval_tf,tok,bundle,audit=f0.build_condition_model(
            root,t2,v8,cond,seed,device,frames.source_train
        )
    del opt
    p=ckpt_path(root,view,seed)
    if not p.exists(): raise FileNotFoundError(p)
    payload=torch.load(p,map_location=device)
    model.load_state_dict(payload.get("state_dict",payload),strict=True)
    model.eval()
    return cond,model,eval_tf,tok,bundle,p


def make_eval_loader(f0,cond,frame,eval_tf,tok,batch=64):
    ds=f0.make_dataset(cond,frame,None,eval_tf,tok,False,True)
    return DataLoader(ds,**f0.loader_kwargs(batch,shuffle=False))


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--root",type=Path,default=DEFAULT_ROOT)
    ap.add_argument("--views",default=",".join(VIEWS))
    ap.add_argument("--seeds",default="42,123,2026")
    ap.add_argument("--max-cf-samples",type=int,default=300)
    ap.add_argument("--max-domain-samples",type=int,default=350)
    ap.add_argument("--force",action="store_true")
    args=ap.parse_args()
    root=args.root.resolve()
    views=[x.strip() for x in args.views.split(",") if x.strip()]
    seeds=[int(x) for x in args.seeds.split(",") if x.strip()]
    for v in views:
        if v not in VIEWS: raise ValueError(v)

    out=root/"results_04_metadata_mechanism_audit_v21"
    out.mkdir(parents=True,exist_ok=True)
    f0,f0_path=import_f0(root)
    frames,t2,table2=f0.load_study_frames(root,"development")
    v8,v8_path=f0.import_v8(root)
    device=torch.device("cuda" if torch.cuda.is_available() else "cpu")

    transfer_rows=[]; domain_rows=[]; cf_rows=[]
    jobs=[(view,seed) for view in views for seed in seeds]
    overall=tqdm(
        jobs,
        total=len(jobs),
        desc="04 mechanism audit",
        unit="condition",
        dynamic_ncols=True,
        leave=True,
        position=0,
    )
    for view,seed in overall:
        overall.set_postfix_str(f"current={view}/seed{seed}",refresh=True)
        set_seed(seed)
        cond,model,eval_tf,tok,bundle,p=load_view_model(f0,root,frames,t2,v8,view,seed,device)
        source_loader=make_eval_loader(f0,cond,frames.source_train,eval_tf,tok)
        source_cache=extract_representations(f0,model,source_loader,device)

        eval_caches={}
        domain_bar=tqdm(
            frames.known_eval.items(),
            total=len(frames.known_eval),
            desc=f"04 {view}/s{seed} domains",
            unit="domain",
            dynamic_ncols=True,
            leave=False,
            position=1,
        )
        for domain,frame in domain_bar:
            domain_bar.set_postfix_str(str(domain),refresh=False)
            loader=make_eval_loader(f0,cond,frame,eval_tf,tok)
            c=extract_representations(f0,model,loader,device)
            eval_caches[domain]=c
            transfer_rows.extend(fit_source_probes(source_cache,c,domain,view,seed))
            cf_rows.extend(counterfactual_audit(
                f0,model,tok,eval_tf,frame,view,seed,domain,args.max_cf_samples,device
            ))

        # Domain predictability uses held-out known cohorts, balanced per domain.
        domain_rows.extend(domain_predictability(
            eval_caches,view,seed,args.max_domain_samples
        ))
        del model,bundle,source_cache,eval_caches
        cleanup()

    pd.DataFrame(transfer_rows).to_csv(out/"representation_transfer.csv",index=False)
    pd.DataFrame(domain_rows).to_csv(out/"domain_predictability.csv",index=False)
    pd.DataFrame(cf_rows).to_csv(out/"counterfactual_field_audit.csv",index=False)

    summary=[]
    if transfer_rows:
        t=pd.DataFrame(transfer_rows)
        s=t.groupby(["view","representation","probe"])[["macro_f1","balanced_accuracy"]].mean().reset_index()
        s["section"]="representation_transfer"; summary.append(s)
    if domain_rows:
        d=pd.DataFrame(domain_rows)
        s=d.groupby(["view","representation"])[["domain_balanced_accuracy_mean"]].mean().reset_index()
        s["section"]="domain_predictability"; summary.append(s)
    if cf_rows:
        c=pd.DataFrame(cf_rows)
        s=c.groupby(["view","perturbation"])[["perturbation_coverage","mean_l1_prob_shift","mean_js_prob_shift","top1_flip_rate"]].mean().reset_index()
        s["section"]="counterfactual"; summary.append(s)
    if summary:
        pd.concat(summary,ignore_index=True,sort=False).to_csv(out/"representation_summary.csv",index=False)

    jdump({
        "protocol":"04_metadata_mechanism_audit_v21",
        "f0_script":f0_path,
        "table2_loader":table2,
        "v8_loader":v8_path,
        "evaluation_mode":"development only",
        "views":views,
        "seeds":seeds,
        "max_counterfactual_samples_per_domain":args.max_cf_samples,
        "controlled_metadata_perturbations":[
            "single-field removal (available fields only)",
            "same-class different-value field swap",
            "different-class different-value field swap",
        ],
        "representations":["PanDerm raw image embedding","BioClinicalBERT pooled text embedding","projected fused embedding"],
        "probe_training":"source PAD train only for class transfer; balanced 5-fold CV for domain identity",
        "target_test_read":False,
    },out/"audit_manifest.json")
    print(f"[04] complete -> {out}")


if __name__=="__main__":
    main()
