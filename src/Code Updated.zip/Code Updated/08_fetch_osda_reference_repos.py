#!/usr/bin/env python3
"""Fetch and audit DA reference repositories relevant to the skin-lesion study.

This is a *reference-code fetcher*, not a DA trainer or OOD evaluator. It clones
official/relevant repositories at their current default branch, records the
resolved commit SHA, and labels which experimental protocol each method assumes.
It does not install dependencies, download datasets/weights, adapt PanDerm, or
evaluate OOD scores.

The main-study candidates are source-aware OSDA/UniDA methods. Source-free
methods are included in the comprehensive catalogue, but must be evaluated in a
separate source-free protocol; their scores must not be presented as matched
against source-aware DANN/UADAL/OSBP results.

Run in the Windows (pytorch) environment:
    python 08_fetch_osda_reference_repos.py --dest "external_da_refs"

Use --list-only to inspect the catalogue without cloning. Use repeated --group
to fetch a subset, for example:
    python 08_fetch_osda_reference_repos.py --group source-aware --group source-free-open-set

Repositories are cloned shallowly and never overwritten or updated. The exact
HEAD commit is written to da_repositories_manifest.json for reproducibility.
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional


# `required` verifies the repository has its main entry points. `required_any`
# is used where upstream layouts have moved or multiple supported entry points
# are documented. The README and commit SHA are always recorded as provenance.
REPOSITORIES = [
    {
        "name": "UADAL",
        "url": "https://github.com/JoonHo-Jang/UADAL.git",
        "group": "source-aware",
        "paper": "Jang et al., Unknown-Aware Domain Adversarial Learning for Open-Set Domain Adaptation, NeurIPS 2022",
        "setting": "source-aware open-set domain adaptation (OSDA)",
        "relevance": "Direct comparator: aligns target-known and segregates target-unknown samples during adaptation.",
        "study_role": "primary-method-comparator; port objective into the shared PanDerm runner",
        "required": ["README.md", "train.py"],
        "required_any": ["models", "data_loader"],
    },
    {
        "name": "OSBP_official",
        "url": "https://github.com/ksaito-ut/OPDA_BP.git",
        "group": "source-aware",
        "paper": "Saito et al., Open Set Domain Adaptation by Backpropagation, ECCV 2018",
        "setting": "source-aware open-set domain adaptation (OSDA)",
        "relevance": "Classic explicit unknown-output baseline; useful historical reference.",
        "study_role": "primary-method-comparator; authors' implementation",
        "required": ["README.md"],
        "required_any": ["trainer_osda.py", "models"],
    },
    {
        "name": "Transfer_Learning_Library_OSBP_reference",
        "url": "https://github.com/thuml/Transfer-Learning-Library.git",
        "group": "cross-check",
        "paper": "Transfer Learning Library OSBP reference implementation",
        "setting": "source-aware open-set domain adaptation (OSDA)",
        "relevance": "Independent implementation cross-check for OSBP; not a separate method or result.",
        "study_role": "secondary-code-cross-check-only",
        "required": ["README.md"],
        "required_any": ["tllib/alignment/osbp.py", "examples/domain_adaptation/openset_domain_adaptation/osbp.py"],
    },
    {
        "name": "ANNA",
        "url": "https://github.com/CityU-AIM-Group/Anna.git",
        "group": "source-aware",
        "paper": "Li et al., Adjustment and Alignment for Unbiased Open Set Domain Adaptation, CVPR 2023",
        "setting": "source-aware open-set domain adaptation (OSDA)",
        "relevance": "Open-set adaptation comparator; region-level unknown discovery may require a substantial image-classification port.",
        "study_role": "secondary-method-candidate-after-feasibility-review",
        "required": ["README.md"],
        "required_any": ["train.py", "run.sh"],
    },
    {
        "name": "TASC",
        "url": "https://github.com/Sapphire-356/TASC.git",
        "group": "source-aware",
        "paper": "He et al., Target Semantics Clustering via Text Representations for Robust Universal Domain Adaptation, AAAI 2025",
        "setting": "source-aware universal domain adaptation (UniDA)",
        "relevance": "Closest textualization-related candidate: text-space target semantics and an open-set score; its VLM class prompts differ from BioClinicalBERT metadata text.",
        "study_role": "high-priority-method-candidate; verify class-set assumptions and port feasibility",
        "required": ["README.md"],
        "required_any": ["train_sapphire_TASC.py", "train_sapphire_TASCBase.py"],
    },
    {
        "name": "DALN",
        "url": "https://github.com/xiaoachen98/DALN.git",
        "group": "source-aware-closed-set",
        "paper": "Chen et al., Reusing the Task-Specific Classifier as a Discriminator: Discriminator-Free Adversarial Domain Adaptation, CVPR 2022",
        "setting": "source-aware closed-set UDA",
        "relevance": "Optional adversarial UDA comparator; it is not open-set-aware, so unknown target samples can cause negative transfer.",
        "study_role": "optional-closed-set-method-comparator",
        "required": ["README.md"],
        "required_any": ["nwd.py", "train.py"],
    },
    {
        "name": "ProDe_DIFO_unified",
        "url": "https://github.com/tntek/source-free-domain-adaptation.git",
        "group": "source-free-open-set",
        "paper": "ProDe (ICLR 2025) and DIFO (CVPR 2024), unified official source-free DA repository",
        "setting": "source-free DA; ProDe reports multiple label-set scenarios including open-set",
        "relevance": "Relevant separate source-free track; cannot be compared as a matched source-aware run.",
        "study_role": "source-free-protocol-only; repository supports both ProDe and DIFO",
        "required": ["README.md"],
        "required_any": ["image_target_of_oh_vs.py", "image_target_in_126.py"],
    },
    {
        "name": "UPUK",
        "url": "https://github.com/xdwfl/UPUK.git",
        "group": "source-free-open-set",
        "paper": "Wan et al., Unveiling the Unknown: Unleashing the Power of Unknown to Known in Open-Set Source-Free Domain Adaptation, CVPR 2024",
        "setting": "open-set source-free domain adaptation (OS-SFDA)",
        "relevance": "Explicitly explores/partitions target-private unknown categories.",
        "study_role": "source-free-protocol-only; inspect task coverage before porting",
        "required": ["README.md"],
        "required_any": ["target_train.py", "train_target_mods.py"],
    },
    {
        "name": "LEAD",
        "url": "https://github.com/ispc-lab/LEAD.git",
        "group": "source-free-open-set",
        "paper": "Qu et al., LEAD: Learning Decomposition for Source-free Universal Domain Adaptation, CVPR 2024",
        "setting": "source-free universal domain adaptation (SF-UniDA)",
        "relevance": "Unknown target-category detection under arbitrary label-set overlap; separate source-free protocol.",
        "study_role": "source-free-protocol-only",
        "required": ["README.md"],
        "required_any": ["train_target.py", "train_source.py"],
    },
    {
        "name": "DIFO_Plus",
        "url": "https://github.com/tntek/DIFO-Plus.git",
        "group": "source-free-vlm",
        "paper": "Tang et al., Source-Free Domain Adaptation with Vision-Language Prior (DIFO++), IJCV 2026",
        "setting": "VLM-guided source-free domain adaptation",
        "relevance": "Latest VLM-prior branch; useful method reference, but source-free and CLIP-based rather than your current source-aware BioClinicalBERT setup.",
        "study_role": "latest-literature-reference; source-free-protocol-only",
        "required": ["README.md"],
        "required_any": ["main.py", "train.py", "image_target_of_oh_vs.py"],
    },
    {
        "name": "VSFOT",
        "url": "https://github.com/TangXu-Group/VSFOT.git",
        "group": "source-free-vlm",
        "paper": "Han et al., Vision-Language Model Guided Source-Free Domain Adaptation via Optimal Transport, CVPR 2026",
        "setting": "VLM-guided source-free DA via optimal transport",
        "relevance": "Latest VLM/OT branch; classification code is available, but source-free protocol does not match current UDA.",
        "study_role": "latest-literature-reference; source-free-protocol-only",
        "required": ["README.md"],
        "required_any": ["main.py", "trainSource.py"],
    },
    {
        "name": "DUET",
        "url": "https://github.com/l3umblee/duet-sfda.git",
        "group": "source-free-classification",
        "paper": "Lee et al., DUET: Dual-Perspective Pseudo Labeling and Uncertainty-Aware Exploration & Exploitation Training for SFDA, NeurIPS 2025",
        "setting": "source-free closed-set DA with model/CLIP agreement and uncertainty-aware learning",
        "relevance": "Classification method and recent reference; unknown-class handling is not its primary protocol.",
        "study_role": "optional-source-free-classification-track-only",
        "required": ["README.md"],
        "required_any": ["image_target_of_oh_vs.py", "image_target_in_126.py"],
    },
    {
        "name": "UCon_SFDA",
        "url": "https://github.com/xugezheng/UCon_SFDA.git",
        "group": "source-free-classification",
        "paper": "Xu et al., Revisiting Source-Free Domain Adaptation: A New Perspective via Uncertainty Control, ICLR 2025",
        "setting": "source-free classification DA",
        "relevance": "Useful uncertainty-control comparator if a separate SFDA track is justified; not itself an open-set method.",
        "study_role": "optional-source-free-classification-track-only",
        "required": ["README.md"],
        "required_any": ["README.md"],
    },
    {
        "name": "RCL",
        "url": "https://github.com/Dong-Jie-Chen/RCL.git",
        "group": "source-free-classification",
        "paper": "Chen et al., Empowering Source-Free Domain Adaptation via MLLM-Guided Reliability-Based Curriculum Learning, WACV 2026",
        "setting": "source-free image-classification DA",
        "relevance": "Recent reliability/curriculum reference; it uses MLLM pseudo-supervision and is not an open-set method.",
        "study_role": "optional-source-free-classification-track-only",
        "required": ["README.md"],
        "required_any": ["README.md"],
    },
    {
        "name": "SFDA2",
        "url": "https://github.com/shinyflight/SFDA2.git",
        "group": "source-free-classification",
        "paper": "Hwang et al., SF(DA)^2: Source-free Domain Adaptation Through the Lens of Data Augmentation, ICLR 2024",
        "setting": "source-free classification DA",
        "relevance": "Classification method and useful augmentation/feature-graph reference; it does not model target unknown classes explicitly.",
        "study_role": "optional-source-free-classification-track-only",
        "required": ["README.md"],
        "required_any": ["visda.sh", "README.md"],
    },
    {
        "name": "SfMamba",
        "url": "https://github.com/chenxi52/SfMamba.git",
        "group": "source-free-classification",
        "paper": "Chen et al., SfMamba: Efficient Source-Free Domain Adaptation via Selective Scan Modeling, ESWA 2026",
        "setting": "source-free image-classification DA with VMamba backbone",
        "relevance": "Recent classification SFDA reference; the VMamba-specific architecture and closed-set protocol do not match the PanDerm open-set main study.",
        "study_role": "latest-literature-reference; optional-source-free-track-only",
        "required": ["README.md"],
        "required_any": ["main_source.py", "main_target.py"],
    },
    {
        "name": "PODA",
        "url": "https://github.com/astra-vision/poda.git",
        "group": "zero-shot-text-conditioned",
        "paper": "Fahes et al., PODA: Prompt-driven Zero-shot Domain Adaptation, ICCV 2023",
        "setting": "prompt-driven zero-shot DA; no unlabeled-target adaptation loop",
        "relevance": "Optional text-conditioned domain-shift reference; not an open-set DA comparator.",
        "study_role": "zero-shot-reference-only",
        "required": ["README.md"],
        "required_any": ["poda.py", "train.py", "README.md"],
    },
]

# Close research-adjacent papers are documented so they are not accidentally
# added as image-classification DA baselines.
OUT_OF_SCOPE = [
    {
        "name": "Tell2Adapt",
        "paper": "CVPR 2026",
        "reason": "source-free medical image segmentation, not image-level lesion classification",
    },
    {
        "name": "FreeDNA",
        "paper": "ICCV 2025",
        "reason": "domain-noise alignment for diffusion-based dense prediction, not this classifier family",
    },
    {
        "name": "GROTO",
        "paper": "CVPR 2025",
        "reason": "class-incremental source-free adaptation; current target task is a static cohort",
    },
    {
        "name": "CoTTA",
        "paper": "CVPR 2022",
        "reason": "continual/test-time adaptation stream protocol, not the current offline UDA protocol",
    },
    {
        "name": "FedSCAl",
        "paper": "WACV 2026",
        "reason": "federated source-free DA with multiple clients and client drift; no federated clients in the current study",
    },
    {
        "name": "PriSM",
        "paper": "ECCV 2026",
        "reason": "unsupervised adaptation for facial landmark detection, not classification",
    },
    {
        "name": "PRISM_VFM",
        "paper": "ICML 2026",
        "reason": "vision foundation-model fusion for dense prediction, not domain adaptation for skin-lesion classification",
    },
]


def run_git(args: List[str], cwd: Optional[Path] = None) -> str:
    p = subprocess.run(
        ["git", *args], cwd=str(cwd) if cwd else None,
        check=True, capture_output=True, text=True,
    )
    return p.stdout.strip()


def ensure_repo(dest: Path, spec: dict) -> dict:
    repo_dir = dest / spec["name"]
    if repo_dir.exists():
        if not (repo_dir / ".git").is_dir():
            raise RuntimeError(
                f"Refusing to overwrite non-git directory: {repo_dir}. "
                "Move it yourself if you want a fresh clone."
            )
        origin = run_git(["-C", str(repo_dir), "remote", "get-url", "origin"])
        def normalize(value: str) -> str:
            value = value[:-4] if value.endswith(".git") else value
            return value.rstrip("/")
        if normalize(origin) != normalize(spec["url"]):
            raise RuntimeError(
                f"Existing directory has a different origin: {repo_dir}\n"
                f"  found: {origin}\n  expected: {spec['url']}"
            )
        action = "existing clone; left unchanged"
    else:
        repo_dir.parent.mkdir(parents=True, exist_ok=True)
        # Do not assume main/master across repositories. The shallow clone uses
        # the repository's advertised default branch; record the resolved SHA.
        try:
            run_git(["clone", "--depth", "1", "--single-branch", spec["url"], str(repo_dir)])
        except Exception:
            # This path did not exist before this invocation, so remove only
            # the incomplete clone produced by this failed attempt.
            shutil.rmtree(repo_dir, ignore_errors=True)
            raise
        action = "cloned default branch"

    missing = [rel for rel in spec.get("required", []) if not (repo_dir / rel).exists()]
    any_paths = spec.get("required_any", [])
    if any_paths and not any((repo_dir / rel).exists() for rel in any_paths):
        missing.append("one of: " + ", ".join(any_paths))
    if missing:
        raise RuntimeError(f"{spec['name']} clone is missing expected paths: {missing}")

    sha = run_git(["-C", str(repo_dir), "rev-parse", "HEAD"])
    branch = run_git(["-C", str(repo_dir), "branch", "--show-current"])
    return {
        **spec,
        "path": str(repo_dir.resolve()),
        "resolved_branch": branch,
        "commit": sha,
        "action": action,
        "verified_required_paths": spec.get("required", []),
        "verified_one_of_paths": any_paths,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument(
        "--dest", type=Path,
        default=Path(__file__).resolve().parent / "external_da_refs",
        help="directory for reference repositories (default: ./external_da_refs)",
    )
    ap.add_argument(
        "--group", action="append", choices=sorted({r["group"] for r in REPOSITORIES}),
        help="only fetch this group; repeat to select multiple groups (default: all relevant groups)",
    )
    ap.add_argument(
        "--list-only", action="store_true",
        help="print selected repositories and protocol notes without cloning",
    )
    args = ap.parse_args()

    selected_groups = set(args.group or [])
    selected = [r for r in REPOSITORIES if not selected_groups or r["group"] in selected_groups]
    if args.list_only:
        print(json.dumps({
            "selected_repositories": [
                {k: r[k] for k in ("name", "url", "group", "paper", "setting", "study_role")}
                for r in selected
            ],
            "not_fetched_as_out_of_scope": OUT_OF_SCOPE,
        }, indent=2))
        return 0

    if shutil.which("git") is None:
        ap.error("Git was not found on PATH. Install Git for Windows, reopen the pytorch prompt, and retry.")

    dest = args.dest.expanduser().resolve()
    dest.mkdir(parents=True, exist_ok=True)
    results = []
    failures = []
    for spec in selected:
        print(f"[fetch] {spec['name']} [{spec['group']}] ...", flush=True)
        try:
            results.append(ensure_repo(dest, spec))
            print(
                f"[fetch] {spec['name']} verified at {results[-1]['commit']} "
                f"({results[-1]['resolved_branch'] or 'detached'})",
                flush=True,
            )
        except Exception as exc:
            failures.append({"name": spec["name"], "url": spec["url"], "error": str(exc)})
            print(f"[fetch] FAILED {spec['name']}: {exc}", file=sys.stderr, flush=True)

    manifest = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "purpose": "Reference-code inventory for matched PanDerm open-set/universal DA research",
        "training_started": False,
        "ood_evaluation_run": False,
        "repositories": results,
        "fetch_failures": failures,
        "not_fetched_as_out_of_scope": OUT_OF_SCOPE,
        "experimental_protocol": {
            "source": "PAD-UFES-20 labeled source",
            "targets": ["ISIC 2019", "MCR-SL"],
            "target_adaptation_labels_available": False,
            "primary_view": "core",
            "textualization_ablation": "full",
            "seeds": [42, 123, 2026],
            "main_study_source_aware_candidates": ["UADAL", "OSBP_official", "TASC"],
            "optional_source_aware_candidates": ["ANNA", "DALN"],
            "source_free_methods_are_separate_protocol": [
                "ProDe_DIFO_unified", "UPUK", "LEAD", "DIFO_Plus", "VSFOT",
                "DUET", "UCon_SFDA", "RCL",
            ],
            "zero_shot_text_conditioned_reference": ["PODA"],
            "paired_evaluation": [
                "known-class Macro-F1 and per-class recall",
                "AUROC, AUPR-out, FPR at 95% known retention",
                "OSCR-AUC",
                "paired patient/case bootstrap intervals",
                "equal-weight cohort mean primary; count-weighted cohort mean secondary",
            ],
            "locked_target_test": True,
        },
        "ood_status": {
            "this_script": "fetches repositories only; it does not score or reject OOD cases",
            "runner_06_current_behavior": (
                "evaluates OOD after adaptation using the frozen DermLIP-MCM branch; "
                "that score is independent of the adapted DA checkpoint"
            ),
            "checkpoint_specific_follow_up": (
                "add a separate source-calibrated score from each adapted checkpoint's logits "
                "(for example energy or maximum-softmax); set its threshold using PAD source_val only, "
                "then report it alongside the fixed DermLIP-MCM reference"
            ),
            "adaptation_time_unknown_handling": (
                "UADAL/OSBP objectives handle open-set samples during adaptation; this differs "
                "from post-hoc OOD scoring and both results should be recorded separately"
            ),
        },
        "porting_note": (
            "These are reference implementations, not plug-compatible PanDerm experiments. "
            "Port selected published objectives into the shared F0/06 loader, source checkpoint, "
            "optimizer budget, target-label-free adaptation loop, and per-case evaluation. "
            "Freeze class-overlap assumptions and the OOD protocol before running the locked test set."
        ),
    }
    manifest_path = dest / "da_repositories_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(
        f"[done] verified {len(results)} reference repositories; "
        f"{len(failures)} failed; manifest: {manifest_path}"
    )
    print("[note] no training or OOD evaluation was started; source-free methods require a separate protocol.")
    return 2 if failures else 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except subprocess.CalledProcessError as exc:
        print(f"[git error] {exc}", file=sys.stderr)
        if exc.stderr:
            print(exc.stderr, file=sys.stderr)
        raise SystemExit(exc.returncode or 1)
