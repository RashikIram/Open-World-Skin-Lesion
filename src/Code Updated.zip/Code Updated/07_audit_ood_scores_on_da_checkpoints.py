#!/usr/bin/env python
from __future__ import annotations

"""Native unknown handling and common post-hoc OOD audit for DA checkpoints.

This development-only evaluator exports one row per case and reports two
different things separately:
  1. Method-native unknown handling, when the checkpoint has a K+1 output or
     implements the documented native_unknown_score/native_unknown_decision API.
  2. Common post-hoc scores (primary: energy; secondary: MSP, entropy,
     prototype distance, kNN distance) computed from that exact DA checkpoint.

Each common-score threshold is calibrated on that checkpoint's PAD source_val
scores only (q95). DermLIP-MCM remains a separately labelled frozen reference
score; it is not a score from the adapted DA checkpoint. Target validation labels
are used only for reported metrics and exported truth columns. Target adaptation
inputs remain label-stripped and target test labels are not loaded.

Requires the matching 00_run_da_panderm_benchmark*.py and project F0-v3 files
under --root. No checkpoint is retrained or overwritten.
"""

import argparse
import importlib.util
import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from sklearn.metrics import average_precision_score, f1_score, recall_score, roc_auc_score

DEFAULT_ROOT = Path(r"C:\Users\Nebula PC\Downloads\Deep Learning")
METHODS = [
    "continued_source", "dann", "cdan", "shared_pcgrad_dann",
    "entropy_pcgrad_dann", "source_calibrated_selective_pcgrad_dann",
]
VIEWS = ["image", "age", "location", "shared_robust", "core", "full", "missing_explicit"]
TARGETS = ["isic", "mcr"]
SCORES = [
    "dermlip_mcm", "energy", "msp", "entropy", "prototype_distance", "knn_distance"
]
COMMON_PRIMARY_SCORE = "energy"
PROPOSED_METHOD = "source_calibrated_selective_pcgrad_dann"
COMPARISON_BASELINES = ("continued_source", "shared_pcgrad_dann")


def restore_frame_order(output, expected_n, name):
    """Restore outputs to frame row order using dataset-provided row indices."""
    indices = np.asarray(output["index"], dtype=np.int64)
    order = np.argsort(indices, kind="stable")
    if len(indices) != expected_n or not np.array_equal(indices[order], np.arange(expected_n)):
        raise RuntimeError(
            f"{name}: loader indices do not map one-to-one to frame rows "
            f"(got {len(indices)}, expected {expected_n})"
        )
    result = {}
    for key, value in output.items():
        if value is None:
            result[key] = None
        else:
            result[key] = np.asarray(value)[order]
    return result


def native_unknown_output(model, output, nclasses):
    """Extract a method-native unknown score without inventing a rule.

    Convention: larger native_score means more likely unknown. A K+1 (or wider)
    classifier uses its extra logit(s) as the native unknown output. A custom DA
    model may instead provide native_unknown_score(features=..., logits=...) and
    optionally native_unknown_decision(features=..., logits=...).
    """
    logits = np.asarray(output["logits"], dtype=np.float32)
    features = np.asarray(output["features"], dtype=np.float32)
    if logits.shape[1] > nclasses:
        full_probs = F.softmax(torch.as_tensor(logits), dim=1).numpy()
        score = full_probs[:, nclasses:].sum(axis=1)
        decision = logits.argmax(axis=1) >= nclasses
        return score, decision, "extra_unknown_logit_argmax"

    score_fn = getattr(model, "native_unknown_score", None)
    if not callable(score_fn) and hasattr(model, "base"):
        score_fn = getattr(model.base, "native_unknown_score", None)
    if callable(score_fn):
        raw_score = score_fn(features=features, logits=logits)
        score = np.asarray(raw_score, dtype=np.float64).reshape(-1)
        if len(score) != len(logits):
            raise RuntimeError("native_unknown_score must return one scalar per case")
        decision_fn = getattr(model, "native_unknown_decision", None)
        if not callable(decision_fn) and hasattr(model, "base"):
            decision_fn = getattr(model.base, "native_unknown_decision", None)
        decision = None
        if callable(decision_fn):
            decision = np.asarray(
                decision_fn(features=features, logits=logits), dtype=bool
            ).reshape(-1)
            if len(decision) != len(logits):
                raise RuntimeError("native_unknown_decision must return one bool per case")
        return score, decision, "model_native_unknown_score"

    return None, None, "no_inference_time_native_unknown_rule"


def extract_model_features(model, moved, da):
    adapter_type = getattr(da, "DomainAdapter", None)
    if isinstance(adapter_type, type) and isinstance(model, adapter_type):
        extractor = model.base
    elif hasattr(model, "base") and hasattr(model.base, "extract_features"):
        extractor = model.base
    else:
        extractor = model
    if not hasattr(extractor, "extract_features"):
        raise RuntimeError(
            "Evaluation model must expose extract_features, or the DA runner must "
            "provide build_checkpoint_eval_model with a compatible model wrapper."
        )
    return extractor.extract_features(
        moved["pixel_values"], moved.get("input_ids"), moved.get("attention_mask")
    )


def import_file(path: Path, module_name: str):
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import script: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def resolve_da_script(root: Path, supplied: Path | None) -> Path:
    if supplied:
        path = supplied.expanduser().resolve()
        if not path.is_file():
            raise FileNotFoundError(f"DA runner not found: {path}")
        return path
    paths = sorted({p.resolve() for folder in (root / "Code", root)
                    if folder.exists()
                    for p in folder.glob("00_run_da_panderm_benchmark*.py")})
    if len(paths) != 1:
        raise RuntimeError(
            "Could not select exactly one 00 DA runner. Pass --da-script with its full path. "
            f"Candidates: {[str(p) for p in paths]}"
        )
    return paths[0]


@torch.inference_mode()
def collect(da, model, loader, device):
    model.eval()
    logits_all, features_all, labels_all, indices_all = [], [], [], []
    for batch in loader:
        labels = batch.get("label")
        moved = da.move_batch(batch, device)
        features = extract_model_features(model, moved, da)
        logits = model(
            moved["pixel_values"], moved.get("input_ids"), moved.get("attention_mask")
        )
        logits_all.append(logits.float().cpu().numpy())
        features_all.append(features.float().cpu().numpy())
        indices_all.append(batch["index"].cpu().numpy().astype(np.int64))
        if labels is not None:
            labels_all.append(labels.cpu().numpy().astype(np.int64))
    if not logits_all:
        raise RuntimeError("Evaluation loader is empty")
    return {
        "logits": np.concatenate(logits_all),
        "features": np.concatenate(features_all),
        "labels": np.concatenate(labels_all) if labels_all else None,
        "index": np.concatenate(indices_all),
    }


def normalize_rows(x):
    x = np.asarray(x, dtype=np.float32)
    return x / np.maximum(np.linalg.norm(x, axis=1, keepdims=True), 1e-12)


def score_matrix(source_train, source_val, eval_out, nclasses, knn_k=10):
    def logits_scores(logits):
        # Common post-hoc scoring always uses the known-class logits. If a
        # method has a native K+1 unknown output, that output is evaluated
        # separately and must not silently alter the common score definition.
        z = torch.as_tensor(logits[:, :nclasses], dtype=torch.float32)
        p = F.softmax(z, dim=1).clamp_min(1e-12)
        return {
            "energy": (-torch.logsumexp(z, dim=1)).numpy(),
            "msp": (1.0 - p.max(dim=1).values).numpy(),
            "entropy": (-(p * p.log()).sum(dim=1) / math.log(p.shape[1])).numpy(),
        }

    trf = normalize_rows(source_train["features"])
    tr_y = source_train["labels"]
    if tr_y is None or len(tr_y) != len(trf):
        raise RuntimeError("Source-train labels are required for class prototypes and kNN")
    centroids = []
    for cls in range(nclasses):
        members = trf[tr_y == cls]
        if len(members) == 0:
            raise RuntimeError(f"Source-train split has no rows for known class id {cls}")
        centroids.append(normalize_rows(members.mean(axis=0, keepdims=True))[0])
    centroids = np.stack(centroids)

    def all_scores(out):
        result = logits_scores(out["logits"])
        feat = normalize_rows(out["features"])
        result["prototype_distance"] = 1.0 - (feat @ centroids.T).max(axis=1)
        sims = feat @ trf.T
        k = min(knn_k, sims.shape[1])
        top = np.partition(sims, sims.shape[1] - k, axis=1)[:, -k:]
        result["knn_distance"] = 1.0 - top.mean(axis=1)
        return result

    return all_scores(source_val), all_scores(eval_out)


def native_metric_row(f0, y_open, known_logits, native_score, native_decision,
                      native_status, metadata):
    """Summarize only the method's own inference-time unknown mechanism."""
    y = np.asarray(y_open, dtype=np.int64)
    known = y != f0.UNKNOWN_ID
    unknown = ~known
    pred_known = np.asarray(known_logits[:, :len(f0.KNOWN_CLASSES)]).argmax(axis=1)
    row = {
        **metadata,
        "native_status": native_status,
        "native_positive_class": "unknown",
        "native_score_convention": "higher means more unknown; method-native score/rule",
        "native_fpr_at_95_known_retention_definition": "known-positive threshold retaining 95% of known cases; FPR is the unknown fraction accepted as known",
        "native_unknown_auroc": np.nan,
        "native_aupr_out": np.nan,
        "native_fpr95": np.nan,
        "native_unknown_fpr_at_95_known_retention": np.nan,
        "native_oscr_auc": np.nan,
        "native_open_macro_f1": np.nan,
        "native_unknown_recall": np.nan,
        "native_known_false_reject_fraction": np.nan,
    }
    if native_score is not None and unknown.any() and known.any():
        score = np.asarray(native_score, dtype=np.float64)
        row["native_unknown_auroc"] = float(roc_auc_score(unknown.astype(int), score))
        row["native_aupr_out"] = float(average_precision_score(unknown.astype(int), score))
        row["native_fpr95"] = float(f0.fpr95_unknown_positive(unknown, score))
        native_threshold = float(np.quantile(score[known], 0.95))
        row["native_unknown_fpr_at_95_known_retention"] = float(
            (score[unknown] <= native_threshold).mean()
        )
        row["native_oscr_auc"] = float(f0.oscr_auc(y, pred_known, score))
    if native_decision is not None:
        reject = np.asarray(native_decision, dtype=bool)
        pred_open = pred_known.copy()
        pred_open[reject] = f0.UNKNOWN_ID
        row["native_open_macro_f1"] = float(f1_score(
            y, pred_open, labels=list(range(f0.UNKNOWN_ID + 1)),
            average="macro", zero_division=0,
        ))
        row["native_unknown_recall"] = (
            float(reject[unknown].mean()) if unknown.any() else np.nan
        )
        row["native_known_false_reject_fraction"] = (
            float(reject[known].mean()) if known.any() else np.nan
        )
    return row


def case_identity_columns(frame, domain):
    """Preserve available case/patient IDs; do not infer patient IDs from names."""
    q = frame.reset_index(drop=True).copy()
    case_key = next(
        (c for c in ("sample_id", "image_id", "image_file", "image_path") if c in q.columns),
        None,
    )
    if case_key is None:
        q["case_id"] = [f"{domain}:row_{i}" for i in range(len(q))]
    else:
        q["case_id"] = domain + ":" + q[case_key].astype(str)
    q["case_id_source_column"] = case_key or "row_order_fallback"
    for col in ("patient_id", "lesion_id", "subject_id", "split_group_id"):
        if col not in q.columns:
            q[col] = np.nan
    return q


def build_case_predictions(f0, frame, domain, y_open, evaluated, eval_scores,
                           thresholds, mcm_score, mcm_threshold, native_score,
                           native_decision, native_status, probs, method, view,
                           target, seed):
    q = case_identity_columns(frame, domain)
    nclasses = len(f0.KNOWN_CLASSES)
    logits = np.asarray(evaluated["logits"])
    pred_known = probs.argmax(axis=1)
    rows = q[["case_id", "case_id_source_column", "patient_id", "lesion_id",
              "subject_id", "split_group_id"]].copy()
    rows.insert(0, "target_adaptation_domain", target)
    rows.insert(1, "method", method)
    rows.insert(2, "view", view)
    rows.insert(3, "seed", int(seed))
    rows["domain"] = domain
    rows["true_open_id"] = np.asarray(y_open, dtype=np.int64)
    rows["true_known_unknown"] = np.where(
        np.asarray(y_open) == f0.UNKNOWN_ID, "unknown", "known"
    )
    rows["true_class"] = q.get("label_harmonized", pd.Series([np.nan] * len(q))).astype(str)
    rows["pred_known_id"] = pred_known
    rows["pred_known_class"] = [f0.KNOWN_CLASSES[int(i)] for i in pred_known]
    rows["native_unknown_method_status"] = native_status
    rows["native_unknown_score"] = (
        np.asarray(native_score) if native_score is not None else np.nan
    )
    rows["native_pred_unknown"] = (
        np.asarray(native_decision, dtype=bool) if native_decision is not None else pd.NA
    )
    rows["native_decision_rule"] = (
        "method-native argmax/decision" if native_decision is not None
        else "not available for this checkpoint"
    )
    rows["dermlip_mcm_reference_score"] = np.asarray(mcm_score, dtype=np.float64)
    rows["dermlip_mcm_reference_source_val_q95"] = float(mcm_threshold)
    rows["dermlip_mcm_reference_reject"] = np.asarray(mcm_score) > float(mcm_threshold)
    for k, class_name in enumerate(f0.KNOWN_CLASSES):
        rows[f"known_logit_{class_name}"] = logits[:, k]
        rows[f"known_probability_{class_name}"] = probs[:, k]
    for name, values in eval_scores.items():
        rows[f"common_{name}_score"] = np.asarray(values, dtype=np.float64)
        rows[f"common_{name}_source_val_q95"] = float(thresholds[name])
        rows[f"common_{name}_reject"] = np.asarray(values) > float(thresholds[name])
    rows["common_primary_score"] = COMMON_PRIMARY_SCORE
    rows["common_primary_reject"] = rows[f"common_{COMMON_PRIMARY_SCORE}_reject"]
    rows["common_primary_threshold"] = rows[f"common_{COMMON_PRIMARY_SCORE}_source_val_q95"]
    return rows


def case_metric_bundle(rows, score_col="common_energy_score"):
    """Metrics on one cohort's rows; larger OOD scores mean more unknown."""
    y = rows["true_open_id"].to_numpy(dtype=int)
    pred = rows["pred_known_id"].to_numpy(dtype=int)
    known_mask = rows["true_known_unknown"].to_numpy() == "known"
    unknown_mask = ~known_mask
    score = rows[score_col].to_numpy(dtype=float)
    probs_cols = [c for c in rows.columns if c.startswith("known_probability_")]
    class_ids = list(range(len(probs_cols)))
    result = {
        "n": int(len(rows)), "n_known": int(known_mask.sum()),
        "n_unknown": int(unknown_mask.sum()),
        "known_macro_f1": np.nan, "oscr_auc": np.nan,
        "unknown_auroc": np.nan, "unknown_aupr_out": np.nan,
        "unknown_fpr_at_95_known_retention": np.nan,
        "source_q95_open_macro_f1": np.nan,
    }
    if known_mask.any():
        result["known_macro_f1"] = float(f1_score(
            y[known_mask], pred[known_mask], labels=class_ids,
            average="macro", zero_division=0,
        ))
        for cls in class_ids:
            # The class display name comes from the matching probability/logit
            # column suffix (e.g. known_probability_AK).
            col = probs_cols[cls]
            display = col.removeprefix("known_probability_")
            result[f"recall_{display}"] = float(recall_score(
                y[known_mask], pred[known_mask], labels=[cls],
                average="macro", zero_division=0,
            ))
    if unknown_mask.any() and known_mask.any():
        is_unknown = unknown_mask.astype(int)
        result["unknown_auroc"] = float(roc_auc_score(is_unknown, score))
        result["unknown_aupr_out"] = float(average_precision_score(is_unknown, score))
        # Evaluation operating point: choose the score threshold that retains
        # 95% of known cases; FPR is the unknown fraction accepted as known.
        retention_threshold = float(np.quantile(score[known_mask], 0.95))
        result["unknown_fpr_at_95_known_retention"] = float(
            (score[unknown_mask] <= retention_threshold).mean()
        )
        result["known_retention_threshold"] = retention_threshold
        correct_known = known_mask & (pred == y)
        thresholds = np.r_[-np.inf, np.sort(np.unique(score)), np.inf]
        x_fpr, y_ccr = [], []
        for threshold in thresholds:
            accepted = score <= threshold
            x_fpr.append(float((accepted & unknown_mask).sum() / unknown_mask.sum()))
            y_ccr.append(float((accepted & correct_known).sum() / known_mask.sum()))
        order = np.argsort(x_fpr)
        x_arr, y_arr = np.asarray(x_fpr)[order], np.asarray(y_ccr)[order]
        unique_x = np.unique(x_arr)
        max_y = np.asarray([y_arr[x_arr == x].max() for x in unique_x])
        result["oscr_auc"] = float(np.trapezoid(max_y, unique_x))
        source_threshold = float(rows["common_energy_source_val_q95"].iloc[0])
        rejected = score > source_threshold
        pred_open = pred.copy()
        pred_open[rejected] = int(max(class_ids) + 1)
        result["source_q95_open_macro_f1"] = float(f1_score(
            y, pred_open, labels=class_ids + [int(max(class_ids) + 1)],
            average="macro", zero_division=0,
        ))
    return result


def _paired_case_table(candidate, baseline, seed):
    """One-to-one case alignment; fail rather than compare mismatched cases."""
    left = candidate[candidate["seed"].astype(int) == int(seed)].copy()
    right = baseline[baseline["seed"].astype(int) == int(seed)].copy()
    if left["case_id"].duplicated().any() or right["case_id"].duplicated().any():
        raise RuntimeError("Paired bootstrap requires one row per case and seed")
    left = left.set_index("case_id", drop=False).sort_index()
    right = right.set_index("case_id", drop=False).sort_index()
    if not left.index.equals(right.index):
        raise RuntimeError("Methods do not contain the same cases for paired comparison")
    if not np.array_equal(left["true_open_id"].to_numpy(), right["true_open_id"].to_numpy()):
        raise RuntimeError("Methods disagree on true labels for paired cases")
    merged = left.reset_index(drop=True).copy()
    for col in ("patient_id", "lesion_id", "subject_id", "split_group_id"):
        if col in left.columns:
            merged[col] = left[col].to_numpy()
    merged["candidate_pred_known_id"] = left["pred_known_id"].to_numpy()
    merged["baseline_pred_known_id"] = right["pred_known_id"].to_numpy()
    merged["candidate_common_energy_score"] = left["common_energy_score"].to_numpy()
    merged["baseline_common_energy_score"] = right["common_energy_score"].to_numpy()
    merged["candidate_source_q95"] = left["common_energy_source_val_q95"].to_numpy()
    merged["baseline_source_q95"] = right["common_energy_source_val_q95"].to_numpy()
    return merged


def paired_bootstrap_summary(case_frame, bootstrap_replicates=2000, seed=20261005):
    """Paired candidate-vs-baseline differences, clustered by patient/case.

    Each bootstrap draw resamples patient clusters once and applies that same
    draw to both methods and all paired seeds. Point estimates average the
    within-seed paired differences. Confidence intervals are conditional on
    the evaluated seeds; seed-level means/stds are separately exported.
    """
    if case_frame.empty:
        return pd.DataFrame(), pd.DataFrame()
    group_keys = ["target_adaptation_domain", "view", "domain"]
    per_seed_rows = []
    paired_rows = []
    rng = np.random.default_rng(seed)
    metric_names = [
        "known_macro_f1", "oscr_auc", "unknown_auroc", "unknown_aupr_out",
        "unknown_fpr_at_95_known_retention", "source_q95_open_macro_f1",
    ]
    for group_key, cohort in case_frame.groupby(group_keys, dropna=False):
        target, view, domain = group_key
        for (method, run_seed), part in cohort.groupby(["method", "seed"], dropna=False):
            bundle = case_metric_bundle(part)
            per_seed_rows.append({
                "target_adaptation_domain": target, "view": view, "domain": domain,
                "method": method, "seed": int(run_seed), **bundle,
            })
        if PROPOSED_METHOD not in set(cohort["method"]):
            continue
        for baseline_method in COMPARISON_BASELINES:
            if baseline_method not in set(cohort["method"]):
                continue
            candidate = cohort[cohort["method"] == PROPOSED_METHOD]
            baseline = cohort[cohort["method"] == baseline_method]
            paired_seeds = sorted(set(candidate["seed"].astype(int)) & set(baseline["seed"].astype(int)))
            if not paired_seeds:
                continue
            tables = {s: _paired_case_table(candidate, baseline, s) for s in paired_seeds}
            any_table = next(iter(tables.values()))
            patient = any_table["patient_id"].astype("string") if "patient_id" in any_table else pd.Series(pd.NA, index=any_table.index, dtype="string")
            case = any_table["case_id"].astype("string")
            clusters = patient.where(patient.notna() & patient.ne(""), case).astype(str)
            unique_clusters = np.asarray(sorted(clusters.unique()), dtype=object)
            observed = {metric: [] for metric in metric_names}
            for run_seed in paired_seeds:
                table = tables[run_seed]
                crows = table.copy()
                crows["pred_known_id"] = crows["candidate_pred_known_id"]
                crows["common_energy_score"] = crows["candidate_common_energy_score"]
                crows["common_energy_source_val_q95"] = crows["candidate_source_q95"]
                brows = table.copy()
                brows["pred_known_id"] = brows["baseline_pred_known_id"]
                brows["common_energy_score"] = brows["baseline_common_energy_score"]
                brows["common_energy_source_val_q95"] = brows["baseline_source_q95"]
                # In paired table labels are preserved from candidate; common
                # threshold is method-specific and applied only to its method.
                cm, bm = case_metric_bundle(crows), case_metric_bundle(brows)
                for metric in metric_names:
                    val = cm.get(metric, np.nan) - bm.get(metric, np.nan)
                    if np.isfinite(val):
                        observed[metric].append(float(val))
            for metric in metric_names:
                point = float(np.mean(observed[metric])) if observed[metric] else np.nan
                paired_rows.append({
                    "target_adaptation_domain": target, "view": view, "domain": domain,
                    "candidate": PROPOSED_METHOD, "baseline": baseline_method,
                    "metric": metric, "candidate_minus_baseline": point,
                    "n_seeds_paired": len(paired_seeds), "n_cases": len(any_table),
                    "n_known": int((any_table["true_known_unknown"] == "known").sum()),
                    "n_unknown": int((any_table["true_known_unknown"] == "unknown").sum()),
                    "n_clusters": len(unique_clusters),
                    "cluster_unit": "patient_id when available, otherwise case_id",
                    "bootstrap_replicates": int(bootstrap_replicates),
                    "ci_low": np.nan, "ci_high": np.nan,
                    "valid_bootstrap_replicates": 0,
                })
                if not np.isfinite(point) or bootstrap_replicates <= 0:
                    continue
                boot_vals = []
                cluster_series = pd.Series(clusters.to_numpy(), index=any_table.index)
                for _ in range(int(bootstrap_replicates)):
                    sampled = rng.choice(unique_clusters, size=len(unique_clusters), replace=True)
                    sampled_indices = np.concatenate([
                        np.flatnonzero(cluster_series.to_numpy() == cl) for cl in sampled
                    ])
                    seed_diffs = []
                    for run_seed in paired_seeds:
                        table = tables[run_seed].iloc[sampled_indices].reset_index(drop=True)
                        crows = table.copy()
                        crows["pred_known_id"] = crows["candidate_pred_known_id"]
                        crows["common_energy_score"] = crows["candidate_common_energy_score"]
                        crows["common_energy_source_val_q95"] = crows["candidate_source_q95"]
                        brows = table.copy()
                        brows["pred_known_id"] = brows["baseline_pred_known_id"]
                        brows["common_energy_score"] = brows["baseline_common_energy_score"]
                        brows["common_energy_source_val_q95"] = brows["baseline_source_q95"]
                        a, b = case_metric_bundle(crows), case_metric_bundle(brows)
                        delta = a.get(metric, np.nan) - b.get(metric, np.nan)
                        if np.isfinite(delta):
                            seed_diffs.append(float(delta))
                    if seed_diffs:
                        boot_vals.append(float(np.mean(seed_diffs)))
                if boot_vals:
                    dest = paired_rows[-1]
                    dest["ci_low"], dest["ci_high"] = [float(x) for x in np.quantile(boot_vals, [0.025, 0.975])]
                    dest["valid_bootstrap_replicates"] = len(boot_vals)
    return pd.DataFrame(per_seed_rows), pd.DataFrame(paired_rows)


def run_one(root, da, target, method, view, seed, force=False):
    outdir = root / "results_07_da_ood_score_audit_v3" / target / method / view / f"seed_{seed}"
    flag = outdir / "RUN_COMPLETE.flag"
    if flag.exists() and not force:
        print(f"[07] skip {target}/{method}/{view}/s{seed}")
        return
    # The source-only continuation is target-independent and the DA runner
    # stores that one checkpoint under its first target key (isic). Reuse it
    # when reporting the same control beside MCR-adapted methods.
    checkpoint_target = "isic" if method == "continued_source" else target
    run_dir = root / "results_00_panderm_da_v21" / "development" / checkpoint_target / method / view / f"seed_{seed}"
    checkpoint = run_dir / "best.pt"
    if not checkpoint.is_file():
        raise FileNotFoundError(f"Missing DA checkpoint: {checkpoint}")

    f0, f0_path = da.import_f0(root)
    da.f0_global = f0
    frames, t2, table2_path = f0.load_study_frames(root, "development")
    v8, _ = f0.import_v8(root)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    (condition, source_model, train_tf, eval_tf, tokenizer, bundle,
     opt_audit, source_checkpoint) = da.condition_and_source_model(
        f0, root, frames, t2, v8, view, seed, device
    )
    model_factory = getattr(da, "build_checkpoint_eval_model", None)
    if callable(model_factory):
        # Future OSBP/UADAL runners can provide their real method architecture.
        # Do not silently instantiate a closed-set DANN head for those methods.
        model = model_factory(
            f0=f0, source_model=source_model, view=view, method=method, device=device
        )
    else:
        legacy_methods = {
            "continued_source", "dann", "cdan", "shared_pcgrad_dann",
            "entropy_pcgrad_dann", "source_calibrated_selective_pcgrad_dann",
        }
        if method not in legacy_methods:
            raise RuntimeError(
                f"Method {method!r} needs its actual architecture. Add "
                "build_checkpoint_eval_model(...) to the DA runner before scoring it."
            )
        needs_domain = method != "continued_source"
        if needs_domain:
            base = da.PanDermAdaptModel(source_model, view, len(f0.KNOWN_CLASSES)).to(device)
            model = da.DomainAdapter(
                base, "cdan" if method == "cdan" else "dann",
                len(f0.KNOWN_CLASSES), f0.DROPOUT
            ).to(device)
        else:
            model = da.PanDermAdaptModel(source_model, view, len(f0.KNOWN_CLASSES)).to(device)
    payload = torch.load(checkpoint, map_location=device)
    saved = payload.get("state_dict", payload)
    if payload.get("target") != checkpoint_target or payload.get("method") != method \
            or payload.get("view") != view or int(payload.get("seed", -1)) != int(seed):
        raise RuntimeError(f"Checkpoint metadata does not match requested cell: {checkpoint}")
    model.load_state_dict(saved, strict=True)
    model.eval()

    source_train_loader = da.make_loader(
        f0, condition, frames.source_train, train_tf, eval_tf, tokenizer,
        False, True, da.EVAL_BATCH_SIZE
    )
    source_val_loader = da.make_loader(
        f0, condition, frames.source_val, train_tf, eval_tf, tokenizer,
        False, True, da.EVAL_BATCH_SIZE
    )
    source_train = restore_frame_order(
        collect(da, model, source_train_loader, device), len(frames.source_train), "source_train"
    )
    source_val = restore_frame_order(
        collect(da, model, source_val_loader, device), len(frames.source_val), "source_val"
    )
    nclasses = len(f0.KNOWN_CLASSES)
    outdir.mkdir(parents=True, exist_ok=True)
    metric_rows = []
    calibration_rows = []
    native_rows = []
    case_frames = []
    # Reuse the prior audit's fixed MCM cache when present; this detector is
    # independent of the DA checkpoint and expensive to rebuild.
    mcm_cache_root = root / "results_07_da_ood_score_audit_v1"
    mcm_threshold, mcm_by_domain = f0.prepare_ood_cache(root, mcm_cache_root, frames, v8)
    for domain, frame in frames.open_eval.items():
        loader = da.make_loader(
            f0, condition, frame, train_tf, eval_tf, tokenizer,
            False, False, da.EVAL_BATCH_SIZE
        )
        evaluated = restore_frame_order(
            collect(da, model, loader, device), len(frame), f"{domain}"
        )
        src_scores, eval_scores = score_matrix(source_train, source_val, evaluated, nclasses)
        mcm_score = np.asarray(mcm_by_domain[domain], dtype=np.float64)
        if len(mcm_score) != len(frame):
            raise RuntimeError(f"{domain}: frozen DermLIP-MCM row count does not match frame")
        eval_scores["dermlip_mcm"] = mcm_score
        y_open = f0.make_open_targets(frame)
        known_logits = np.asarray(evaluated["logits"][:, :nclasses], dtype=np.float32)
        probs = F.softmax(torch.as_tensor(known_logits, dtype=torch.float32), dim=1).numpy()
        native_score, native_decision, native_status = native_unknown_output(
            model, evaluated, nclasses
        )
        thresholds = {}
        for name in SCORES:
            threshold = (
                float(mcm_threshold) if name == "dermlip_mcm"
                else float(np.quantile(src_scores[name], 0.95))
            )
            thresholds[name] = threshold
            metrics = f0.open_metrics(y_open, probs, eval_scores[name], threshold)
            is_unknown = np.asarray(y_open) == f0.UNKNOWN_ID
            metrics.update({
                "ood_positive_class": "unknown",
                "ood_score_convention": "higher means more unknown",
                "fpr_at_95_known_retention_definition": "known-positive threshold retaining 95% of known cases; FPR is the unknown fraction accepted as known",
                "unknown_auroc": (
                    float(roc_auc_score(is_unknown.astype(int), eval_scores[name]))
                    if is_unknown.any() and (~is_unknown).any() else np.nan
                ),
                "unknown_aupr_out": (
                    float(average_precision_score(is_unknown.astype(int), eval_scores[name]))
                    if is_unknown.any() and (~is_unknown).any() else np.nan
                ),
                # OOD-positive convention: FPR is the known-case false-reject
                # fraction at >=95% unknown detection recall.
                "fpr95_unknown_positive": (
                    float(f0.fpr95_unknown_positive(is_unknown, eval_scores[name]))
                    if is_unknown.any() and (~is_unknown).any() else np.nan
                ),
                # User-requested operating point: retain 95% of known cases,
                # then report the unknown fraction incorrectly accepted as known.
                "unknown_fpr_at_95_known_retention": (
                    float((eval_scores[name][is_unknown] <= np.quantile(
                        eval_scores[name][~is_unknown], 0.95
                    )).mean()) if is_unknown.any() and (~is_unknown).any() else np.nan
                ),
                "known_macro_f1": (
                    float(f1_score(
                        np.asarray(y_open)[~is_unknown],
                        np.asarray(probs).argmax(axis=1)[~is_unknown],
                        labels=list(range(nclasses)), average="macro", zero_division=0,
                    )) if (~is_unknown).any() else np.nan
                ),
            })
            if (~is_unknown).any():
                for cls_id, cls_name in enumerate(f0.KNOWN_CLASSES):
                    metrics[f"known_recall_{cls_name}"] = float(recall_score(
                        np.asarray(y_open)[~is_unknown],
                        np.asarray(probs).argmax(axis=1)[~is_unknown],
                        labels=[cls_id], average="macro", zero_division=0,
                    ))
            metric_rows.append({
                "target_adaptation_domain": target, "method": method, "view": view,
                "seed": seed, "domain": domain, "score": name,
                "score_role": (
                    "frozen_reference_detector" if name == "dermlip_mcm"
                    else ("common_primary_posthoc" if name == COMMON_PRIMARY_SCORE else "common_secondary_posthoc")
                ),
                "n": int(len(y_open)), "n_known": int((y_open != f0.UNKNOWN_ID).sum()),
                "n_unknown": int((y_open == f0.UNKNOWN_ID).sum()),
                "source_val_q95": threshold, **metrics,
            })
            calibration_rows.append({
                "target_adaptation_domain": target, "method": method, "view": view,
                "seed": seed, "domain": domain, "score": name,
                "source_val_q95": threshold,
                "source_val_mean": (
                    float(np.mean(src_scores[name])) if name != "dermlip_mcm" else np.nan
                ),
                "source_val_std": (
                    float(np.std(src_scores[name])) if name != "dermlip_mcm" else np.nan
                ),
            })

        native_rows.append(native_metric_row(
            f0, y_open, known_logits, native_score, native_decision, native_status,
            {"target_adaptation_domain": target, "method": method, "view": view,
             "seed": int(seed), "domain": domain,
             "n": int(len(y_open)), "n_known": int((y_open != f0.UNKNOWN_ID).sum()),
             "n_unknown": int((y_open == f0.UNKNOWN_ID).sum())},
        ))
        case_frames.append(build_case_predictions(
            f0, frame, domain, y_open, evaluated, eval_scores, thresholds,
            mcm_score, mcm_threshold, native_score, native_decision,
            native_status, probs, method, view, target, seed,
        ))

    pd.DataFrame(metric_rows).to_csv(outdir / "ood_metrics.csv", index=False)
    pd.DataFrame(calibration_rows).to_csv(outdir / "source_calibration.csv", index=False)
    pd.DataFrame(native_rows).to_csv(outdir / "native_unknown_metrics.csv", index=False)
    pd.concat(case_frames, ignore_index=True).to_csv(outdir / "case_predictions.csv", index=False)
    if method == "source_calibrated_selective_pcgrad_dann":
        native_description = (
            "source-calibrated target alignment gate is used during adaptation; "
            "there is no inference-time native unknown output"
        )
    elif "extra_unknown_logit_argmax" in {r["native_status"] for r in native_rows}:
        native_description = "method-native extra unknown output"
    else:
        native_description = "no method-native inference-time unknown rejector in this checkpoint"
    manifest = {
        "protocol": "07_native_and_common_da_ood_audit_v3",
        "source_f0_script": str(f0_path), "table2": str(table2_path),
        "source_checkpoint": str(source_checkpoint), "da_checkpoint": str(checkpoint),
        "checkpoint_target_key": checkpoint_target,
        "target": target, "method": method, "view": view, "seed": int(seed),
        "checkpoint_selection": "PAD source_val Macro-F1 from matched DA runner",
        "native_unknown_handling": native_description,
        "native_status_by_domain": sorted({r["native_status"] for r in native_rows}),
        "common_posthoc_primary": COMMON_PRIMARY_SCORE,
        "common_posthoc_threshold": "that DA checkpoint's PAD source_val q95; no target-label calibration",
        "ood_metric_conventions": {
            "auroc_aupr_out": "unknown is positive; higher score means more unknown",
            "unknown_fpr_at_95_known_retention": "threshold is the evaluation-known 95th percentile for metric reporting; FPR is unknown accepted as known; descriptive operating-point metric, not the deployment threshold",
            "fpr95_unknown_positive": "unknown is positive; threshold attains 95% unknown recall; reports known false-reject rate",
            "deployed_development_threshold": "each score's q95 on PAD source_val for that exact adapted checkpoint",
        },
        "common_posthoc_scores": [x for x in SCORES if x != "dermlip_mcm"],
        "frozen_reference_score": "DermLIP-MCM, independently calibrated on PAD source_val q95",
        "knn_k": 10,
        "case_level_output": "case_predictions.csv; includes case/patient IDs when available, truth, predictions, logits, scores, q95 thresholds, and reject decisions",
        "native_metrics_output": "native_unknown_metrics.csv; method-native results kept separate from common post-hoc results",
        "target_validation_labels": "used only for post-hoc metrics",
        "target_test_read": False,
    }
    (outdir / "run_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    flag.write_text("complete\n", encoding="utf-8")
    print(f"[07] complete {target}/{method}/{view}/s{seed}")


def aggregate(root, bootstrap_replicates=2000):
    base = root / "results_07_da_ood_score_audit_v3"
    paths = sorted(base.glob("*/*/*/seed_*/ood_metrics.csv"))
    if not paths:
        return
    frame = pd.concat([pd.read_csv(path) for path in paths], ignore_index=True)
    frame.to_csv(base / "ALL_ood_metrics.csv", index=False)
    keys = ["target_adaptation_domain", "method", "view", "domain", "score"]
    id_cols = set(keys + ["seed", "n", "n_known", "n_unknown", "source_val_q95"])
    metrics = [c for c in frame.columns if c not in id_cols and pd.api.types.is_numeric_dtype(frame[c])]
    if metrics:
        summary = frame.groupby(keys, dropna=False)[metrics].agg(["mean", "std"]).reset_index()
        summary.columns = [
            "_".join(str(v) for v in col if str(v)) if isinstance(col, tuple) else str(col)
            for col in summary.columns
        ]
        summary.to_csv(base / "MEAN_STD_ood_metrics.csv", index=False)
    native_paths = sorted(base.glob("*/*/*/seed_*/native_unknown_metrics.csv"))
    if native_paths:
        native = pd.concat([pd.read_csv(path) for path in native_paths], ignore_index=True)
        native.to_csv(base / "ALL_native_unknown_metrics.csv", index=False)
    case_paths = sorted(base.glob("*/*/*/seed_*/case_predictions.csv"))
    if case_paths:
        cases = pd.concat([pd.read_csv(path) for path in case_paths], ignore_index=True)
        cases.to_csv(base / "ALL_case_predictions.csv", index=False)
        per_seed, paired = paired_bootstrap_summary(
            cases, bootstrap_replicates=int(bootstrap_replicates)
        )
        if not per_seed.empty:
            per_seed.to_csv(base / "PER_SEED_CASE_METRICS.csv", index=False)
            summary_metrics = [
                c for c in per_seed.select_dtypes(include=[np.number]).columns
                if c not in {"seed", "n", "n_known", "n_unknown", "known_retention_threshold"}
            ]
            summary_rows = []
            summary_keys = ["target_adaptation_domain", "method", "view", "seed"]
            for key, part in per_seed.groupby(summary_keys, dropna=False):
                for metric in summary_metrics:
                    valid = part[metric].notna()
                    if not valid.any():
                        continue
                    weight_col = "n_known" if metric.startswith(("known_", "recall_")) else "n"
                    weights = part.loc[valid, weight_col].astype(float)
                    values = part.loc[valid, metric].astype(float)
                    summary_rows.append({
                        **dict(zip(summary_keys, key)), "metric": metric,
                        "equal_weight_cohort_mean": float(values.mean()),
                        "count_weighted_cohort_mean": float(np.average(values, weights=weights)) if weights.sum() > 0 else np.nan,
                        "cohort_weight_basis": weight_col,
                        "n_cohorts": int(valid.sum()),
                        "interpretation": "within-seed mean of cohort metrics; not a pooled-case metric",
                    })
            pd.DataFrame(summary_rows).to_csv(base / "PER_SEED_COHORT_SUMMARY.csv", index=False)
        if not paired.empty:
            paired.to_csv(base / "PAIRED_BOOTSTRAP_DIFFERENCES.csv", index=False)
            paired_summary_rows = []
            pkeys = ["target_adaptation_domain", "view", "candidate", "baseline", "metric"]
            for key, part in paired.groupby(pkeys, dropna=False):
                valid = part["candidate_minus_baseline"].notna()
                if not valid.any():
                    continue
                p = part.loc[valid]
                weight_col = "n_known" if str(key[-1]).startswith(("known_", "recall_")) else "n_cases"
                weights = p[weight_col].astype(float)
                values = p["candidate_minus_baseline"].astype(float)
                paired_summary_rows.append({
                    **dict(zip(pkeys, key)),
                    "equal_weight_cohort_mean_difference": float(values.mean()),
                    "count_weighted_cohort_mean_difference": float(np.average(values, weights=weights)) if weights.sum() > 0 else np.nan,
                    "cohort_weight_basis": weight_col,
                    "n_cohorts": int(valid.sum()),
                    "interpretation": "mean of paired cohort differences; cohort-specific CIs are in PAIRED_BOOTSTRAP_DIFFERENCES.csv",
                })
            pd.DataFrame(paired_summary_rows).to_csv(
                base / "PAIRED_COHORT_SUMMARY.csv", index=False
            )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=DEFAULT_ROOT)
    parser.add_argument("--da-script", type=Path, default=None)
    parser.add_argument("--targets", default="isic,mcr")
    parser.add_argument("--methods", default=",".join(METHODS))
    parser.add_argument("--views", default=",".join(VIEWS))
    parser.add_argument("--seeds", default="42,123,2026")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--bootstrap-replicates", type=int, default=2000)
    args = parser.parse_args()
    root = args.root.expanduser().resolve()
    da_path = resolve_da_script(root, args.da_script)
    da = import_file(da_path, "da_runner_for_ood_audit")
    targets = [x.strip() for x in args.targets.split(",") if x.strip()]
    methods = [x.strip() for x in args.methods.split(",") if x.strip()]
    views = [x.strip() for x in args.views.split(",") if x.strip()]
    seeds = [int(x.strip()) for x in args.seeds.split(",") if x.strip()]
    available_methods = getattr(da, "METHODS", METHODS)
    available_views = getattr(da, "VIEWS", VIEWS)
    for value, allowed, label in ((targets, TARGETS, "target"), (methods, available_methods, "method"), (views, available_views, "view")):
        bad = sorted(set(value) - set(allowed))
        if bad:
            raise ValueError(f"Unknown {label}(s): {bad}; allowed={allowed}")
    jobs = [(t, m, v, s) for t in targets for m in methods for v in views for s in seeds]
    print(f"[07] evaluating {len(jobs)} existing DA checkpoint cells")
    for job in jobs:
        run_one(root, da, *job, force=args.force)
    aggregate(root, bootstrap_replicates=args.bootstrap_replicates)


if __name__ == "__main__":
    main()
