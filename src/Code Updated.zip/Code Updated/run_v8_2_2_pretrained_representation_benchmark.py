#!/usr/bin/env python
"""
V8.2 PRETRAINED REPRESENTATION BENCHMARK
=========================================

V8.2 COMPLETION PATCH
---------------------
- MONET: uses the authors' explicitly supported Hugging Face implementation
  (`suinleelab/monet`) to avoid OpenAI-CLIP package/runtime incompatibility.
- DermLIP: uses the authors' OFFICIAL Derm1M repository-bundled `src/open_clip`
  fork, which contains the PanDerm-specific VLM implementation used by their
  released evaluation code.
- Adds DermLIP-B/16 as the companion architecture released by the same authors.
- Adds OPTIONAL gated DermFM-Zero support through the authors' official
  DermFM-Zero repository-bundled `src/open_clip` fork.
- DermFM-Zero ISIC results are explicitly marked overlap-risk because its
  model card states that ISIC Archive images were included in pretraining.

Scientific protocol is unchanged:
source_train/source_val only for fitting/selection/calibration;
target_val_ow diagnostic only;
source_test, target_adapt_ow, and target_test_ow remain untouched.

PATCHES FROM V8
---------------
1) Windows-safe feature-cache filenames:
   target split keys such as "ISIC 2019::target_val_ow" are now sanitized
   before being used as filenames. Windows forbids ":" in filenames.

2) Exact frozen legacy reconstruction:
   the source-trained MobileViT cross-attention checkpoints are rebuilt with
   the FROZEN protocol geometry (fusion_dim=128, heads=4, dropout from the
   frozen run, image size=224, freeze_backbones=False), rather than whatever
   defaults happen to exist in today's ExperimentConfig.

3) Legacy checkpoint geometry is audited before model construction. The
   checkpoint's fusion dimension must agree with the frozen protocol.

Scientific protocol is otherwise unchanged.

Goal
----
Determine whether the main bottleneck in the current open-world skin-lesion
study is the learned representation itself.

This benchmark uses AUTHORS' RELEASED PRETRAINED MODELS AS FROZEN FEATURE
EXTRACTORS. We do NOT pretrain DINOv2, BiomedCLIP, MONET, PanDerm, DermLIP,
or Derm Foundation from scratch.

Primary questions
-----------------
1) Domain generalization:
   How linearly separable are PAD-UFES known classes in each frozen
   representation, and how well does a source-only linear probe transfer to
   ISIC 2019 / MCR-SL target validation?

2) Metadata contribution:
   Does adding the SAME frozen BioClinicalBERT text_core representation improve
   cross-domain classification and/or OOD separation?

3) Native VLM contribution:
   For models with their own aligned text encoder, does native image-text
   fusion of the textualized metadata improve transfer?

4) OOD representation quality:
   With the feature extractor frozen, how good are:
       a) source-prototype raw cosine-distance + source-val q95
       b) deep kNN-50 distance + source-val q95
   on target_val_ow?

5) Native zero-shot VLM diagnostic:
   For BiomedCLIP, MONET, and DermLIP-PanDerm, how well does a single fixed
   six-class prompt template transfer without fitting a source classifier?
   OOD rejection for this diagnostic is source-val calibrated only.

STRICT PROTOCOL
---------------
Used:
    source_train
    source_val
    target_val_ow (ISIC 2019; MCR-SL exploratory)

NOT used:
    target_adapt_ow
    target_test_ow
    source_test

No foundation backbone is updated.
No target label affects training, model selection, thresholds, feature
normalization, or hyperparameters.

Target-validation labels are used ONLY to calculate diagnostic metrics after
the representation, probe, and source-only thresholds are frozen.

OFFICIAL IMPLEMENTATION CROSS-CHECKS
------------------------------------
DINOv2
  Repository:
    https://github.com/facebookresearch/dinov2
  Official loading:
    torch.hub.load("facebookresearch/dinov2", "dinov2_vitb14")
    torch.hub.load("facebookresearch/dinov2", "dinov2_vitl14")
  Official evaluation preprocessing:
    Resize(256, bicubic) -> CenterCrop(224) -> ImageNet mean/std.

BiomedCLIP
  Official Microsoft Hugging Face release:
    microsoft/BiomedCLIP-PubMedBERT_256-vit_base_patch16_224
  Official loading:
    open_clip.create_model_and_transforms(
        "hf-hub:microsoft/BiomedCLIP-PubMedBERT_256-vit_base_patch16_224"
    )
  We use the returned preprocess_val and model.encode_image/model.encode_text.

MONET
  Repository:
    https://github.com/suinleelab/MONET
  Authors' original OpenAI-CLIP path:
    CLIP ViT-L/14
    released weight_clip.pt
  Important: their repository explicitly uses:
    Resize(224, bicubic) -> CenterCrop(224)
    ImageNet mean/std
  rather than generic OpenAI CLIP image normalization.
  We reproduce that original path.

PanDerm
  Repository:
    https://github.com/SiyuanYan1/PanDerm
  Authors' builder:
    classification/models/builder.py
  Authors' feature extraction:
    model.forward_features(batch, is_train=False)
  Authors' transform:
    Resize(256) -> CenterCrop(224) -> ToTensor()
    -> mean=(0.485,0.456,0.406), std=(0.228,0.224,0.225)
  Checkpoints:
    PanDerm_Base:
      panderm_bb_data6_checkpoint-499.pth
    PanDerm_Large:
      panderm_ll_data6_checkpoint-499.pth

DermLIP-PanDerm
  Public OpenCLIP checkpoint:
    redlessone/DermLIP_PanDerm-base-w-PubMed-256
  Official usage:
    open_clip.create_model_and_transforms("hf-hub:...")
    model.encode_image / model.encode_text

Google Derm Foundation (OPTIONAL)
  Repository:
    https://github.com/Google-Health/derm-foundation
  Model:
    google/derm-foundation
  Official output:
    6144-D embedding from encoded 448x448 PNG.
  Access requires accepting Google's Health AI Developer Foundations terms.
  This is disabled by default because it requires TensorFlow/Keras and gated
  Hugging Face access. Enable explicitly with --include-derm-foundation.

NOT INCLUDED AS A DEFAULT RUNNABLE MODEL
----------------------------------------
DermFM-Zero / PanDerm-2:
  https://github.com/SiyuanYan1/DermFM-Zero
As of this benchmark design, its official repository states that model weights
are private / request-only. We therefore do NOT silently substitute another
checkpoint for it.

DINOv3:
Official weights/access can require an access request depending on model.
DINOv2-B/L are the public generic foundation baselines in the primary benchmark.

PRETRAINING-OVERLAP CAUTION
---------------------------
Foundation-model pretraining corpora differ and may include public/web medical
images. Results should be described as transfer with released pretrained
representations, not as guaranteed contamination-free estimates. PanDerm's
authors explicitly discuss leakage minimization, but that is not equivalent to
proving zero overlap with every image in this study.

LINEAR PROBE
------------
For each representation:
  - features are frozen;
  - source_train only fits the classifier;
  - four pre-declared probe variants are tried:
      raw/unweighted
      raw/effective-number-weighted
      L2/unweighted
      L2/effective-number-weighted
  - source_val Macro-F1 selects ONE probe variant;
  - target validation never selects a probe.

The logistic-regression cost follows the PanDerm linear-probe code:
    C = feature_dim * num_classes / 100
with max_iter=1000.

The effective-number weighting reuses the frozen study beta:
    beta = 0.9596031602585381

OOD
---
For every representation:
  1) prototype_q95:
       score = min_c [1 - cos(z, mu_c)]
  2) knn50_q95:
       score = Euclidean distance to the 50th nearest L2-normalized
               source_train feature.

Both thresholds are fixed at source_val q95.

REPRESENTATION VARIANTS
-----------------------
Every image encoder:
  - image_only
  - image_plus_bioclinicalbert_text_core

VLMs additionally:
  - native_image_text_mean
    (unit-normalized native image/text embeddings, averaged then normalized)

Global:
  - bioclinicalbert_text_only

Legacy:
  - existing source-trained MobileViT cross-attention/text_core frozen fused
    representation for seeds 42/123/2026, evaluated by the SAME probe/OOD code.

DEFAULT EXTERNAL MODELS
-----------------------
auto-download / official remote loaders:
  dinov2_vitb14
  dinov2_vitl14
  biomedclip
  monet
  dermlip_panderm

local official PanDerm repo/checkpoints:
  panderm_base
  panderm_large

optional gated TensorFlow model:
  derm_foundation

The parent process runs each model in an isolated subprocess so GPU memory is
released between large encoders and partial results are resumable.
"""

from __future__ import annotations

import argparse
import gc
import importlib
import io
import json
import math
import os
import re
import shutil
import subprocess
import sys
import traceback
from contextlib import nullcontext
from dataclasses import dataclass, replace
from pathlib import Path
from types import SimpleNamespace
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from PIL import Image
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    f1_score,
    recall_score,
    roc_auc_score,
)
from sklearn.exceptions import ConvergenceWarning
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms
from torchvision.transforms import InterpolationMode
from tqdm import tqdm
from transformers import AutoModel, AutoTokenizer
import warnings

warnings.filterwarnings("ignore", category=ConvergenceWarning)


# =============================================================================
# PROJECT / PROTOCOL
# =============================================================================

ROOT = Path(r"C:\Users\Nebula PC\Downloads\Deep Learning")
PROTOCOL_MODULE = "run_openworld_contrastive_v2_optimized_workers4_C_DRIVE"
PACKAGE_DIR = ROOT / "final_training_pipeline_reviewed"

OUTPUT_ROOT = ROOT / "results_v8_pretrained_representation_benchmark"
FEATURE_ROOT = OUTPUT_ROOT / "feature_cache"
CHILD_ROOT = OUTPUT_ROOT / "children"

EXTERNAL_ROOT = ROOT / "external_models"
PANDERM_REPO = EXTERNAL_ROOT / "PanDerm"
PANDERM_CLASSIFICATION = PANDERM_REPO / "classification"
PANDERM_WEIGHT_DIR = PANDERM_REPO / "weights"
PANDERM_BASE_CKPT = (
    PANDERM_WEIGHT_DIR / "panderm_bb_data6_checkpoint-499.pth"
)
PANDERM_LARGE_CKPT = (
    PANDERM_WEIGHT_DIR / "panderm_ll_data6_checkpoint-499.pth"
)

DERM1M_REPO = EXTERNAL_ROOT / "Derm1M"
DERMFM_REPO = EXTERNAL_ROOT / "DermFM-Zero"

DERM1M_GIT = "https://github.com/SiyuanYan1/Derm1M.git"
DERMFM_GIT = "https://github.com/SiyuanYan1/DermFM-Zero.git"

DERMLIP_PANDERM_HF = (
    "hf-hub:redlessone/DermLIP_PanDerm-base-w-PubMed-256"
)
DERMLIP_B16_HF = "hf-hub:redlessone/DermLIP_ViT-B-16"
DERMFM_HF = "hf-hub:redlessone/DermFM-Zero"
MONET_HF = "suinleelab/monet"

PANDERM_BASE_DRIVE_URL = (
    "https://drive.google.com/file/d/"
    "17J4MjsZu3gdBP6xAQi_NMDVvH65a00HB/view?usp=sharing"
)
PANDERM_LARGE_DRIVE_URL = (
    "https://drive.google.com/file/d/"
    "1SwEzaOlFV_gBKf2UzeowMC8z9UH7AQbE/view?usp=sharing"
)

TARGETS_DEFAULT = ["ISIC 2019", "MCR-SL"]

TEXT_COL = "text_core"
BIOCLINICAL_MODEL_FALLBACK = "emilyalsentzer/Bio_ClinicalBERT"
MAX_TEXT_LEN = 192

NUM_WORKERS = 4
PERSISTENT_WORKERS = True
PREFETCH_FACTOR = 2
PIN_MEMORY = True
USE_AMP = True

OOD_QUANTILE = 0.95
KNN_K = 50
KNN_QUERY_CHUNK = 1024

BALANCE_BETA = 0.9596031602585381
PROBE_MAX_ITER = 1000
PROBE_RANDOM_STATE = 0

LEGACY_SEEDS = [42, 123, 2026]

# Exact frozen source protocol used by the legacy closed checkpoints.
LEGACY_FUSION_DIM = 128
LEGACY_NUM_HEADS = 4
LEGACY_DROPOUT = 0.1353970008207678
LEGACY_IMAGE_SIZE = 224
LEGACY_FREEZE_BACKBONES = False

AUTO_MODELS = [
    "dinov2_vitb14",
    "dinov2_vitl14",
    "biomedclip",
    "monet",
    "dermlip_panderm",
    "dermlip_vitb16",
]
LOCAL_MODELS = [
    "panderm_base",
    "panderm_large",
]
LEGACY_MODELS = [
    "legacy_fused_seed42",
    "legacy_fused_seed123",
    "legacy_fused_seed2026",
]
SPECIAL_MODELS = [
    "bioclinicalbert_text",
]
OPTIONAL_MODELS = [
    "derm_foundation",
    "dermfm_zero",
]

PRIMARY_MODELS = (
    SPECIAL_MODELS
    + LEGACY_MODELS
    + AUTO_MODELS
    + LOCAL_MODELS
)

MODEL_BATCH_SIZE = {
    "dinov2_vitb14": 64,
    "dinov2_vitl14": 20,
    "biomedclip": 64,
    "monet": 16,
    "dermlip_panderm": 32,
    "dermlip_vitb16": 48,
    "dermfm_zero": 16,
    "panderm_base": 64,
    "panderm_large": 24,
    "derm_foundation": 16,
    "legacy_fused_seed42": 64,
    "legacy_fused_seed123": 64,
    "legacy_fused_seed2026": 64,
    "bioclinicalbert_text": 64,
}

CLASS_DISPLAY_NAMES = {
    "AK": "actinic keratosis",
    "BCC": "basal cell carcinoma",
    "MEL": "melanoma",
    "NEV": "nevus",
    "SCC": "squamous cell carcinoma",
    "SK": "seborrheic keratosis",
}

FIXED_ZERO_SHOT_TEMPLATE = "This is a skin image of {}"


# =============================================================================
# SMALL UTILITIES
# =============================================================================

def json_dump(obj, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)

    def default(x):
        if isinstance(x, (np.integer,)):
            return int(x)
        if isinstance(x, (np.floating,)):
            return float(x)
        if isinstance(x, np.ndarray):
            return x.tolist()
        if isinstance(x, Path):
            return str(x)
        raise TypeError(type(x))

    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, default=default)


def safe_text(x) -> str:
    return "" if pd.isna(x) else str(x)


def harmonic(a: float, b: float) -> float:
    if not np.isfinite(a) or not np.isfinite(b) or (a + b) <= 0:
        return 0.0
    return float(2.0 * a * b / (a + b))


def device_from_project():
    if torch.cuda.is_available():
        return torch.device("cuda")
    return torch.device("cpu")


def amp_context(device):
    if USE_AMP and device.type == "cuda":
        return torch.autocast(
            device_type="cuda",
            dtype=torch.float16,
        )
    return nullcontext()


def l2_np(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=np.float32)
    n = np.linalg.norm(x, axis=1, keepdims=True)
    return x / np.clip(n, 1e-12, None)


def concat_modalities(
    image_features: np.ndarray,
    text_features: np.ndarray,
) -> np.ndarray:
    if len(image_features) != len(text_features):
        raise ValueError("Image/text feature row mismatch.")
    a = l2_np(image_features)
    b = l2_np(text_features)
    z = np.concatenate([a, b], axis=1).astype(np.float32)
    return l2_np(z)


def aligned_mean_modalities(
    image_features: np.ndarray,
    text_features: np.ndarray,
) -> np.ndarray:
    if image_features.shape != text_features.shape:
        raise ValueError(
            "Native aligned mean requires equal image/text dimensions: "
            f"{image_features.shape} vs {text_features.shape}"
        )
    a = l2_np(image_features)
    b = l2_np(text_features)
    return l2_np((a + b).astype(np.float32))


def class_order_from_config(known_classes) -> List[str]:
    # KNOWN_CLASSES may be list/tuple in the project.
    classes = [str(x) for x in list(known_classes)]
    if len(classes) != 6:
        raise RuntimeError(f"Expected 6 known classes, got {classes}")
    return classes


def class_names_for_prompts(known_classes) -> List[str]:
    names = []
    for cls in class_order_from_config(known_classes):
        names.append(CLASS_DISPLAY_NAMES.get(cls, cls))
    return names


def effective_number_class_weights(
    y: np.ndarray,
    n_classes: int,
    beta: float,
) -> Dict[int, float]:
    counts = np.bincount(y.astype(int), minlength=n_classes).astype(np.float64)
    weights = np.zeros(n_classes, dtype=np.float64)

    for c in range(n_classes):
        if counts[c] <= 0:
            raise RuntimeError(f"Class {c} absent from source_train.")
        effective_num = 1.0 - (beta ** counts[c])
        weights[c] = (1.0 - beta) / max(effective_num, 1e-12)

    # Normalize mean class weight to 1, matching common weighted-CE practice.
    weights = weights / weights.mean()
    return {int(c): float(weights[c]) for c in range(n_classes)}


def windows_safe_filename_component(value: str) -> str:
    """
    Sanitize one path component for Windows.

    Important for target split keys such as:
        "ISIC 2019::target_val_ow"
    because ':' is forbidden in Windows filenames.

    We preserve human readability while replacing all Windows-reserved
    filename characters. Trailing spaces/dots are stripped as well.
    """
    value = str(value)
    value = re.sub(r'[<>:"/\\|?*]+', "__", value)
    value = re.sub(r"__+", "__", value)
    value = value.rstrip(" .")

    # Avoid Windows reserved DOS device names.
    reserved = {
        "CON", "PRN", "AUX", "NUL",
        *(f"COM{i}" for i in range(1, 10)),
        *(f"LPT{i}" for i in range(1, 10)),
    }
    if value.upper() in reserved:
        value = f"_{value}_"

    if not value:
        value = "_empty_"

    return value


def cache_path(model_name: str, split_key: str, kind: str) -> Path:
    safe_model = windows_safe_filename_component(model_name)
    safe_split = windows_safe_filename_component(split_key)
    safe_kind = windows_safe_filename_component(kind)
    return FEATURE_ROOT / safe_model / f"{safe_split}__{safe_kind}.npz"


def save_feature_cache(
    path: Path,
    features: np.ndarray,
    indices: np.ndarray,
    *,
    metadata: Optional[dict] = None,
):
    path.parent.mkdir(parents=True, exist_ok=True)
    meta_json = json.dumps(metadata or {}, sort_keys=True)
    np.savez_compressed(
        path,
        features=np.asarray(features, dtype=np.float32),
        indices=np.asarray(indices, dtype=np.int64),
        metadata=np.asarray([meta_json]),
    )


def load_feature_cache(path: Path):
    z = np.load(path, allow_pickle=False)
    features = z["features"].astype(np.float32)
    indices = z["indices"].astype(np.int64)
    metadata = {}
    if "metadata" in z.files:
        metadata = json.loads(str(z["metadata"][0]))
    return features, indices, metadata


def validate_indices(indices: np.ndarray, n: int, label: str):
    expected = np.arange(n, dtype=np.int64)
    if not np.array_equal(indices, expected):
        raise RuntimeError(
            f"{label}: cached/extracted row order mismatch."
        )


# =============================================================================
# DATA LOADING
# =============================================================================

class ImageDataset(Dataset):
    def __init__(self, frame: pd.DataFrame, transform):
        self.df = frame.reset_index(drop=True).copy()
        self.transform = transform

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        path = self.df.iloc[idx]["image_path"]
        image = Image.open(path).convert("RGB")
        return {
            "image": self.transform(image),
            "index": torch.tensor(idx, dtype=torch.long),
        }


class LegacyMultimodalDataset(Dataset):
    def __init__(
        self,
        frame: pd.DataFrame,
        tokenizer,
        transform,
        text_col: str,
        max_text_len: int,
    ):
        self.df = frame.reset_index(drop=True).copy()
        self.transform = transform

        enc = tokenizer(
            [safe_text(x) for x in self.df[text_col].tolist()],
            padding="max_length",
            truncation=True,
            max_length=max_text_len,
            return_tensors="pt",
        )
        self.input_ids = enc["input_ids"].contiguous()
        self.attention_mask = enc["attention_mask"].contiguous()

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        image = Image.open(row["image_path"]).convert("RGB")
        return {
            "pixel_values": self.transform(image),
            "input_ids": self.input_ids[idx],
            "attention_mask": self.attention_mask[idx],
            "index": torch.tensor(idx, dtype=torch.long),
        }


def load_protocol_frames(targets: List[str]):
    sys.path.insert(0, str(ROOT))
    protocol = __import__(PROTOCOL_MODULE)
    protocol.preflight(force_scan=False)
    resolved_roots = protocol.load_resolved_roots()

    sys.path.insert(0, str(PACKAGE_DIR))
    from final_training_pipeline_reviewed.preprocessing import (
        add_known_unknown_columns,
        select_split,
        validate_frozen_protocol,
    )

    source_df = protocol._call_load_standardized_splits(
        csv_path=str(protocol.STANDARDIZED_CSV),
        image_roots=[str(p) for p in protocol.SOURCE_IMAGE_ROOTS],
        dataset_name=protocol.SOURCE_DATASET,
        required_text_col=TEXT_COL,
    )
    validate_frozen_protocol(source_df)
    source_df = add_known_unknown_columns(source_df)

    frames = {
        "source_train": select_split(
            source_df, "source_train"
        ).reset_index(drop=True),
        "source_val": select_split(
            source_df, "source_val"
        ).reset_index(drop=True),
    }

    for target in targets:
        target_df = protocol._call_load_standardized_splits(
            csv_path=str(protocol.STANDARDIZED_CSV),
            image_roots=resolved_roots[target],
            dataset_name=target,
            required_text_col=TEXT_COL,
        )
        target_df = add_known_unknown_columns(target_df)

        tval = select_split(
            target_df, "target_val_ow"
        ).reset_index(drop=True)

        frames[f"{target}::target_val_ow"] = tval

    return protocol, frames


# =============================================================================
# OFFICIAL MODEL ADAPTERS
# =============================================================================

@dataclass
class EncoderBundle:
    name: str
    model: object
    image_transform: object
    device: torch.device
    image_feature_kind: str
    native_tokenizer: object = None
    native_text_kind: Optional[str] = None
    notes: Optional[dict] = None


def freeze_eval(model):
    if hasattr(model, "eval"):
        model.eval()
    if hasattr(model, "parameters"):
        for p in model.parameters():
            p.requires_grad_(False)
    return model


def load_dinov2(model_name: str, device) -> EncoderBundle:
    hub_name = {
        "dinov2_vitb14": "dinov2_vitb14",
        "dinov2_vitl14": "dinov2_vitl14",
    }[model_name]

    model = torch.hub.load(
        "facebookresearch/dinov2",
        hub_name,
    )
    model = freeze_eval(model.to(device))

    transform = transforms.Compose(
        [
            transforms.Resize(
                256,
                interpolation=InterpolationMode.BICUBIC,
            ),
            transforms.CenterCrop(224),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=(0.485, 0.456, 0.406),
                std=(0.229, 0.224, 0.225),
            ),
        ]
    )

    return EncoderBundle(
        name=model_name,
        model=model,
        image_transform=transform,
        device=device,
        image_feature_kind="dinov2_cls",
        notes={
            "official_loader": (
                f"torch.hub.load('facebookresearch/dinov2','{hub_name}')"
            ),
            "official_eval_transform": (
                "Resize256 bicubic -> CenterCrop224 -> ImageNet norm"
            ),
        },
    )


def load_biomedclip(device) -> EncoderBundle:
    try:
        import open_clip
    except Exception as e:
        raise RuntimeError(
            "BiomedCLIP requires open_clip_torch. "
            "Install with: pip install open_clip_torch"
        ) from e

    model_id = (
        "hf-hub:"
        "microsoft/BiomedCLIP-PubMedBERT_256-vit_base_patch16_224"
    )

    model, _, preprocess_val = (
        open_clip.create_model_and_transforms(model_id)
    )
    tokenizer = open_clip.get_tokenizer(model_id)

    model = freeze_eval(model.to(device))

    return EncoderBundle(
        name="biomedclip",
        model=model,
        image_transform=preprocess_val,
        device=device,
        image_feature_kind="openclip_encode_image",
        native_tokenizer=tokenizer,
        native_text_kind="openclip_encode_text",
        notes={
            "official_loader": (
                "open_clip.create_model_and_transforms("
                "'hf-hub:microsoft/"
                "BiomedCLIP-PubMedBERT_256-vit_base_patch16_224')"
            ),
        },
    )


def _ensure_official_repo(path: Path, git_url: str):
    """
    Clone an official repository only when it is not already present.
    Existing clones are never modified automatically.
    """
    if path.exists():
        if not (path / ".git").exists():
            raise RuntimeError(
                f"{path} exists but is not a git clone. "
                "Move/remove it or clone the official repository there."
            )
        return

    path.parent.mkdir(parents=True, exist_ok=True)
    print(
        f"[V8.2] Cloning official repository:\n"
        f"  {git_url}\n"
        f"  -> {path}",
        flush=True,
    )
    subprocess.check_call(
        ["git", "clone", "--depth", "1", git_url, str(path)]
    )


def _import_repo_open_clip(repo_src: Path):
    """
    Import the repository-bundled open_clip fork.

    V8 launches every model in its own Python child process, so replacing the
    generic open_clip import inside this child cannot contaminate another model.
    """
    package_dir = repo_src / "open_clip"
    if not package_dir.exists():
        raise FileNotFoundError(
            f"Bundled open_clip not found: {package_dir}"
        )

    for name in list(sys.modules):
        if name == "open_clip" or name.startswith("open_clip."):
            del sys.modules[name]

    sys.path.insert(0, str(repo_src))
    return importlib.import_module("open_clip")


class _HFImageProcessorTransform:
    """Single-PIL -> tensor wrapper around an official HF processor."""

    def __init__(self, processor):
        self.processor = processor

    def __call__(self, image):
        encoded = self.processor(
            images=image,
            return_tensors="pt",
        )
        return encoded["pixel_values"][0]


class _HFTokenizerWrapper:
    """Return a BatchEncoding; BatchEncoding implements `.to(device)`."""

    def __init__(self, tokenizer):
        self.tokenizer = tokenizer

    def __call__(self, texts):
        return self.tokenizer(
            texts,
            padding=True,
            truncation=True,
            return_tensors="pt",
        )


class _HFCLIPAdapter(nn.Module):
    """
    Version-stable CLIP embedding adapter for MONET.

    MONET is a CLIPModel with a learned 768-D shared projection space.
    Recent Transformers releases may return BaseModelOutputWithPooling from
    get_image_features()/get_text_features() for some CLIP code paths rather
    than the final projected tensor expected by older releases.

    To avoid version-dependent behavior, explicitly reproduce CLIPModel's
    intended embedding path:

        image:
            vision_model -> pooler_output -> visual_projection

        text:
            text_model -> pooler_output -> text_projection

    This is essential: using pooler_output WITHOUT the projection would put
    image features in the 1024-D ViT hidden space rather than MONET's shared
    768-D image-text contrastive space.
    """

    def __init__(self, model):
        super().__init__()
        self.model = model

        required = (
            "vision_model",
            "text_model",
            "visual_projection",
            "text_projection",
        )
        missing = [
            name
            for name in required
            if not hasattr(self.model, name)
        ]
        if missing:
            raise RuntimeError(
                "MONET Hugging Face checkpoint is not exposing the expected "
                f"CLIPModel modules; missing={missing}. "
                f"Observed type={type(self.model)}"
            )

    @staticmethod
    def _pooler_output(outputs, branch: str):
        """
        Accept HF ModelOutput, OrderedDict/dict, or legacy tuple return types.
        """
        if hasattr(outputs, "pooler_output"):
            pooled = outputs.pooler_output
        elif isinstance(outputs, dict) and "pooler_output" in outputs:
            pooled = outputs["pooler_output"]
        elif isinstance(outputs, (tuple, list)) and len(outputs) >= 2:
            pooled = outputs[1]
        else:
            keys = (
                list(outputs.keys())
                if hasattr(outputs, "keys")
                else None
            )
            raise RuntimeError(
                f"MONET {branch} encoder output has no pooler_output. "
                f"type={type(outputs)}, keys={keys}"
            )

        if not torch.is_tensor(pooled) or pooled.ndim != 2:
            raise RuntimeError(
                f"MONET {branch} pooler_output must be NxD tensor; "
                f"observed={type(pooled)} "
                f"shape={getattr(pooled, 'shape', None)}"
            )
        return pooled

    def encode_image(self, pixel_values, normalize=False):
        outputs = self.model.vision_model(
            pixel_values=pixel_values,
            return_dict=True,
        )
        pooled = self._pooler_output(
            outputs,
            "vision",
        )
        feat = self.model.visual_projection(
            pooled
        )

        if not torch.is_tensor(feat) or feat.ndim != 2:
            raise RuntimeError(
                "MONET visual_projection did not return an NxD tensor: "
                f"type={type(feat)}, shape={getattr(feat, 'shape', None)}"
            )

        if normalize:
            feat = F.normalize(feat, dim=-1)
        return feat

    def encode_text(self, tokens, normalize=False):
        if not hasattr(tokens, "items"):
            raise TypeError(
                "HF text input must be a BatchEncoding/dict."
            )

        kwargs = {
            k: v
            for k, v in tokens.items()
            if k in {
                "input_ids",
                "attention_mask",
                "position_ids",
                "token_type_ids",
            }
        }

        outputs = self.model.text_model(
            **kwargs,
            return_dict=True,
        )
        pooled = self._pooler_output(
            outputs,
            "text",
        )
        feat = self.model.text_projection(
            pooled
        )

        if not torch.is_tensor(feat) or feat.ndim != 2:
            raise RuntimeError(
                "MONET text_projection did not return an NxD tensor: "
                f"type={type(feat)}, shape={getattr(feat, 'shape', None)}"
            )

        if normalize:
            feat = F.normalize(feat, dim=-1)
        return feat


def load_dermlip(
    model_name: str,
    model_id: str,
    device,
) -> EncoderBundle:
    """
    Official Derm1M path.

    The authors' released evaluation code is executed from Derm1M/src and uses
    its bundled open_clip fork. We reproduce that rather than assuming the
    generic pip OpenCLIP package contains the PanDerm-specific architecture.
    """
    _ensure_official_repo(
        DERM1M_REPO,
        DERM1M_GIT,
    )
    open_clip = _import_repo_open_clip(
        DERM1M_REPO / "src"
    )

    model, _, preprocess_val = (
        open_clip.create_model_and_transforms(
            model_id,
            device=device,
        )
    )
    tokenizer = open_clip.get_tokenizer(
        model_id
    )
    model = freeze_eval(model.to(device))

    return EncoderBundle(
        name=model_name,
        model=model,
        image_transform=preprocess_val,
        device=device,
        image_feature_kind="openclip_encode_image",
        native_tokenizer=tokenizer,
        native_text_kind="openclip_encode_text",
        notes={
            "official_repo": DERM1M_GIT,
            "official_model": model_id,
            "open_clip_source": str(
                DERM1M_REPO / "src" / "open_clip"
            ),
        },
    )


def load_dermlip_panderm(device) -> EncoderBundle:
    return load_dermlip(
        "dermlip_panderm",
        DERMLIP_PANDERM_HF,
        device,
    )


def load_dermlip_vitb16(device) -> EncoderBundle:
    return load_dermlip(
        "dermlip_vitb16",
        DERMLIP_B16_HF,
        device,
    )


def load_dermfm_zero(device) -> EncoderBundle:
    """
    OPTIONAL gated model.

    IMPORTANT:
    The official DermFM-Zero model card states that 38,404 ISIC Archive images
    were used in its pretraining corpus. ISIC-2019 metrics from this model must
    therefore be treated as overlap-risk / exploratory rather than clean DG.
    """
    _ensure_official_repo(
        DERMFM_REPO,
        DERMFM_GIT,
    )
    open_clip = _import_repo_open_clip(
        DERMFM_REPO / "src"
    )

    try:
        model, _, preprocess_val = (
            open_clip.create_model_and_transforms(
                DERMFM_HF,
                device=device,
            )
        )
        tokenizer = open_clip.get_tokenizer(
            DERMFM_HF
        )
    except Exception as e:
        raise RuntimeError(
            "DermFM-Zero is a gated Hugging Face release. "
            "Request/accept access at "
            "https://huggingface.co/redlessone/DermFM-Zero "
            "and authenticate your Hugging Face token before rerunning "
            "with --include-dermfm-zero."
        ) from e

    model = freeze_eval(model.to(device))

    return EncoderBundle(
        name="dermfm_zero",
        model=model,
        image_transform=preprocess_val,
        device=device,
        image_feature_kind="openclip_encode_image",
        native_tokenizer=tokenizer,
        native_text_kind="openclip_encode_text",
        notes={
            "official_repo": DERMFM_GIT,
            "official_model": DERMFM_HF,
            "isic_overlap_risk": True,
            "reported_isic_archive_pretraining_images": 38404,
        },
    )


def load_monet(device) -> EncoderBundle:
    """
    MONET authors explicitly provide this Hugging Face implementation in the
    original repository, alongside the OpenAI-CLIP implementation.

    This avoids environment-specific OpenAI-CLIP runtime/state-dict issues while
    still using the authors' released MONET model.
    """
    try:
        from transformers import (
            AutoModelForZeroShotImageClassification,
            AutoProcessor,
        )
    except Exception as e:
        raise RuntimeError(
            "MONET Hugging Face loader requires transformers."
        ) from e

    processor = AutoProcessor.from_pretrained(
        MONET_HF
    )
    hf_model = (
        AutoModelForZeroShotImageClassification
        .from_pretrained(MONET_HF)
    )

    adapter = _HFCLIPAdapter(
        hf_model
    )
    adapter = freeze_eval(
        adapter.to(device)
    )

    tokenizer = getattr(
        processor,
        "tokenizer",
        None,
    )
    if tokenizer is None:
        raise RuntimeError(
            "MONET AutoProcessor did not expose its tokenizer."
        )

    return EncoderBundle(
        name="monet",
        model=adapter,
        image_transform=_HFImageProcessorTransform(
            processor
        ),
        device=device,
        image_feature_kind="openclip_encode_image",
        native_tokenizer=_HFTokenizerWrapper(
            tokenizer
        ),
        native_text_kind="openclip_encode_text",
        notes={
            "official_repo": (
                "https://github.com/suinleelab/MONET"
            ),
            "official_hf_model": MONET_HF,
            "loader": (
                "AutoProcessor + "
                "AutoModelForZeroShotImageClassification"
            ),
        },
    )


def _import_panderm_models():
    if not PANDERM_CLASSIFICATION.exists():
        raise FileNotFoundError(
            "Official PanDerm repository not found.\n"
            f"Expected: {PANDERM_REPO}\n"
            "Clone it with:\n"
            f'  git clone https://github.com/SiyuanYan1/PanDerm '
            f'"{PANDERM_REPO}"'
        )

    classification_str = str(PANDERM_CLASSIFICATION)
    if classification_str not in sys.path:
        sys.path.insert(0, classification_str)

    # PanDerm intentionally imports top-level package `models` from its
    # classification directory. In this isolated child process that is safe.
    return importlib.import_module("models")


def load_panderm(model_name: str, device) -> EncoderBundle:
    if model_name == "panderm_base":
        checkpoint = PANDERM_BASE_CKPT
        official_name = "PanDerm_Base_LP"
        drive_url = PANDERM_BASE_DRIVE_URL
    elif model_name == "panderm_large":
        checkpoint = PANDERM_LARGE_CKPT
        official_name = "PanDerm_Large_LP"
        drive_url = PANDERM_LARGE_DRIVE_URL
    else:
        raise ValueError(model_name)

    if not checkpoint.exists():
        raise FileNotFoundError(
            f"Missing PanDerm checkpoint: {checkpoint}\n"
            f"Official download: {drive_url}\n"
            f"Place it under: {PANDERM_WEIGHT_DIR}"
        )

    models_pkg = _import_panderm_models()
    if not hasattr(models_pkg, "get_encoder"):
        raise RuntimeError(
            "Official PanDerm `models.get_encoder` was not found."
        )

    args = SimpleNamespace(
        pretrained_checkpoint=str(checkpoint),
    )
    model, eval_transform = models_pkg.get_encoder(
        args,
        official_name,
    )
    model = freeze_eval(model.to(device))

    return EncoderBundle(
        name=model_name,
        model=model,
        image_transform=eval_transform,
        device=device,
        image_feature_kind="panderm_forward_features",
        notes={
            "official_model_name": official_name,
            "official_checkpoint": str(checkpoint),
            "official_feature_call": (
                "model.forward_features(batch, is_train=False)"
            ),
        },
    )


def load_encoder(model_name: str, device) -> EncoderBundle:
    if model_name.startswith("dinov2_"):
        return load_dinov2(model_name, device)
    if model_name == "biomedclip":
        return load_biomedclip(device)
    if model_name == "monet":
        return load_monet(device)
    if model_name == "dermlip_panderm":
        return load_dermlip_panderm(device)
    if model_name == "dermlip_vitb16":
        return load_dermlip_vitb16(device)
    if model_name == "dermfm_zero":
        return load_dermfm_zero(device)
    if model_name in {"panderm_base", "panderm_large"}:
        return load_panderm(model_name, device)
    raise ValueError(f"No image encoder loader for {model_name}")


# =============================================================================
# FEATURE EXTRACTION
# =============================================================================

@torch.inference_mode()
def encode_image_batch(bundle: EncoderBundle, batch: torch.Tensor):
    model = bundle.model
    kind = bundle.image_feature_kind

    with amp_context(bundle.device):
        if kind == "dinov2_cls":
            out = model(batch)
            if isinstance(out, dict):
                if "x_norm_clstoken" in out:
                    out = out["x_norm_clstoken"]
                else:
                    raise RuntimeError(
                        f"Unexpected DINO output dict keys: {out.keys()}"
                    )

        elif kind == "openclip_encode_image":
            try:
                out = model.encode_image(batch, normalize=False)
            except TypeError:
                out = model.encode_image(batch)

        elif kind == "openai_clip_encode_image":
            out = model.encode_image(batch)

        elif kind == "panderm_forward_features":
            out = model.forward_features(
                batch,
                is_train=False,
            )

        else:
            raise ValueError(kind)

    if isinstance(out, (tuple, list)):
        out = out[0]
    if isinstance(out, dict):
        # Do not silently choose a representation.
        raise RuntimeError(
            f"{bundle.name}: unresolved feature dict keys: {out.keys()}"
        )

    out = out.float()
    if out.ndim != 2:
        raise RuntimeError(
            f"{bundle.name}: expected NxD image embedding, got {out.shape}"
        )
    return out


def extract_image_features(
    bundle: EncoderBundle,
    frame: pd.DataFrame,
    split_key: str,
    *,
    force: bool = False,
):
    path = cache_path(
        bundle.name,
        split_key,
        "image",
    )

    if path.exists() and not force:
        features, indices, metadata = load_feature_cache(path)
        validate_indices(indices, len(frame), f"{bundle.name}/{split_key}")
        return features

    dataset = ImageDataset(
        frame,
        bundle.image_transform,
    )
    loader = DataLoader(
        dataset,
        batch_size=MODEL_BATCH_SIZE[bundle.name],
        shuffle=False,
        drop_last=False,
        num_workers=NUM_WORKERS,
        pin_memory=PIN_MEMORY and torch.cuda.is_available(),
        persistent_workers=(
            PERSISTENT_WORKERS if NUM_WORKERS > 0 else False
        ),
        prefetch_factor=(
            PREFETCH_FACTOR if NUM_WORKERS > 0 else None
        ),
    )

    all_features = []
    all_indices = []

    for batch in tqdm(
        loader,
        desc=f"features {bundle.name} {split_key}",
    ):
        images = batch["image"].to(
            bundle.device,
            non_blocking=torch.cuda.is_available(),
        )
        feats = encode_image_batch(bundle, images)
        all_features.append(feats.cpu().numpy())
        all_indices.append(batch["index"].numpy())

    features = np.concatenate(all_features, axis=0).astype(np.float32)
    indices = np.concatenate(all_indices, axis=0).astype(np.int64)
    validate_indices(indices, len(frame), f"{bundle.name}/{split_key}")

    if not np.isfinite(features).all():
        raise RuntimeError(f"{bundle.name}/{split_key}: non-finite features.")

    save_feature_cache(
        path,
        features,
        indices,
        metadata={
            "model": bundle.name,
            "kind": "image",
            "feature_dim": int(features.shape[1]),
            **(bundle.notes or {}),
        },
    )
    return features


@torch.inference_mode()
def extract_native_text_features(
    bundle: EncoderBundle,
    texts: List[str],
    split_key: str,
    *,
    force: bool = False,
):
    if bundle.native_tokenizer is None:
        raise RuntimeError(f"{bundle.name} has no native text encoder.")

    path = cache_path(
        bundle.name,
        split_key,
        "native_text",
    )

    if path.exists() and not force:
        features, indices, _ = load_feature_cache(path)
        validate_indices(indices, len(texts), f"{bundle.name}/{split_key}/text")
        return features

    batch_size = MODEL_BATCH_SIZE[bundle.name]
    all_features = []
    all_indices = []

    for start in tqdm(
        range(0, len(texts), batch_size),
        desc=f"native text {bundle.name} {split_key}",
    ):
        batch_text = texts[start:start + batch_size]

        if bundle.native_text_kind == "openclip_encode_text":
            tokens = bundle.native_tokenizer(batch_text).to(bundle.device)
            with amp_context(bundle.device):
                try:
                    feat = bundle.model.encode_text(
                        tokens,
                        normalize=False,
                    )
                except TypeError:
                    feat = bundle.model.encode_text(tokens)

        elif bundle.native_text_kind == "openai_clip_encode_text":
            # OpenAI CLIP tokenizer supports truncate=True.
            try:
                tokens = bundle.native_tokenizer(
                    batch_text,
                    truncate=True,
                )
            except TypeError:
                tokens = bundle.native_tokenizer(batch_text)
            tokens = tokens.to(bundle.device)

            with amp_context(bundle.device):
                feat = bundle.model.encode_text(tokens)

        else:
            raise ValueError(bundle.native_text_kind)

        feat = feat.float()
        if feat.ndim != 2:
            raise RuntimeError(
                f"{bundle.name}: native text feature shape {feat.shape}"
            )

        all_features.append(feat.cpu().numpy())
        all_indices.append(
            np.arange(
                start,
                start + len(batch_text),
                dtype=np.int64,
            )
        )

    features = np.concatenate(all_features, axis=0).astype(np.float32)
    indices = np.concatenate(all_indices, axis=0)
    validate_indices(indices, len(texts), f"{bundle.name}/{split_key}/text")

    save_feature_cache(
        path,
        features,
        indices,
        metadata={
            "model": bundle.name,
            "kind": "native_text",
            "feature_dim": int(features.shape[1]),
        },
    )
    return features


def bioclinical_model_name():
    sys.path.insert(0, str(PACKAGE_DIR))
    try:
        from config import ExperimentConfig
        cfg = ExperimentConfig(seed=42)
        return str(cfg.text_model_name)
    except Exception:
        return BIOCLINICAL_MODEL_FALLBACK


@torch.inference_mode()
def extract_bioclinical_text_features(
    frame: pd.DataFrame,
    split_key: str,
    *,
    force: bool = False,
):
    model_name = bioclinical_model_name()
    cache_model = "bioclinicalbert_text_core"
    path = cache_path(
        cache_model,
        split_key,
        "text_cls",
    )

    if path.exists() and not force:
        features, indices, _ = load_feature_cache(path)
        validate_indices(indices, len(frame), f"BioClinical/{split_key}")
        return features

    device = device_from_project()
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModel.from_pretrained(model_name).to(device)
    model = freeze_eval(model)

    texts = [safe_text(x) for x in frame[TEXT_COL].tolist()]
    batch_size = MODEL_BATCH_SIZE["bioclinicalbert_text"]
    all_features = []
    all_indices = []

    for start in tqdm(
        range(0, len(texts), batch_size),
        desc=f"BioClinicalBERT {split_key}",
    ):
        bt = texts[start:start + batch_size]
        enc = tokenizer(
            bt,
            padding=True,
            truncation=True,
            max_length=MAX_TEXT_LEN,
            return_tensors="pt",
        )
        enc = {
            k: v.to(device, non_blocking=torch.cuda.is_available())
            for k, v in enc.items()
        }

        with amp_context(device):
            out = model(**enc).last_hidden_state[:, 0, :]

        all_features.append(out.float().cpu().numpy())
        all_indices.append(
            np.arange(start, start + len(bt), dtype=np.int64)
        )

    features = np.concatenate(all_features, axis=0).astype(np.float32)
    indices = np.concatenate(all_indices)
    validate_indices(indices, len(frame), f"BioClinical/{split_key}")

    save_feature_cache(
        path,
        features,
        indices,
        metadata={
            "model": model_name,
            "kind": "CLS",
            "text_col": TEXT_COL,
            "max_length": MAX_TEXT_LEN,
            "feature_dim": int(features.shape[1]),
        },
    )

    del model
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    return features


# =============================================================================
# LEGACY FROZEN FUSED REPRESENTATION
# =============================================================================

def extract_legacy_fused(
    seed: int,
    frame: pd.DataFrame,
    split_key: str,
    protocol,
    *,
    force: bool = False,
):
    model_name = f"legacy_fused_seed{seed}"
    path = cache_path(
        model_name,
        split_key,
        "legacy_fused",
    )

    if path.exists() and not force:
        features, indices, _ = load_feature_cache(path)
        validate_indices(indices, len(frame), f"{model_name}/{split_key}")
        return features

    sys.path.insert(0, str(PACKAGE_DIR))
    from config import ExperimentConfig, KNOWN_CLASSES
    from final_training_pipeline_reviewed.models import build_model
    from final_training_pipeline_reviewed.transforms import get_eval_transform

    cfg = ExperimentConfig(seed=seed)

    registry = pd.read_csv(protocol.CLOSED_CHECKPOINT_REGISTRY)
    registry["best_checkpoint"] = (
        registry["best_checkpoint"]
        .astype(str)
        .str.replace(
            r"D:\Deep Learning",
            str(ROOT),
            regex=False,
        )
    )

    hit = registry[
        (registry["model_family"].astype(str) == "mobilevit_cross_attention")
        & (registry["text_col"].astype(str) == TEXT_COL)
        & (registry["seed"].astype(int) == seed)
    ]
    if len(hit) != 1:
        raise RuntimeError(
            f"Legacy seed {seed}: expected one checkpoint, got {len(hit)}"
        )

    checkpoint = Path(hit.iloc[0]["best_checkpoint"])
    state_payload = torch.load(checkpoint, map_location="cpu")
    state = state_payload.get("model_state_dict", state_payload)

    # Reconstruct the legacy model from the FROZEN experiment protocol,
    # not from current ExperimentConfig defaults.
    required_key = "fusion.image_proj.weight"
    if required_key not in state:
        raise RuntimeError(
            f"Legacy checkpoint missing required key: {required_key}"
        )

    checkpoint_fusion_dim = int(state[required_key].shape[0])
    if checkpoint_fusion_dim != LEGACY_FUSION_DIM:
        raise RuntimeError(
            "Legacy checkpoint/protocol fusion-dimension mismatch: "
            f"checkpoint={checkpoint_fusion_dim}, "
            f"expected frozen protocol={LEGACY_FUSION_DIM}"
        )

    # Additional geometry audits before construction.
    expected_shapes = {
        "fusion.text_proj.weight": (LEGACY_FUSION_DIM, 768),
        "classifier.3.weight": (len(KNOWN_CLASSES), LEGACY_FUSION_DIM),
    }
    for key, expected in expected_shapes.items():
        if key in state and tuple(state[key].shape) != tuple(expected):
            raise RuntimeError(
                f"Legacy checkpoint geometry mismatch for {key}: "
                f"observed={tuple(state[key].shape)}, expected={expected}"
            )

    model = build_model(
        "mobilevit_cross_attention",
        cfg.image_model_name,
        cfg.text_model_name,
        len(KNOWN_CLASSES),
        fusion_dim=LEGACY_FUSION_DIM,
        num_heads=LEGACY_NUM_HEADS,
        freeze_backbones=LEGACY_FREEZE_BACKBONES,
        dropout=LEGACY_DROPOUT,
    )
    model.load_state_dict(state, strict=True)

    device = device_from_project()
    model = freeze_eval(model.to(device))

    tokenizer = AutoTokenizer.from_pretrained(cfg.text_model_name)
    transform = get_eval_transform(LEGACY_IMAGE_SIZE)

    dataset = LegacyMultimodalDataset(
        frame,
        tokenizer,
        transform,
        TEXT_COL,
        MAX_TEXT_LEN,
    )
    loader = DataLoader(
        dataset,
        batch_size=MODEL_BATCH_SIZE[model_name],
        shuffle=False,
        drop_last=False,
        num_workers=NUM_WORKERS,
        pin_memory=PIN_MEMORY and torch.cuda.is_available(),
        persistent_workers=(
            PERSISTENT_WORKERS if NUM_WORKERS > 0 else False
        ),
        prefetch_factor=(
            PREFETCH_FACTOR if NUM_WORKERS > 0 else None
        ),
    )

    feats_all = []
    idx_all = []

    with torch.inference_mode():
        for batch in tqdm(
            loader,
            desc=f"legacy fused seed{seed} {split_key}",
        ):
            pixels = batch["pixel_values"].to(
                device,
                non_blocking=torch.cuda.is_available(),
            )
            ids = batch["input_ids"].to(
                device,
                non_blocking=torch.cuda.is_available(),
            )
            mask = batch["attention_mask"].to(
                device,
                non_blocking=torch.cuda.is_available(),
            )

            with amp_context(device):
                feat = model.extract_features(
                    pixels,
                    ids,
                    mask,
                )

            feats_all.append(feat.float().cpu().numpy())
            idx_all.append(batch["index"].numpy())

    features = np.concatenate(feats_all).astype(np.float32)
    indices = np.concatenate(idx_all).astype(np.int64)
    validate_indices(indices, len(frame), f"{model_name}/{split_key}")

    save_feature_cache(
        path,
        features,
        indices,
        metadata={
            "model": "legacy_mobilevit_cross_attention_text_core",
            "seed": seed,
            "checkpoint": str(checkpoint),
            "feature_dim": int(features.shape[1]),
        },
    )

    del model
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    return features


# =============================================================================
# OPTIONAL GOOGLE DERM FOUNDATION
# =============================================================================

def extract_derm_foundation(
    frame: pd.DataFrame,
    split_key: str,
    *,
    force: bool = False,
):
    """
    Official Google/Hugging Face path. Kept optional because it requires:
      1) accepting model terms on Hugging Face;
      2) TensorFlow/Keras in the environment.

    TensorFlow GPU is disabled intentionally so it does not fight PyTorch for
    VRAM in the user's main environment.
    """
    path = cache_path(
        "derm_foundation",
        split_key,
        "image",
    )

    if path.exists() and not force:
        features, indices, _ = load_feature_cache(path)
        validate_indices(indices, len(frame), f"DermFoundation/{split_key}")
        return features

    try:
        import tensorflow as tf
        try:
            tf.config.set_visible_devices([], "GPU")
        except Exception:
            pass

        from huggingface_hub import from_pretrained_keras
    except Exception as e:
        raise RuntimeError(
            "Derm Foundation requires TensorFlow and a Hugging Face Hub "
            "version exposing from_pretrained_keras. It is optional."
        ) from e

    loaded_model = from_pretrained_keras(
        "google/derm-foundation"
    )
    infer = loaded_model.signatures["serving_default"]

    features = []

    for start in tqdm(
        range(0, len(frame), MODEL_BATCH_SIZE["derm_foundation"]),
        desc=f"Derm Foundation {split_key}",
    ):
        serialised = []

        chunk = frame.iloc[
            start:start + MODEL_BATCH_SIZE["derm_foundation"]
        ]

        for image_path in chunk["image_path"].tolist():
            image = Image.open(image_path).convert("RGB")
            image = image.resize(
                (448, 448),
                resample=Image.Resampling.BICUBIC,
            )

            buf = io.BytesIO()
            image.save(buf, format="PNG")
            image_bytes = buf.getvalue()

            example = tf.train.Example(
                features=tf.train.Features(
                    feature={
                        "image/encoded": tf.train.Feature(
                            bytes_list=tf.train.BytesList(
                                value=[image_bytes]
                            )
                        )
                    }
                )
            ).SerializeToString()

            serialised.append(example)

        output = infer(
            inputs=tf.constant(serialised)
        )
        if "embedding" not in output:
            raise RuntimeError(
                f"Derm Foundation output keys: {list(output.keys())}"
            )

        features.append(
            output["embedding"].numpy().astype(np.float32)
        )

    features = np.concatenate(features, axis=0)
    indices = np.arange(len(frame), dtype=np.int64)

    if features.ndim != 2 or features.shape[1] != 6144:
        raise RuntimeError(
            f"Derm Foundation expected Nx6144, got {features.shape}"
        )

    save_feature_cache(
        path,
        features,
        indices,
        metadata={
            "model": "google/derm-foundation",
            "feature_dim": 6144,
            "input": "448x448 encoded PNG",
        },
    )
    return features


# =============================================================================
# LINEAR PROBE
# =============================================================================

def prepare_probe_features(
    x: np.ndarray,
    norm_mode: str,
):
    if norm_mode == "raw":
        return np.asarray(x, dtype=np.float64)
    if norm_mode == "l2":
        return l2_np(x).astype(np.float64)
    raise ValueError(norm_mode)


def fit_probe_variants(
    x_train: np.ndarray,
    y_train: np.ndarray,
    x_val: np.ndarray,
    y_val: np.ndarray,
    n_classes: int,
):
    class_weights = effective_number_class_weights(
        y_train,
        n_classes,
        BALANCE_BETA,
    )

    protocols = [
        ("raw_unweighted", "raw", None),
        ("raw_effective_weighted", "raw", class_weights),
        ("l2_unweighted", "l2", None),
        ("l2_effective_weighted", "l2", class_weights),
    ]

    rows = []
    fitted = {}

    feature_dim = int(x_train.shape[1])
    cost = float(feature_dim * n_classes / 100.0)

    for name, norm_mode, weight_dict in protocols:
        tr = prepare_probe_features(x_train, norm_mode)
        va = prepare_probe_features(x_val, norm_mode)

        clf = LogisticRegression(
            C=cost,
            max_iter=PROBE_MAX_ITER,
            random_state=PROBE_RANDOM_STATE,
            solver="lbfgs",
            class_weight=weight_dict,
        )
        clf.fit(tr, y_train)

        pred = clf.predict(va)
        macro_f1 = float(
            f1_score(
                y_val,
                pred,
                labels=list(range(n_classes)),
                average="macro",
                zero_division=0,
            )
        )
        acc = float(accuracy_score(y_val, pred))

        rows.append(
            {
                "probe_protocol": name,
                "norm_mode": norm_mode,
                "weighted": weight_dict is not None,
                "source_val_macro_f1": macro_f1,
                "source_val_accuracy": acc,
                "cost_C": cost,
            }
        )
        fitted[name] = (
            clf,
            norm_mode,
        )

    probe_df = pd.DataFrame(rows).sort_values(
        ["source_val_macro_f1", "source_val_accuracy"],
        ascending=[False, False],
    )

    selected_name = str(probe_df.iloc[0]["probe_protocol"])
    selected_clf, selected_norm = fitted[selected_name]

    return probe_df, selected_name, selected_clf, selected_norm


def probe_predict(
    clf,
    norm_mode: str,
    features: np.ndarray,
):
    x = prepare_probe_features(features, norm_mode)
    pred = clf.predict(x)
    prob = clf.predict_proba(x)
    return pred.astype(int), prob.astype(np.float64)


# =============================================================================
# OOD SCORING
# =============================================================================

def build_prototypes_np(
    source_features: np.ndarray,
    source_labels: np.ndarray,
    n_classes: int,
):
    z = l2_np(source_features)
    protos = []

    for c in range(n_classes):
        zc = z[source_labels == c]
        if len(zc) == 0:
            raise RuntimeError(f"No source-train samples for class {c}")
        p = zc.mean(axis=0, keepdims=True)
        p = l2_np(p)[0]
        protos.append(p)

    return np.stack(protos).astype(np.float32)


def prototype_score_np(
    features: np.ndarray,
    prototypes: np.ndarray,
):
    z = l2_np(features)
    p = l2_np(prototypes)
    sim = z @ p.T
    return (1.0 - sim.max(axis=1)).astype(np.float32)


def kth_knn_distance_np(
    query_features: np.ndarray,
    bank_features: np.ndarray,
    *,
    k: int = KNN_K,
    chunk_size: int = KNN_QUERY_CHUNK,
):
    q = torch.from_numpy(l2_np(query_features))
    bank = torch.from_numpy(l2_np(bank_features))

    if k > len(bank):
        raise ValueError(f"k={k} > source bank {len(bank)}")

    bank_t = bank.T.contiguous()
    out = []

    for start in range(0, len(q), chunk_size):
        qc = q[start:start + chunk_size]
        sim = qc @ bank_t
        kth = torch.topk(
            sim,
            k=k,
            dim=1,
            largest=True,
            sorted=True,
        ).values[:, -1]
        dist = torch.sqrt(
            torch.clamp(
                2.0 - 2.0 * kth,
                min=0.0,
            )
        )
        out.append(dist.numpy())

    return np.concatenate(out).astype(np.float32)


def evaluate_openworld(
    *,
    y_open: np.ndarray,
    known_pred: np.ndarray,
    ood_score: np.ndarray,
    threshold: float,
    n_classes: int,
):
    y_unknown = (y_open == n_classes).astype(int)
    reject = ood_score > float(threshold)

    pred_open = known_pred.copy()
    pred_open[reject] = n_classes

    known_mask = y_open < n_classes
    unknown_mask = y_open == n_classes

    os_star = float(
        recall_score(
            y_open[known_mask],
            pred_open[known_mask],
            labels=list(range(n_classes)),
            average="macro",
            zero_division=0,
        )
    )

    unknown_recall = (
        float((pred_open[unknown_mask] == n_classes).mean())
        if unknown_mask.any()
        else float("nan")
    )

    auroc = (
        float(roc_auc_score(y_unknown, ood_score))
        if len(np.unique(y_unknown)) == 2
        else float("nan")
    )
    aupr_out = (
        float(average_precision_score(y_unknown, ood_score))
        if len(np.unique(y_unknown)) == 2
        else float("nan")
    )

    return {
        "auroc": auroc,
        "aupr_out": aupr_out,
        "open_macro_f1": float(
            f1_score(
                y_open,
                pred_open,
                labels=list(range(n_classes + 1)),
                average="macro",
                zero_division=0,
            )
        ),
        "os_star": os_star,
        "unknown_recall": unknown_recall,
        "hos": harmonic(os_star, unknown_recall),
        "predicted_unknown_fraction": float(reject.mean()),
        "known_false_reject_fraction": float(
            reject[known_mask].mean()
        ),
        "n_unknown": int(unknown_mask.sum()),
        "n_known": int(known_mask.sum()),
    }


# =============================================================================
# NATIVE ZERO-SHOT VLM
# =============================================================================

@torch.inference_mode()
def native_prompt_features(
    bundle: EncoderBundle,
    class_names: List[str],
):
    prompts = [
        FIXED_ZERO_SHOT_TEMPLATE.format(c)
        for c in class_names
    ]

    if bundle.native_text_kind == "openclip_encode_text":
        tokens = bundle.native_tokenizer(prompts).to(bundle.device)
        with amp_context(bundle.device):
            try:
                feat = bundle.model.encode_text(
                    tokens,
                    normalize=False,
                )
            except TypeError:
                feat = bundle.model.encode_text(tokens)

    elif bundle.native_text_kind == "openai_clip_encode_text":
        try:
            tokens = bundle.native_tokenizer(
                prompts,
                truncate=True,
            )
        except TypeError:
            tokens = bundle.native_tokenizer(prompts)
        tokens = tokens.to(bundle.device)

        with amp_context(bundle.device):
            feat = bundle.model.encode_text(tokens)
    else:
        raise RuntimeError(
            f"{bundle.name} has no native VLM text encoder."
        )

    return l2_np(feat.float().cpu().numpy())


def evaluate_native_zero_shot(
    bundle: EncoderBundle,
    split_features: Dict[str, np.ndarray],
    frames: Dict[str, pd.DataFrame],
    known_classes,
    target_names: List[str],
):
    n_classes = len(known_classes)
    prompt_features = native_prompt_features(
        bundle,
        class_names_for_prompts(known_classes),
    )

    source_val_image = l2_np(split_features["source_val"])
    source_val_sim = source_val_image @ prompt_features.T
    source_val_pred = source_val_sim.argmax(axis=1)
    source_val_uncertainty = (
        1.0 - source_val_sim.max(axis=1)
    ).astype(np.float32)

    source_val_y = frames["source_val"]["label_id"].astype(int).to_numpy()

    threshold = float(
        np.quantile(
            source_val_uncertainty,
            OOD_QUANTILE,
        )
    )

    rows = []

    for target in target_names:
        key = f"{target}::target_val_ow"
        frame = frames[key]

        image_features = l2_np(split_features[key])
        sim = image_features @ prompt_features.T
        known_pred = sim.argmax(axis=1).astype(int)
        uncertainty = (
            1.0 - sim.max(axis=1)
        ).astype(np.float32)

        is_unknown = frame["is_unknown"].astype(bool).to_numpy()
        known_mask = ~is_unknown

        y_known = frame.loc[known_mask, "label_id"].astype(int).to_numpy()
        pred_known = known_pred[known_mask]

        y_open = np.where(
            is_unknown,
            n_classes,
            frame["label_id"].fillna(-1).astype(int).to_numpy(),
        ).astype(int)

        open_metrics = evaluate_openworld(
            y_open=y_open,
            known_pred=known_pred.copy(),
            ood_score=uncertainty,
            threshold=threshold,
            n_classes=n_classes,
        )

        rows.append(
            {
                "model": bundle.name,
                "target_dataset": target,
                "zero_shot_template": FIXED_ZERO_SHOT_TEMPLATE,
                "source_val_known_macro_f1": float(
                    f1_score(
                        source_val_y,
                        source_val_pred,
                        labels=list(range(n_classes)),
                        average="macro",
                        zero_division=0,
                    )
                ),
                "target_val_known_macro_f1": float(
                    f1_score(
                        y_known,
                        pred_known,
                        labels=list(range(n_classes)),
                        average="macro",
                        zero_division=0,
                    )
                ),
                "target_val_known_accuracy": float(
                    accuracy_score(
                        y_known,
                        pred_known,
                    )
                ),
                "ood_rule": "native_max_similarity_source_q95",
                "ood_threshold": threshold,
                **open_metrics,
            }
        )

    return pd.DataFrame(rows)


# =============================================================================
# REPRESENTATION EVALUATION
# =============================================================================

def evaluate_representation(
    *,
    model_name: str,
    variant_name: str,
    features_by_split: Dict[str, np.ndarray],
    frames: Dict[str, pd.DataFrame],
    known_classes,
    target_names: List[str],
):
    n_classes = len(known_classes)

    x_train = features_by_split["source_train"]
    x_val = features_by_split["source_val"]
    y_train = frames["source_train"]["label_id"].astype(int).to_numpy()
    y_val = frames["source_val"]["label_id"].astype(int).to_numpy()

    probe_df, selected_probe, clf, probe_norm = fit_probe_variants(
        x_train,
        y_train,
        x_val,
        y_val,
        n_classes,
    )

    source_val_pred, _ = probe_predict(
        clf,
        probe_norm,
        x_val,
    )

    source_val_macro_f1 = float(
        f1_score(
            y_val,
            source_val_pred,
            labels=list(range(n_classes)),
            average="macro",
            zero_division=0,
        )
    )

    # Source-only OOD calibration.
    prototypes = build_prototypes_np(
        x_train,
        y_train,
        n_classes,
    )

    source_proto_score = prototype_score_np(
        x_val,
        prototypes,
    )
    proto_q95 = float(
        np.quantile(
            source_proto_score,
            OOD_QUANTILE,
        )
    )

    source_knn_score = kth_knn_distance_np(
        x_val,
        x_train,
        k=KNN_K,
    )
    knn_q95 = float(
        np.quantile(
            source_knn_score,
            OOD_QUANTILE,
        )
    )

    result_rows = []
    probe_rows = probe_df.copy()
    probe_rows.insert(0, "variant", variant_name)
    probe_rows.insert(0, "model", model_name)

    for target in target_names:
        key = f"{target}::target_val_ow"
        frame = frames[key]
        x_target = features_by_split[key]

        known_pred, _ = probe_predict(
            clf,
            probe_norm,
            x_target,
        )

        unknown_mask = frame["is_unknown"].astype(bool).to_numpy()
        known_mask = ~unknown_mask

        y_target_known = (
            frame.loc[known_mask, "label_id"]
            .astype(int)
            .to_numpy()
        )
        pred_target_known = known_pred[known_mask]

        target_known_macro_f1 = float(
            f1_score(
                y_target_known,
                pred_target_known,
                labels=list(range(n_classes)),
                average="macro",
                zero_division=0,
            )
        )
        target_known_acc = float(
            accuracy_score(
                y_target_known,
                pred_target_known,
            )
        )

        y_open = np.where(
            unknown_mask,
            n_classes,
            frame["label_id"].fillna(-1).astype(int).to_numpy(),
        ).astype(int)

        proto_score = prototype_score_np(
            x_target,
            prototypes,
        )
        knn_score = kth_knn_distance_np(
            x_target,
            x_train,
            k=KNN_K,
        )

        for ood_rule, score, threshold in [
            ("prototype_q95", proto_score, proto_q95),
            ("knn50_q95", knn_score, knn_q95),
        ]:
            open_metrics = evaluate_openworld(
                y_open=y_open,
                known_pred=known_pred.copy(),
                ood_score=score,
                threshold=threshold,
                n_classes=n_classes,
            )

            result_rows.append(
                {
                    "model": model_name,
                    "variant": variant_name,
                    "feature_dim": int(x_train.shape[1]),
                    "target_dataset": target,
                    "selected_probe_protocol": selected_probe,
                    "source_val_macro_f1": source_val_macro_f1,
                    "target_val_known_macro_f1": target_known_macro_f1,
                    "target_val_known_accuracy": target_known_acc,
                    "ood_rule": ood_rule,
                    "ood_threshold": float(threshold),
                    "source_val_reject_fraction": float(
                        (
                            (
                                source_proto_score
                                if ood_rule == "prototype_q95"
                                else source_knn_score
                            )
                            > threshold
                        ).mean()
                    ),
                    **open_metrics,
                }
            )

    return pd.DataFrame(result_rows), probe_rows


# =============================================================================
# BUILD REPRESENTATION VARIANTS
# =============================================================================

def split_keys(target_names: List[str]) -> List[str]:
    return [
        "source_train",
        "source_val",
        *[
            f"{target}::target_val_ow"
            for target in target_names
        ],
    ]


def get_bioclinical_for_splits(
    frames,
    target_names,
    *,
    force=False,
):
    result = {}
    for key in split_keys(target_names):
        result[key] = extract_bioclinical_text_features(
            frames[key],
            key,
            force=force,
        )
    return result


def build_image_model_variants(
    bundle: EncoderBundle,
    frames,
    target_names,
    *,
    force=False,
):
    image_features = {}

    for key in split_keys(target_names):
        image_features[key] = extract_image_features(
            bundle,
            frames[key],
            key,
            force=force,
        )

    bioclinical = get_bioclinical_for_splits(
        frames,
        target_names,
        force=force,
    )

    variants = {
        "image_only": image_features,
        "image_plus_bioclinicalbert_text_core": {
            key: concat_modalities(
                image_features[key],
                bioclinical[key],
            )
            for key in image_features
        },
    }

    native_text_features = None

    if bundle.native_tokenizer is not None:
        native_text_features = {}

        for key in split_keys(target_names):
            texts = [
                safe_text(x)
                for x in frames[key][TEXT_COL].tolist()
            ]
            native_text_features[key] = extract_native_text_features(
                bundle,
                texts,
                key,
                force=force,
            )

        # Native image/text encoders live in the same contrastive space.
        # Equal-weight mean is fixed prospectively; no target tuning.
        variants["native_image_text_mean"] = {
            key: aligned_mean_modalities(
                image_features[key],
                native_text_features[key],
            )
            for key in image_features
        }

    return variants, image_features


# =============================================================================
# PREFLIGHT
# =============================================================================

def preflight_report(include_derm_foundation: bool):
    rows = []

    def row(model, status, detail):
        rows.append(
            {
                "model": model,
                "status": status,
                "detail": detail,
            }
        )

    # Local path/cache safety audit.
    try:
        test_name = windows_safe_filename_component(
            "ISIC 2019::target_val_ow"
        )
        if ":" in test_name:
            raise RuntimeError("':' survived Windows filename sanitization")
        row(
            "feature_cache_path_safety",
            "READY",
            f'Windows-safe target cache component: "{test_name}"',
        )
    except Exception as e:
        row(
            "feature_cache_path_safety",
            "ERROR",
            repr(e),
        )

    # Frozen legacy geometry audit from registry/checkpoint metadata.
    try:
        sys.path.insert(0, str(ROOT))
        protocol_pf = __import__(PROTOCOL_MODULE)
        registry_pf = pd.read_csv(protocol_pf.CLOSED_CHECKPOINT_REGISTRY)
        registry_pf["best_checkpoint"] = (
            registry_pf["best_checkpoint"]
            .astype(str)
            .str.replace(
                r"D:\Deep Learning",
                str(ROOT),
                regex=False,
            )
        )
        dims = []
        for seed_pf in LEGACY_SEEDS:
            hit_pf = registry_pf[
                (registry_pf["model_family"].astype(str)
                 == "mobilevit_cross_attention")
                & (registry_pf["text_col"].astype(str) == TEXT_COL)
                & (registry_pf["seed"].astype(int) == seed_pf)
            ]
            if len(hit_pf) != 1:
                raise RuntimeError(
                    f"seed {seed_pf}: expected one registry row, got {len(hit_pf)}"
                )
            ckpt_pf = Path(hit_pf.iloc[0]["best_checkpoint"])
            payload_pf = torch.load(ckpt_pf, map_location="cpu")
            state_pf = payload_pf.get("model_state_dict", payload_pf)
            dim_pf = int(state_pf["fusion.image_proj.weight"].shape[0])
            dims.append((seed_pf, dim_pf))
        if any(dim != LEGACY_FUSION_DIM for _, dim in dims):
            raise RuntimeError(
                f"legacy checkpoint fusion dims={dims}, "
                f"expected {LEGACY_FUSION_DIM}"
            )
        row(
            "legacy_frozen_checkpoint_geometry",
            "READY",
            f"fusion_dim={LEGACY_FUSION_DIM} verified for seeds {LEGACY_SEEDS}",
        )
    except Exception as e:
        row(
            "legacy_frozen_checkpoint_geometry",
            "ERROR",
            repr(e),
        )

    # DINOv2
    row(
        "dinov2_vitb14 / dinov2_vitl14",
        "AUTO",
        "Official Meta torch.hub; downloads on first use.",
    )

    # open_clip
    try:
        import open_clip  # noqa
        oc_status = "READY"
    except Exception:
        oc_status = "MISSING"
    row(
        "biomedclip",
        oc_status,
        "Requires open_clip_torch (`pip install open_clip_torch`).",
    )
    row(
        "dermlip_panderm / dermlip_vitb16",
        "READY" if shutil.which("git") else "MISSING GIT",
        (
            "V8.2 uses the authors' Derm1M bundled src/open_clip fork. "
            f"Repo location: {DERM1M_REPO}; auto-cloned if absent."
        ),
    )

    # MONET official Hugging Face implementation.
    try:
        from transformers import AutoConfig
        AutoConfig.from_pretrained(MONET_HF)
        monet_status = "READY"
    except Exception:
        monet_status = "ERROR"
    row(
        "monet",
        monet_status,
        (
            "Uses MONET authors' supported Hugging Face release "
            f"{MONET_HF}."
        ),
    )

    # PanDerm repo/weights
    repo_ok = PANDERM_CLASSIFICATION.exists()
    base_ok = PANDERM_BASE_CKPT.exists()
    large_ok = PANDERM_LARGE_CKPT.exists()

    row(
        "panderm_base",
        "READY" if repo_ok and base_ok else "MISSING",
        (
            f"Repo={repo_ok}; checkpoint={base_ok}. "
            f"Expected {PANDERM_BASE_CKPT}. "
            f"Official: {PANDERM_BASE_DRIVE_URL}"
        ),
    )
    row(
        "panderm_large",
        "READY" if repo_ok and large_ok else "MISSING",
        (
            f"Repo={repo_ok}; checkpoint={large_ok}. "
            f"Expected {PANDERM_LARGE_CKPT}. "
            f"Official: {PANDERM_LARGE_DRIVE_URL}"
        ),
    )

    if include_derm_foundation:
        try:
            import tensorflow  # noqa
            from huggingface_hub import from_pretrained_keras  # noqa
            tf_status = "DEPENDENCIES PRESENT"
        except Exception:
            tf_status = "MISSING DEPENDENCIES"

        row(
            "derm_foundation",
            tf_status,
            "Also requires accepting google/derm-foundation terms on HF.",
        )
    else:
        row(
            "derm_foundation",
            "OPTIONAL/OFF",
            "Enable with --include-derm-foundation after accepting HF terms.",
        )

    row(
        "dermfm_zero",
        "OPTIONAL/GATED",
        (
            "Public gated release now exists at redlessone/DermFM-Zero. "
            "Enable with --include-dermfm-zero after approved HF access. "
            "ISIC result is overlap-risk because ISIC Archive images are "
            "reported in pretraining."
        ),
    )

    return pd.DataFrame(rows)


# =============================================================================
# CHILD WORK
# =============================================================================

def run_text_only_child(
    frames,
    target_names,
    known_classes,
    *,
    force=False,
):
    features = get_bioclinical_for_splits(
        frames,
        target_names,
        force=force,
    )

    results, probes = evaluate_representation(
        model_name="bioclinicalbert",
        variant_name="text_core_only",
        features_by_split=features,
        frames=frames,
        known_classes=known_classes,
        target_names=target_names,
    )

    return results, probes, pd.DataFrame()


def run_legacy_child(
    model_name,
    frames,
    target_names,
    known_classes,
    protocol,
    *,
    force=False,
):
    seed = int(model_name.replace("legacy_fused_seed", ""))

    features = {}
    for key in split_keys(target_names):
        features[key] = extract_legacy_fused(
            seed,
            frames[key],
            key,
            protocol,
            force=force,
        )

    results, probes = evaluate_representation(
        model_name=model_name,
        variant_name="legacy_source_trained_multimodal_fused",
        features_by_split=features,
        frames=frames,
        known_classes=known_classes,
        target_names=target_names,
    )

    return results, probes, pd.DataFrame()


def run_derm_foundation_child(
    frames,
    target_names,
    known_classes,
    *,
    force=False,
):
    image_features = {}
    for key in split_keys(target_names):
        image_features[key] = extract_derm_foundation(
            frames[key],
            key,
            force=force,
        )

    bioclinical = get_bioclinical_for_splits(
        frames,
        target_names,
        force=force,
    )

    variants = {
        "image_only": image_features,
        "image_plus_bioclinicalbert_text_core": {
            key: concat_modalities(
                image_features[key],
                bioclinical[key],
            )
            for key in image_features
        },
    }

    result_frames = []
    probe_frames = []

    for variant_name, feat in variants.items():
        r, p = evaluate_representation(
            model_name="derm_foundation",
            variant_name=variant_name,
            features_by_split=feat,
            frames=frames,
            known_classes=known_classes,
            target_names=target_names,
        )
        result_frames.append(r)
        probe_frames.append(p)

    return (
        pd.concat(result_frames, ignore_index=True),
        pd.concat(probe_frames, ignore_index=True),
        pd.DataFrame(),
    )


def run_image_child(
    model_name,
    frames,
    target_names,
    known_classes,
    *,
    force=False,
):
    device = device_from_project()
    bundle = load_encoder(model_name, device)

    variants, image_features = build_image_model_variants(
        bundle,
        frames,
        target_names,
        force=force,
    )

    result_frames = []
    probe_frames = []

    for variant_name, feature_dict in variants.items():
        r, p = evaluate_representation(
            model_name=model_name,
            variant_name=variant_name,
            features_by_split=feature_dict,
            frames=frames,
            known_classes=known_classes,
            target_names=target_names,
        )
        r["pretraining_overlap_risk"] = False
        if model_name == "dermfm_zero":
            r.loc[
                r["target_dataset"].eq("ISIC 2019"),
                "pretraining_overlap_risk",
            ] = True

        result_frames.append(r)
        probe_frames.append(p)

    zero_shot = pd.DataFrame()
    if bundle.native_tokenizer is not None:
        zero_shot = evaluate_native_zero_shot(
            bundle,
            image_features,
            frames,
            known_classes,
            target_names,
        )
        zero_shot["pretraining_overlap_risk"] = False
        if model_name == "dermfm_zero":
            zero_shot.loc[
                zero_shot["target_dataset"].eq("ISIC 2019"),
                "pretraining_overlap_risk",
            ] = True

    return (
        pd.concat(result_frames, ignore_index=True),
        pd.concat(probe_frames, ignore_index=True),
        zero_shot,
    )


def run_child(
    model_name: str,
    target_names: List[str],
    *,
    force_features: bool,
):
    protocol, frames = load_protocol_frames(target_names)

    sys.path.insert(0, str(PACKAGE_DIR))
    from config import KNOWN_CLASSES
    known_classes = class_order_from_config(KNOWN_CLASSES)

    if model_name == "bioclinicalbert_text":
        return run_text_only_child(
            frames,
            target_names,
            known_classes,
            force=force_features,
        )

    if model_name.startswith("legacy_fused_seed"):
        return run_legacy_child(
            model_name,
            frames,
            target_names,
            known_classes,
            protocol,
            force=force_features,
        )

    if model_name == "derm_foundation":
        return run_derm_foundation_child(
            frames,
            target_names,
            known_classes,
            force=force_features,
        )

    return run_image_child(
        model_name,
        frames,
        target_names,
        known_classes,
        force=force_features,
    )


# =============================================================================
# PARENT ORCHESTRATION
# =============================================================================

def parse_targets(raw: str):
    if raw.lower() == "both":
        return TARGETS_DEFAULT
    parts = [x.strip() for x in raw.split(",") if x.strip()]
    allowed = set(TARGETS_DEFAULT)
    for x in parts:
        if x not in allowed:
            raise ValueError(
                f"Unknown target {x!r}. Allowed: {TARGETS_DEFAULT}"
            )
    return parts


def models_to_run(
    requested: str,
    include_derm_foundation: bool,
    include_dermfm_zero: bool,
):
    if requested.lower() == "all":
        models = list(PRIMARY_MODELS)
        if include_derm_foundation:
            models.append("derm_foundation")
        if include_dermfm_zero:
            models.append("dermfm_zero")
        return models

    models = [
        x.strip()
        for x in requested.split(",")
        if x.strip()
    ]

    allowed = set(
        PRIMARY_MODELS + OPTIONAL_MODELS
    )
    bad = [x for x in models if x not in allowed]
    if bad:
        raise ValueError(
            f"Unknown models {bad}. Allowed: {sorted(allowed)}"
        )
    return models


def child_output_dir(model_name: str):
    return CHILD_ROOT / model_name


def write_child_outputs(
    model_name: str,
    results: pd.DataFrame,
    probes: pd.DataFrame,
    zero_shot: pd.DataFrame,
):
    out = child_output_dir(model_name)
    out.mkdir(parents=True, exist_ok=True)

    results.to_csv(
        out / "representation_results.csv",
        index=False,
    )
    probes.to_csv(
        out / "probe_source_val_selection.csv",
        index=False,
    )
    zero_shot.to_csv(
        out / "native_zero_shot_results.csv",
        index=False,
    )

    (out / "RUN_COMPLETE.flag").write_text(
        "complete\n",
        encoding="utf-8",
    )


def aggregate_parent(models: List[str]):
    result_frames = []
    probe_frames = []
    zero_frames = []
    status_rows = []

    for model in models:
        out = child_output_dir(model)
        complete = (out / "RUN_COMPLETE.flag").exists()

        if not complete:
            status_rows.append(
                {
                    "model": model,
                    "status": "INCOMPLETE_OR_FAILED",
                }
            )
            continue

        status_rows.append(
            {
                "model": model,
                "status": "COMPLETE",
            }
        )

        rp = out / "representation_results.csv"
        pp = out / "probe_source_val_selection.csv"
        zp = out / "native_zero_shot_results.csv"

        if rp.exists():
            result_frames.append(pd.read_csv(rp))
        if pp.exists():
            probe_frames.append(pd.read_csv(pp))
        if zp.exists() and zp.stat().st_size > 1:
            try:
                z = pd.read_csv(zp)
                if len(z):
                    zero_frames.append(z)
            except pd.errors.EmptyDataError:
                pass

    status = pd.DataFrame(status_rows)
    status.to_csv(
        OUTPUT_ROOT / "v8_model_status.csv",
        index=False,
    )

    if result_frames:
        results = pd.concat(
            result_frames,
            ignore_index=True,
        )
        results.to_csv(
            OUTPUT_ROOT / "v8_all_representation_results.csv",
            index=False,
        )

        # Compact image/metadata comparison.
        compact = (
            results[
                results["ood_rule"] == "prototype_q95"
            ]
            .copy()
            .sort_values(
                [
                    "target_dataset",
                    "target_val_known_macro_f1",
                    "auroc",
                ],
                ascending=[True, False, False],
            )
        )
        compact.to_csv(
            OUTPUT_ROOT / "v8_compact_prototype_comparison.csv",
            index=False,
        )

    else:
        results = pd.DataFrame()

    if probe_frames:
        pd.concat(
            probe_frames,
            ignore_index=True,
        ).to_csv(
            OUTPUT_ROOT / "v8_all_probe_protocols.csv",
            index=False,
        )

    if zero_frames:
        pd.concat(
            zero_frames,
            ignore_index=True,
        ).to_csv(
            OUTPUT_ROOT / "v8_all_native_zero_shot_results.csv",
            index=False,
        )

    return status, results


def main():
    ap = argparse.ArgumentParser()

    ap.add_argument(
        "--model",
        default=None,
        help="Internal child model id. Parent normally sets this.",
    )
    ap.add_argument(
        "--models",
        default="all",
        help="Parent model list or 'all'.",
    )
    ap.add_argument(
        "--targets",
        default="both",
        help="'both' or comma list: 'ISIC 2019,MCR-SL'.",
    )
    ap.add_argument(
        "--include-derm-foundation",
        action="store_true",
        help=(
            "Include optional Google Derm Foundation. Requires accepted "
            "HF terms + TensorFlow."
        ),
    )
    ap.add_argument(
        "--include-dermfm-zero",
        action="store_true",
        help=(
            "Include gated DermFM-Zero after approved Hugging Face access. "
            "Its ISIC result is overlap-risk because ISIC Archive images "
            "are reported in pretraining."
        ),
    )
    ap.add_argument(
        "--preflight",
        action="store_true",
        help="Print dependency/checkpoint readiness and exit.",
    )
    ap.add_argument(
        "--strict",
        action="store_true",
        help="Parent exits on first failed child.",
    )
    ap.add_argument(
        "--force-features",
        action="store_true",
        help="Ignore feature caches and re-extract.",
    )

    args = ap.parse_args()

    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    FEATURE_ROOT.mkdir(parents=True, exist_ok=True)
    CHILD_ROOT.mkdir(parents=True, exist_ok=True)

    targets = parse_targets(args.targets)

    if args.preflight:
        report = preflight_report(
            include_derm_foundation=args.include_derm_foundation
        )
        print("\nV8.2 PRETRAINED MODEL PREFLIGHT")
        print(report.to_string(index=False))
        print(
            "\nPanDerm setup directory:",
            PANDERM_REPO,
        )
        print(
            "\nIMPORTANT: do NOT install an older PanDerm PyTorch build over "
            "your working environment just because the original README lists "
            "its development version. First try the official code with your "
            "current environment; install only missing dependencies."
        )
        return

    # ------------------------------------------------------------------
    # CHILD
    # ------------------------------------------------------------------
    if args.model is not None:
        model_name = args.model

        print("\n" + "=" * 150)
        print(f"V8.2 CHILD: {model_name}")
        print(f"Targets: {targets}")
        print("TARGET ADAPT/TEST ARE NOT USED.")
        print("=" * 150, flush=True)

        results, probes, zero_shot = run_child(
            model_name,
            targets,
            force_features=args.force_features,
        )

        write_child_outputs(
            model_name,
            results,
            probes,
            zero_shot,
        )

        print("\nRepresentation results:")
        show = [
            c for c in [
                "model",
                "variant",
                "target_dataset",
                "selected_probe_protocol",
                "source_val_macro_f1",
                "target_val_known_macro_f1",
                "ood_rule",
                "auroc",
                "open_macro_f1",
                "hos",
                "unknown_recall",
            ]
            if c in results.columns
        ]
        print(results[show].to_string(index=False))

        if len(zero_shot):
            print("\nNative zero-shot diagnostic:")
            print(zero_shot.to_string(index=False))

        print("\nSAFETY: target_adapt_ow and target_test_ow were untouched.")
        return

    # ------------------------------------------------------------------
    # PARENT
    # ------------------------------------------------------------------
    models = models_to_run(
        args.models,
        args.include_derm_foundation,
        args.include_dermfm_zero,
    )

    # BioClinical text first so all image children reuse the same cache.
    if (
        "bioclinicalbert_text" in models
        and models[0] != "bioclinicalbert_text"
    ):
        models.remove("bioclinicalbert_text")
        models.insert(0, "bioclinicalbert_text")

    script = str(Path(__file__).resolve())

    print("\n" + "=" * 150)
    print("V8.2 PRETRAINED REPRESENTATION BENCHMARK")
    print("=" * 150)
    print("Models:")
    for m in models:
        print("  -", m)
    print("Targets:", targets)
    print(
        "\nAll pretrained encoders remain frozen. "
        "Only source-only linear probes are fitted."
    )
    print("TARGET ADAPT/TEST ARE NOT USED.", flush=True)

    failed = []

    for i, model in enumerate(models, start=1):
        out = child_output_dir(model)

        if (
            (out / "RUN_COMPLETE.flag").exists()
            and not args.force_features
        ):
            print(
                f"\n[{i}/{len(models)}] {model}: already complete; skipping."
            )
            continue

        cmd = [
            sys.executable,
            script,
            "--model",
            model,
            "--targets",
            ",".join(targets),
        ]

        if args.force_features:
            cmd.append("--force-features")

        print(
            f"\n[{i}/{len(models)}] launching {model}",
            flush=True,
        )

        try:
            subprocess.check_call(cmd)
        except subprocess.CalledProcessError as e:
            failed.append(
                {
                    "model": model,
                    "returncode": int(e.returncode),
                }
            )
            print(
                f"\n[V8] {model} FAILED. "
                "Other models can continue because every child is isolated.",
                flush=True,
            )
            if args.strict:
                raise

    status, results = aggregate_parent(models)

    if failed:
        pd.DataFrame(failed).to_csv(
            OUTPUT_ROOT / "v8_failures.csv",
            index=False,
        )

    print("\n" + "=" * 150)
    print("V8.2 PRETRAINED REPRESENTATION BENCHMARK COMPLETE")
    print("=" * 150)
    print("\nModel status:")
    print(status.to_string(index=False))

    if len(results):
        compact_cols = [
            "model",
            "variant",
            "target_dataset",
            "selected_probe_protocol",
            "target_val_known_macro_f1",
            "ood_rule",
            "auroc",
            "aupr_out",
            "open_macro_f1",
            "hos",
            "unknown_recall",
            "known_false_reject_fraction",
        ]

        print("\nResults:")
        print(
            results[
                [c for c in compact_cols if c in results.columns]
            ].to_string(index=False)
        )

    print("\nPrimary artifacts:")
    print(OUTPUT_ROOT / "v8_all_representation_results.csv")
    print(OUTPUT_ROOT / "v8_compact_prototype_comparison.csv")
    print(OUTPUT_ROOT / "v8_all_probe_protocols.csv")
    print(OUTPUT_ROOT / "v8_all_native_zero_shot_results.csv")
    print(OUTPUT_ROOT / "v8_model_status.csv")

    if failed:
        print(
            "\nSome optional/local models failed. See:",
            OUTPUT_ROOT / "v8_failures.csv",
        )

    print(
        "\nSAFETY: source_test, target_adapt_ow and target_test_ow "
        "were NOT selected or evaluated."
    )
    print("=" * 150)


if __name__ == "__main__":
    main()
