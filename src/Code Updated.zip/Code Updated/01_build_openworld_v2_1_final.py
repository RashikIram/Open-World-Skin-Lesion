#!/usr/bin/env python
"""
FINAL REVIEWER-HARDENED OPEN-WORLD PREPROCESSING PROTOCOL V2.1
=======================================================

Purpose
-------
Create a corrected, auditable successor to the frozen Open-World V1 table
WITHOUT changing split membership.

This script fixes preprocessing/semantic issues discovered during reviewer audit:

1) PAD-UFES FOREARM mapping bug:
       FOREARM -> upper_extremity
   (not head_neck).

2) Anatomical site harmonization becomes explicit/exact for PAD, ISIC, MCR.
   No loose substring rules are used in this script.

3) Age semantics are harmonized to decade bands across datasets:
       58 -> 50-59
       60 -> 60-69
   This removes the exact-age vs ISIC 5-year-bin representation mismatch.

4) Lesion diameter is harmonized as a shared concept without overstating measurement equivalence:
   PAD: max(diameter_1, diameter_2)
   MCR: supplied scalar lesion diameter
   ISIC: unavailable.

5) ISIC BKL -> SK is retained ONLY for six-class compatibility but is explicitly
   flagged as an approximate ontology mapping. An exact five-class sensitivity
   flag excludes SK/BKL.

6) ISIC VASC is preserved as VASC (unknown), not renamed ANG.
   Both VASC and MCR ANG receive unknown_family="vascular".

7) MCR lesions L0247/L0248 are preserved for provenance but excluded from
   primary evaluation because raw diagnosis_image_id points to the other lesion.

8) Informative missingness is not silently treated as a clean primary signal.
   A reviewer-clean primary text is added:
       text_shared_robust = age group + anatomical site
   Sex is excluded from this PRIMARY text because PAD sex availability is
   strongly acquisition/biopsy-linked.

   Existing-style corrected text columns are also retained:
       text_core              = age group + sex + anatomical site
       text_full              = heterogeneous-schema stress test
       text_missing_explicit  = informative-missingness stress test only

9) Split membership is preserved exactly from Open-World V1.

10) Two independent validation passes are mandatory:
    PASS 1: raw-source reconciliation before correction.
    PASS 2: in-memory semantic/protocol invariants after correction.
    PASS 3: reload-from-disk verification after writing.

The script aborts on any failed invariant and only writes
PROTOCOL_V2_1_THREE_PASS_AUDIT_PASSED.flag after all checks pass.

Important irreducible limitations
---------------------------------
The script cannot make unavailable metadata exist, remove the PAD/ISIC visual
modality gap, or turn ISIC BKL into a pure seborrheic-keratosis class. Those
limitations are surfaced explicitly in the output audits/manifest.

Run
---
python build_reviewer_corrected_openworld_protocol_v2.py

Optional explicit paths are available via argparse.

Output
------
preprocessed_outputs_openworld_v2_1_final/
    all_preprocessed_splits_standardized_text_openworld_v2_1.csv
    raw_source_crosscheck_pass1.csv
    semantic_protocol_audit_pass2.csv
    reload_crosscheck_pass3.csv
    metadata_availability_by_dataset.csv
    pad_availability_by_class.csv
    label_mapping_audit_v2_1.csv
    split_membership_hashes.csv
    protocol_manifest_v2_1.json
    dataset/split CSVs
    five-class sensitivity CSVs
    PROTOCOL_V2_1_THREE_PASS_AUDIT_PASSED.flag
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import unicodedata
from pathlib import Path

import numpy as np
import pandas as pd


# =============================================================================
# DEFAULT PATHS
# =============================================================================

ROOT = Path(r"C:\Users\Nebula PC\Downloads\Deep Learning")
ROOT2 = Path(r"C:\Users\Nebula PC\Downloads\Deep Learning\MCR-SL_dataset")

DEFAULT_V1 = (
    ROOT
    / "preprocessed_outputs_openworld_v1"
    / "all_preprocessed_splits_standardized_text_openworld_v1.csv"
)

DEFAULT_PAD_RAW = ROOT / "metadata.csv"
DEFAULT_ISIC_META = ROOT / "ISIC_2019_Training_Metadata.csv"
DEFAULT_ISIC_GT = ROOT / "ISIC_2019_Training_GroundTruth.csv"

DEFAULT_MCR_LESION = ROOT2 / "lesion.xlsx"
DEFAULT_MCR_IMAGE = ROOT2 / "image.xlsx"
DEFAULT_MCR_SUBJECT = ROOT2 / "subject.xlsx"
DEFAULT_MCR_UNIFIED = ROOT2 / "unified_diagnosis.xlsx"
DEFAULT_MCR_DERM = ROOT2 / "dermatology_diagnosis.xlsx"
DEFAULT_MCR_HISTO = ROOT2 / "histopathology_diagnosis.xlsx"

DEFAULT_OUTPUT = ROOT / "preprocessed_outputs_openworld_v2_1_final"

KNOWN_CLASSES = ["AK", "BCC", "MEL", "NEV", "SCC", "SK"]
EXACT_5CLASS = ["AK", "BCC", "MEL", "NEV", "SCC"]

EXPECTED_SPLITS = {
    ("PAD-UFES-20", "source_train"): 1593,
    ("PAD-UFES-20", "source_val"): 349,
    ("PAD-UFES-20", "source_test"): 356,
    ("ISIC 2019", "target_adapt_ow"): 20430,
    ("ISIC 2019", "target_val_ow"): 4901,
    ("ISIC 2019", "target_test_ow"): 8238,
    ("MCR-SL", "target_adapt_ow"): 140,
    ("MCR-SL", "target_val_ow"): 47,
    ("MCR-SL", "target_test_ow"): 47,
}

MCR_CONFLICT_LESIONS = {"L0247", "L0248"}


# =============================================================================
# EXPLICIT ANATOMICAL MAPS
# =============================================================================

PAD_SITE_MAP = {
    "ABDOMEN": "trunk",
    "ARM": "upper_extremity",
    "BACK": "trunk",
    "CHEST": "trunk",
    "EAR": "head_neck",
    "FACE": "head_neck",
    "FOOT": "distal_extremity",
    "FOREARM": "upper_extremity",
    "HAND": "distal_extremity",
    "LIP": "head_neck",
    "NECK": "head_neck",
    "NOSE": "head_neck",
    "SCALP": "head_neck",
    "THIGH": "lower_extremity",
}

ISIC_SITE_MAP = {
    "anterior torso": "trunk",
    "posterior torso": "trunk",
    "lateral torso": "trunk",
    "head/neck": "head_neck",
    "upper extremity": "upper_extremity",
    "lower extremity": "lower_extremity",
    "palms/soles": "distal_extremity",
    "oral/genital": "mucosal",
}

MCR_SITE_MAP = {
    "abdomen": "trunk",
    "back": "trunk",
    "back / left shoulder": "unknown",
    "chest": "trunk",
    "face": "head_neck",
    "foot": "distal_extremity",
    "forehead": "head_neck",
    "head": "head_neck",
    "head (behind the ear)": "head_neck",
    "left arm": "upper_extremity",
    "left cheek": "head_neck",
    "left leg": "lower_extremity",
    "left side": "trunk",
    "lip": "head_neck",
    "neck": "head_neck",
    "nose": "head_neck",
    "right ankle": "lower_extremity",
    "right arm": "upper_extremity",
    "right body side": "trunk",
    "right cheek": "head_neck",
    "right leg": "lower_extremity",
    "scalp": "head_neck",
    "shoulder": "upper_extremity",
    "temple": "head_neck",
    "unknown": "unknown",
}


# =============================================================================
# STANDARDIZED TEXT SCHEMA
# =============================================================================

FIELD_LABELS = [
    ("std_age", "age group"),
    ("std_sex", "sex"),
    ("std_location", "anatomical site"),
    ("std_diameter", "lesion diameter"),
    ("std_fitzpatrick", "Fitzpatrick type"),
    ("std_itch", "itching"),
    ("std_grew", "growth"),
    ("std_hurt", "pain"),
    ("std_changed", "change"),
    ("std_bleed", "bleeding"),
    ("std_elevation", "elevation"),
    ("std_personal_skin_cancer_history", "personal skin cancer history"),
    ("std_family_skin_cancer_history", "family skin cancer history"),
    ("std_general_cancer_history", "general cancer history"),
    ("std_smoking", "smoking"),
    ("std_alcohol", "alcohol"),
    ("std_pesticide_exposure", "pesticide exposure"),
    ("std_sunbed_use", "sunbed use"),
    ("std_organ_transplant", "organ transplant"),
    ("std_immunosuppression", "immunosuppression"),
    ("std_natural_hair_color", "natural hair color"),
    ("std_skin_reaction_to_sun", "skin reaction to sun"),
    ("std_moles_body_18", "moles on body at age 18"),
    ("std_moles_bigger_5mm", "moles larger than 5 mm"),
    ("std_moles_bigger_20cm", "moles field bigger 20 cm"),
    ("std_moles_body", "moles on body"),
    ("std_sunburn_number_group", "sunburn count group"),
]

FULL_FIELDS = [x[0] for x in FIELD_LABELS]
FIELD_TO_LABEL = dict(FIELD_LABELS)

# Reviewer-clean primary text: removes PAD's biopsy-linked sex availability.
ROBUST_PRIMARY_FIELDS = ["std_age", "std_location"]

# Corrected historical core retained as a secondary sensitivity view.
DEMOGRAPHIC_FIELDS = ["std_age", "std_sex", "std_location"]
AGE_ONLY_FIELDS = ["std_age"]
LOCATION_ONLY_FIELDS = ["std_location"]


# =============================================================================
# HELPERS
# =============================================================================

def norm_string(x) -> str:
    if pd.isna(x):
        return ""
    s = unicodedata.normalize("NFKC", str(x)).replace("\xa0", " ")
    s = re.sub(r"\s+", " ", s.strip())
    return s


def norm_id(x) -> str:
    if pd.isna(x):
        return ""
    s = str(x).strip()
    if re.fullmatch(r"\d+\.0", s):
        s = s[:-2]
    return s


def is_missing(x) -> bool:
    if pd.isna(x):
        return True
    return str(x).strip().lower() in {
        "", "nan", "none", "null", "unknown", "n/a", "na"
    }


def clean_std(x) -> str:
    return "unknown" if is_missing(x) else str(x).strip().lower()


def normalize_sex(x) -> str:
    s = norm_string(x).lower()
    if s in {"male", "m"}:
        return "male"
    if s in {"female", "f"}:
        return "female"
    return "unknown"


def decade_age(x) -> str:
    if pd.isna(x):
        return "unknown"
    try:
        v = float(x)
        if not np.isfinite(v) or v < 0:
            return "unknown"
        start = int(math.floor(v / 10.0) * 10)
        return f"{start}-{start + 9}"
    except (TypeError, ValueError):
        return "unknown"


def max_numeric(*xs):
    vals = []
    for x in xs:
        try:
            v = float(x)
            if np.isfinite(v):
                vals.append(v)
        except (TypeError, ValueError):
            pass
    return max(vals) if vals else np.nan


def format_mm(x) -> str:
    if pd.isna(x):
        return "unknown"
    v = float(x)
    z = f"{v:.1f}".rstrip("0").rstrip(".")
    return f"{z} mm"


def build_text(row, fields, explicit_missing=False) -> str:
    parts = []

    for field in fields:
        value = clean_std(row.get(field, "unknown"))

        if value == "unknown" and not explicit_missing:
            continue

        if field == "std_age" and value != "unknown":
            value = f"{value} years"

        parts.append(f"{FIELD_TO_LABEL[field]}: {value}")

    if not parts:
        return "Patient metadata unavailable."

    return "Patient metadata: " + "; ".join(parts) + "."


def membership_hash(df: pd.DataFrame) -> str:
    payload = "\n".join(
        sorted(
            f"{d}|{sid}|{sp}"
            for d, sid, sp in zip(
                df["dataset"].astype(str),
                df["sample_id"].astype(str),
                df["split"].astype(str),
            )
        )
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def group_membership_hash(df: pd.DataFrame) -> str:
    group = df.get("openworld_split_group_id", pd.Series(index=df.index, dtype=object))
    payload = "\n".join(
        sorted(
            f"{d}|{sid}|{sp}|{g}"
            for d, sid, sp, g in zip(
                df["dataset"].astype(str),
                df["sample_id"].astype(str),
                df["split"].astype(str),
                group.fillna("").astype(str),
            )
        )
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def evaluation_membership_hash(df: pd.DataFrame) -> str:
    q = df[df["primary_eval_eligible"].astype(bool)].copy()
    payload = "\n".join(
        sorted(
            f"{d}|{sid}|{sp}"
            for d, sid, sp in zip(
                q["dataset"].astype(str),
                q["sample_id"].astype(str),
                q["split"].astype(str),
            )
        )
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def stable_csv_semantic_hash(df: pd.DataFrame) -> str:
    cols = [
        "dataset",
        "split",
        "sample_id",
        "label_raw",
        "label_harmonized",
        "known_unknown",
        "unknown_family",
        "unknown_type",
        "openworld_split_group_id",
        "label_harmonization_quality",
        "known_class_mapping_exact",
        "ontology_5class_known_exact_eligible",
        "ontology_5class_openworld_eligible",
        "std_age",
        "std_sex",
        "std_location",
        "std_diameter",
        "std_diameter_mm",
        "std_diameter_definition",
        "age_available",
        "sex_available",
        "location_available",
        "text_age_only",
        "text_location_only",
        "text_shared_robust",
        "text_core",
        "text_full",
        "text_missing_explicit",
        "primary_eval_eligible",
        "evaluation_exclusion_reason",
    ]
    # CSV round-trip invariant: empty strings are read back as NaN by pandas.
    # Canonicalize both representations to the same empty token before hashing.
    q = df[cols].copy().fillna("").astype(str)
    q = q.sort_values(["dataset", "sample_id", "split"]).reset_index(drop=True)
    payload = q.to_csv(index=False, lineterminator="\n")
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def json_dump(obj, path: Path) -> None:
    def conv(x):
        if isinstance(x, Path):
            return str(x)
        if isinstance(x, np.integer):
            return int(x)
        if isinstance(x, np.floating):
            x = float(x)
            return None if math.isnan(x) else x
        if isinstance(x, np.ndarray):
            return x.tolist()
        if isinstance(x, dict):
            return {str(k): conv(v) for k, v in x.items()}
        if isinstance(x, (list, tuple)):
            return [conv(v) for v in x]
        return x

    path.write_text(
        json.dumps(conv(obj), indent=2),
        encoding="utf-8",
    )


# =============================================================================
# AUTHORITATIVE ISIC TRAINING GROUND-TRUTH PARSER
# =============================================================================

def parse_isic_training_groundtruth(path: Path) -> pd.DataFrame:
    gt = pd.read_csv(path, low_memory=False)
    if "image" not in gt.columns:
        raise RuntimeError("ISIC training ground-truth must contain an 'image' column.")

    candidates = ["MEL", "NV", "BCC", "AK", "BKL", "DF", "VASC", "SCC", "UNK"]
    present = [c for c in candidates if c in gt.columns]
    required = ["MEL", "NV", "BCC", "AK", "BKL", "DF", "VASC", "SCC"]
    missing = [c for c in required if c not in present]
    if missing:
        raise RuntimeError(f"ISIC ground-truth missing expected class columns: {missing}")

    values = gt[present].apply(pd.to_numeric, errors="coerce").fillna(0.0)
    positives = values.gt(0.5)
    npos = positives.sum(axis=1)
    if not npos.eq(1).all():
        bad = gt.loc[~npos.eq(1), ["image"] + present].head(20)
        raise RuntimeError(
            "ISIC training ground-truth must have exactly one positive class per row:\n"
            + bad.to_string(index=False)
        )

    gt = gt.copy()
    gt["authoritative_label_raw"] = [
        present[int(i)] for i in positives.to_numpy().argmax(axis=1)
    ]
    return gt[["image", "authoritative_label_raw"]]


# =============================================================================
# PASS 1 — RAW SOURCE RECONCILIATION
# =============================================================================

def pass1_raw_crosscheck(
    v1,
    pad_raw,
    isic_meta,
    isic_gt,
    mcr_lesion,
    mcr_image,
    mcr_subject,
    mcr_unified,
    mcr_derm,
    mcr_histo,
):
    rows = []

    def check(name, condition, details=""):
        rows.append(
            {
                "check": name,
                "passed": bool(condition),
                "details": str(details),
            }
        )
        if not condition:
            raise RuntimeError(
                f"PASS-1 RAW CROSSCHECK FAILED: {name}: {details}"
            )

    def same_normalized_text(a, b):
        aa = a.fillna("").astype(str).str.strip().str.lower()
        bb = b.fillna("").astype(str).str.strip().str.lower()
        return (aa == bb).all()

    # PAD ---------------------------------------------------------------------
    pad = v1[v1["dataset"].eq("PAD-UFES-20")].copy()

    check(
        "PAD row count equals raw metadata",
        len(pad) == len(pad_raw),
        f"{len(pad)} vs {len(pad_raw)}",
    )

    check(
        "PAD sample set equals raw img_id set",
        set(pad["sample_id"].astype(str))
        == set(pad_raw["img_id"].astype(str)),
    )

    merged = pad.merge(
        pad_raw,
        left_on="sample_id",
        right_on="img_id",
        how="left",
        suffixes=("_v1", "_raw"),
    )

    check(
        "PAD every protocol row merges to raw metadata",
        merged["img_id"].notna().all(),
    )

    check(
        "PAD label_raw equals raw diagnostic",
        (
            merged["label_raw"].astype(str)
            == merged["diagnostic"].astype(str)
        ).all(),
    )

    check(
        "PAD patient_id matches raw",
        (
            merged["patient_id_v1"].astype(str)
            == merged["patient_id_raw"].astype(str)
        ).all(),
    )

    check(
        "PAD lesion_id matches raw",
        all(
            norm_id(a) == norm_id(b)
            for a, b in zip(
                merged["lesion_id_v1"],
                merged["lesion_id_raw"],
            )
        ),
    )

    check(
        "PAD site_clean equals raw region",
        (
            merged["site_clean"].astype(str)
            == merged["region"].astype(str)
        ).all(),
    )

    check(
        "PAD age_clean equals raw age",
        np.allclose(
            pd.to_numeric(merged["age_clean"], errors="coerce"),
            pd.to_numeric(merged["age"], errors="coerce"),
            equal_nan=True,
        ),
    )

    check(
        "PAD sex_clean equals raw gender",
        same_normalized_text(merged["sex_clean"], merged["gender"]),
    )

    check(
        "PAD diameter_1_clean equals raw diameter_1",
        np.allclose(
            pd.to_numeric(merged["diameter_1_clean"], errors="coerce"),
            pd.to_numeric(merged["diameter_1"], errors="coerce"),
            equal_nan=True,
        ),
    )

    check(
        "PAD diameter_2_clean equals raw diameter_2",
        np.allclose(
            pd.to_numeric(merged["diameter_2_clean"], errors="coerce"),
            pd.to_numeric(merged["diameter_2"], errors="coerce"),
            equal_nan=True,
        ),
    )

    # ISIC --------------------------------------------------------------------
    isic = v1[v1["dataset"].eq("ISIC 2019")].copy()
    raw_ids = set(isic_meta["image"].astype(str))

    train_rows = isic[
        isic["sample_id"].astype(str).isin(raw_ids)
    ].copy()

    check(
        "ISIC training metadata coverage is exact",
        len(train_rows) == len(isic_meta),
        f"{len(train_rows)} vs {len(isic_meta)}",
    )

    merged = train_rows.merge(
        isic_meta,
        left_on="sample_id",
        right_on="image",
        how="left",
        suffixes=("_v1", "_raw"),
    )

    check(
        "ISIC every training metadata row merges",
        merged["image"].notna().all(),
    )

    def same_str(a, b):
        return same_normalized_text(a, b)

    check(
        "ISIC sex matches raw metadata",
        same_str(merged["sex_v1"], merged["sex_raw"]),
    )
    check(
        "ISIC anatomy matches raw metadata",
        same_str(
            merged["anatom_site_general_v1"],
            merged["anatom_site_general_raw"],
        ),
    )
    check(
        "ISIC age matches raw metadata",
        np.allclose(
            pd.to_numeric(merged["age_approx_v1"], errors="coerce"),
            pd.to_numeric(merged["age_approx_raw"], errors="coerce"),
            equal_nan=True,
        ),
    )
    check(
        "ISIC lesion_id matches raw metadata",
        same_str(merged["lesion_id_v1"], merged["lesion_id_raw"]),
    )

    gt_merged = train_rows[["sample_id", "label_raw"]].merge(
        isic_gt,
        left_on="sample_id",
        right_on="image",
        how="left",
    )
    check(
        "ISIC authoritative training labels cover every training-pool image",
        gt_merged["authoritative_label_raw"].notna().all()
        and len(gt_merged) == len(isic_gt),
        f"protocol_rows={len(gt_merged)} gt_rows={len(isic_gt)}",
    )
    check(
        "ISIC label_raw equals authoritative training ground truth",
        (
            gt_merged["label_raw"].astype(str)
            == gt_merged["authoritative_label_raw"].astype(str)
        ).all(),
    )

    # MCR ---------------------------------------------------------------------
    mcr = v1[v1["dataset"].eq("MCR-SL")].copy()

    check(
        "MCR protocol has one row per lesion",
        mcr["lesion_id"].astype(str).nunique() == len(mcr),
        len(mcr),
    )

    unified = mcr_unified[
        ["lesion_id", "unified_diagnosis"]
    ].rename(
        columns={"unified_diagnosis": "raw_unified_diagnosis"}
    )

    merged = mcr.merge(
        unified,
        on="lesion_id",
        how="left",
    )

    check(
        "MCR every protocol lesion exists in unified diagnosis",
        merged["raw_unified_diagnosis"].notna().all(),
    )

    check(
        "MCR label_raw equals raw unified_diagnosis",
        (
            merged["label_raw"].astype(str)
            == merged["raw_unified_diagnosis"].astype(str)
        ).all(),
    )

    lesion_raw = mcr_lesion[
        [
            "subject_id",
            "lesion_id",
            "location",
            "location_group",
            "diameter",
            "diagnosis_image_id",
        ]
    ].rename(
        columns={
            "subject_id": "raw_subject_id",
            "location": "raw_location",
            "location_group": "raw_location_group",
            "diameter": "raw_diameter",
            "diagnosis_image_id": "raw_diagnosis_image_id",
        }
    )

    merged = mcr.merge(
        lesion_raw,
        on="lesion_id",
        how="left",
    )

    check(
        "MCR every protocol lesion exists in lesion.xlsx",
        merged["raw_subject_id"].notna().all(),
    )

    check(
        "MCR subject_id matches raw lesion table",
        (
            merged["subject_id"].astype(str)
            == merged["raw_subject_id"].astype(str)
        ).all(),
    )

    subject_raw = mcr_subject[["subject_id", "age", "sex"]].rename(
        columns={"age": "raw_age", "sex": "raw_sex"}
    )
    subject_merged = mcr.merge(subject_raw, on="subject_id", how="left")
    check(
        "MCR every protocol subject exists in subject.xlsx",
        subject_merged["raw_age"].notna().all() | subject_merged["raw_sex"].notna().all(),
    )
    check(
        "MCR age_clean equals subject.xlsx age",
        np.allclose(
            pd.to_numeric(subject_merged["age_clean"], errors="coerce"),
            pd.to_numeric(subject_merged["raw_age"], errors="coerce"),
            equal_nan=True,
        ),
    )
    check(
        "MCR sex_clean equals subject.xlsx sex",
        same_normalized_text(subject_merged["sex_clean"], subject_merged["raw_sex"]),
    )

    check(
        "MCR location equals lesion.xlsx location",
        same_normalized_text(merged["location"], merged["raw_location"]),
    )
    check(
        "MCR location_group equals lesion.xlsx location_group",
        same_normalized_text(merged["location_group"], merged["raw_location_group"]),
    )
    check(
        "MCR diameter_clean equals lesion.xlsx diameter",
        np.allclose(
            pd.to_numeric(merged["diameter_clean"], errors="coerce"),
            pd.to_numeric(merged["raw_diameter"], errors="coerce"),
            equal_nan=True,
        ),
    )

    derm_sets = (
        mcr_derm.groupby("lesion_id")["diagnosis"]
        .apply(lambda s: set(s.dropna().astype(str)))
        .to_dict()
    )
    derm_ok = []
    for lesion_id, final_dx in zip(mcr_unified["lesion_id"], mcr_unified["dermatology_diagnosis"]):
        values = derm_sets.get(lesion_id, set())
        derm_ok.append(str(final_dx) == "UNK" or str(final_dx) in values)
    check(
        "MCR unified dermatology diagnosis is supported by raw assessments or explicit UNK consensus",
        all(derm_ok),
        f"bad={sum(not x for x in derm_ok)}",
    )

    histo_by_id = mcr_histo.set_index("diagnosis_id", drop=False)
    histo_orphans = []
    histo_bad = []
    for _, row in mcr_unified[mcr_unified["diagnosis_id_histopathology"].notna()].iterrows():
        did = str(row["diagnosis_id_histopathology"])
        if did not in histo_by_id.index.astype(str):
            histo_orphans.append((str(row["lesion_id"]), did))
            continue
        rr = histo_by_id.loc[did]
        if isinstance(rr, pd.DataFrame):
            rr = rr.iloc[0]
        if str(rr["lesion_id"]) != str(row["lesion_id"]) or str(rr["diagnosis"]) != str(row["histopathology_diagnosis"]):
            histo_bad.append((str(row["lesion_id"]), did))
    check(
        "MCR resolvable histopathology references match raw histopathology table",
        len(histo_bad) == 0,
        histo_bad[:10],
    )
    # Public release contains one known orphan reference (L0196 -> DH00045).
    check(
        "MCR histopathology orphan references are limited to the documented release inconsistency",
        set(histo_orphans).issubset({("L0196", "DH00045")}),
        histo_orphans,
    )

    image_to_lesion = (
        mcr_image.set_index("image_id")["lesion_id"]
        .astype(str)
        .to_dict()
    )

    selected_ok = np.asarray(
        [
            image_to_lesion.get(str(image_id), "") == str(lesion_id)
            for image_id, lesion_id in zip(
                mcr["selected_image_id"],
                mcr["lesion_id"],
            )
        ]
    )

    check(
        "MCR selected image belongs to same lesion",
        selected_ok.all(),
        f"bad={int((~selected_ok).sum())}",
    )

    raw_diagnosis_image_ok = []
    for image_id, lesion_id in zip(
        merged["raw_diagnosis_image_id"],
        merged["lesion_id"],
    ):
        if pd.isna(image_id):
            raw_diagnosis_image_ok.append(True)
        else:
            raw_diagnosis_image_ok.append(
                image_to_lesion.get(str(image_id), "")
                == str(lesion_id)
            )

    raw_diagnosis_image_ok = np.asarray(
        raw_diagnosis_image_ok
    )

    conflict_lesions = set(
        merged.loc[
            ~raw_diagnosis_image_ok,
            "lesion_id",
        ].astype(str)
    )

    check(
        "MCR diagnosis-image metadata conflicts are exactly L0247/L0248",
        conflict_lesions == MCR_CONFLICT_LESIONS,
        sorted(conflict_lesions),
    )

    return pd.DataFrame(rows)


# =============================================================================
# CORRECTION
# =============================================================================

def correct_protocol(v1: pd.DataFrame) -> pd.DataFrame:
    out = v1.copy()

    # Preserve important V1 values for row-level audit.
    preserve = [
        "std_age",
        "std_location",
        "std_diameter",
        "text_core",
        "text_full",
        "text_missing_explicit",
        "label_harmonized",
        "known_unknown",
        "unknown_type",
    ]

    for col in preserve:
        if col in out.columns:
            out[f"v1_{col}"] = out[col]

    # Ensure all standardized columns exist and normalize missing values.
    for field in FULL_FIELDS:
        if field not in out.columns:
            out[field] = "unknown"

        out[field] = out[field].apply(clean_std)

    # -------------------------------------------------------------------------
    # AGE / SEX
    # -------------------------------------------------------------------------
    out["std_age_group"] = out["age_clean"].apply(decade_age)
    out["std_age"] = out["std_age_group"]
    out["std_sex"] = out["sex_clean"].apply(normalize_sex)

    # -------------------------------------------------------------------------
    # ANATOMICAL SITE — explicit dataset-specific maps
    # -------------------------------------------------------------------------
    corrected_locations = []

    for _, row in out.iterrows():
        dataset = str(row["dataset"])

        if dataset == "PAD-UFES-20":
            raw = norm_string(row.get("site_clean", "")).upper()

            if raw not in PAD_SITE_MAP:
                raise RuntimeError(
                    f"Unmapped PAD site: {raw!r}"
                )

            corrected_locations.append(
                PAD_SITE_MAP[raw]
            )

        elif dataset == "ISIC 2019":
            raw = norm_string(row.get("site_clean", "")).lower()

            if not raw:
                corrected_locations.append("unknown")
            elif raw not in ISIC_SITE_MAP:
                raise RuntimeError(
                    f"Unmapped ISIC site: {raw!r}"
                )
            else:
                corrected_locations.append(
                    ISIC_SITE_MAP[raw]
                )

        elif dataset == "MCR-SL":
            raw = norm_string(row.get("location", "")).lower()

            if not raw:
                corrected_locations.append("unknown")
            elif raw not in MCR_SITE_MAP:
                raise RuntimeError(
                    f"Unmapped MCR site: {raw!r}"
                )
            else:
                corrected_locations.append(
                    MCR_SITE_MAP[raw]
                )

        else:
            raise RuntimeError(
                f"Unexpected dataset in protocol: {dataset}"
            )

    out["std_location"] = corrected_locations

    # -------------------------------------------------------------------------
    # DIAMETER — one semantic definition everywhere
    # -------------------------------------------------------------------------
    diameter_mm = []

    for _, row in out.iterrows():
        dataset = str(row["dataset"])

        if dataset == "PAD-UFES-20":
            value = max_numeric(
                row.get("diameter_1_clean"),
                row.get("diameter_2_clean"),
            )

        elif dataset == "MCR-SL":
            value = max_numeric(
                row.get("diameter_clean")
            )

        elif dataset == "ISIC 2019":
            value = np.nan

        else:
            raise RuntimeError(dataset)

        diameter_mm.append(value)

    out["std_diameter_mm"] = diameter_mm
    out["std_diameter"] = out["std_diameter_mm"].apply(
        format_mm
    )
    out["std_diameter_definition"] = np.select(
        [
            out["dataset"].eq("PAD-UFES-20"),
            out["dataset"].eq("MCR-SL"),
            out["dataset"].eq("ISIC 2019"),
        ],
        [
            "lesion diameter in mm; PAD method=max(horizontal, vertical)",
            "lesion diameter in mm; MCR method=reported scalar diameter",
            "unavailable",
        ],
        default="unknown",
    )

    # Normalize all remaining standardized values.
    for field in FULL_FIELDS:
        out[field] = out[field].apply(clean_std)

    # -------------------------------------------------------------------------
    # LABEL ONTOLOGY
    # -------------------------------------------------------------------------
    harmonized = []
    mapping_quality = []
    mapping_note = []
    unknown_family = []
    unknown_type = []

    for _, row in out.iterrows():
        dataset = str(row["dataset"])
        raw = str(row["label_raw"])

        if dataset == "PAD-UFES-20":
            mapping = {
                "ACK": "AK",
                "BCC": "BCC",
                "MEL": "MEL",
                "NEV": "NEV",
                "SCC": "SCC",
                "SEK": "SK",
            }

            if raw not in mapping:
                raise RuntimeError(
                    f"Unexpected PAD diagnosis: {raw}"
                )

            h = mapping[raw]

            harmonized.append(h)
            mapping_quality.append("exact_alias")
            mapping_note.append(
                "PAD diagnostic alias harmonized to study ontology"
            )
            unknown_family.append("known")
            unknown_type.append("known")

        elif dataset == "ISIC 2019":
            mapping = {
                "AK": "AK",
                "BCC": "BCC",
                "MEL": "MEL",
                "NV": "NEV",
                "SCC": "SCC",
                "BKL": "SK",
                "DF": "DF",
                "VASC": "VASC",
                "UNK": "UNK",
            }

            if raw not in mapping:
                raise RuntimeError(
                    f"Unexpected ISIC diagnosis: {raw}"
                )

            h = mapping[raw]
            harmonized.append(h)

            if raw == "BKL":
                mapping_quality.append(
                    "approximate_broader_target_to_source"
                )
                mapping_note.append(
                    "ISIC BKL contains seborrheic keratosis plus "
                    "solar lentigo and lichen-planus-like keratosis; "
                    "mapped to source SK only for six-class compatibility"
                )

            elif raw == "NV":
                mapping_quality.append("exact_alias")
                mapping_note.append(
                    "ISIC NV mapped to NEV alias"
                )

            else:
                mapping_quality.append(
                    "exact_or_preserved"
                )
                mapping_note.append(
                    "ISIC class preserved or exact harmonization"
                )

            if raw == "VASC":
                unknown_family.append("vascular")
                unknown_type.append("semantic_unseen")

            elif raw == "DF":
                unknown_family.append("dermatofibroma")
                unknown_type.append("semantic_unseen")

            elif raw == "UNK":
                unknown_family.append(
                    "challenge_outlier"
                )
                unknown_type.append(
                    "challenge_outlier"
                )

            else:
                unknown_family.append("known")
                unknown_type.append("known")

        elif dataset == "MCR-SL":
            h = raw

            harmonized.append(h)
            mapping_quality.append(
                "exact_or_preserved"
            )
            mapping_note.append(
                "MCR unified diagnosis preserved"
            )

            if raw == "ANG":
                unknown_family.append("vascular")
                unknown_type.append("semantic_unseen")

            elif raw == "DF":
                unknown_family.append("dermatofibroma")
                unknown_type.append("semantic_unseen")

            elif raw == "ATY":
                unknown_family.append(
                    "atypical_melanocytic"
                )
                unknown_type.append("semantic_unseen")

            else:
                unknown_family.append("known")
                unknown_type.append("known")

        else:
            raise RuntimeError(dataset)

    out["label_harmonized"] = harmonized
    out["label_harmonization_quality"] = mapping_quality
    out["label_harmonization_note"] = mapping_note
    out["unknown_family"] = unknown_family
    out["unknown_type"] = unknown_type

    out["known_unknown"] = np.where(
        out["label_harmonized"].isin(KNOWN_CLASSES),
        "known",
        "unknown",
    )

    # Ontology sensitivities. The known-only flag is a five-class CLOSED-SET
    # sensitivity; the open-world flag removes SK/BKL from the known set while
    # retaining every unknown sample.
    out["ontology_5class_known_exact_eligible"] = (
        out["label_harmonized"].isin(EXACT_5CLASS)
    )
    out["ontology_5class_openworld_eligible"] = (
        out["label_harmonized"].isin(EXACT_5CLASS)
        | out["known_unknown"].eq("unknown")
    )
    # Backward-compatible alias; explicitly documented as known-only.
    out["ontology_5class_exact_eligible"] = out[
        "ontology_5class_known_exact_eligible"
    ]

    out["known_class_mapping_exact"] = ~(
        out["dataset"].eq("ISIC 2019")
        & out["label_raw"].eq("BKL")
    )

    # -------------------------------------------------------------------------
    # MCR DIAGNOSIS-IMAGE METADATA CONFLICTS
    # -------------------------------------------------------------------------
    out["primary_eval_eligible"] = True
    out["evaluation_exclusion_reason"] = ""

    mcr_conflict = (
        out["dataset"].eq("MCR-SL")
        & out["lesion_id"].astype(str).isin(
            MCR_CONFLICT_LESIONS
        )
    )

    out.loc[
        mcr_conflict,
        "primary_eval_eligible",
    ] = False

    out.loc[
        mcr_conflict,
        "evaluation_exclusion_reason",
    ] = (
        "raw diagnosis_image_id points to the other lesion; "
        "source metadata conflict"
    )

    # -------------------------------------------------------------------------
    # SCHEMA AVAILABILITY
    # -------------------------------------------------------------------------
    out["age_available"] = ~out["std_age"].apply(is_missing)
    out["sex_available"] = ~out["std_sex"].apply(is_missing)
    out["location_available"] = ~out["std_location"].apply(is_missing)

    availability = np.column_stack(
        [
            ~out[field]
            .astype(str)
            .str.lower()
            .isin(["unknown", "nan", "none", ""])
            for field in FULL_FIELDS
        ]
    )

    out["metadata_fields_present_n"] = (
        availability.sum(axis=1)
    )
    out["metadata_fields_present_fraction"] = (
        availability.mean(axis=1)
    )

    out["metadata_schema_signature"] = [
        "".join(
            "1" if value else "0"
            for value in row
        )
        for row in availability
    ]

    # -------------------------------------------------------------------------
    # TEXTUALIZATIONS
    # -------------------------------------------------------------------------

    # Canonical single-field ablations used by Table 2.
    out["text_age_only"] = out.apply(
        lambda row: build_text(row, AGE_ONLY_FIELDS, explicit_missing=False),
        axis=1,
    )
    out["text_location_only"] = out.apply(
        lambda row: build_text(row, LOCATION_ONLY_FIELDS, explicit_missing=False),
        axis=1,
    )

    # Restricted shared-schema PRIMARY representation.
    out["text_shared_robust"] = out.apply(
        lambda row: build_text(
            row,
            ROBUST_PRIMARY_FIELDS,
            explicit_missing=False,
        ),
        axis=1,
    )

    # Corrected historical core, retained as sensitivity because PAD sex
    # availability is strongly source-acquisition/biopsy-linked.
    out["text_core"] = out.apply(
        lambda row: build_text(
            row,
            DEMOGRAPHIC_FIELDS,
            explicit_missing=False,
        ),
        axis=1,
    )

    # Heterogeneous-schema stress test.
    out["text_full"] = out.apply(
        lambda row: build_text(
            row,
            FULL_FIELDS,
            explicit_missing=False,
        ),
        axis=1,
    )

    # Informative-missingness stress test only.
    out["text_missing_explicit"] = out.apply(
        lambda row: build_text(
            row,
            FULL_FIELDS,
            explicit_missing=True,
        ),
        axis=1,
    )

    out["primary_text_column"] = (
        "text_shared_robust"
    )

    out["text_core_role"] = (
        "secondary_demographic_sensitivity_due_PAD_sex_missingness"
    )

    out["text_full_role"] = (
        "heterogeneous_schema_stress_test"
    )

    out["text_missing_explicit_role"] = (
        "informative_missingness_stress_test_only"
    )

    out["protocol_parent"] = "openworld_v1"
    out["protocol_name"] = (
        "openworld_v2_1_final"
    )

    return out


# =============================================================================
# PASS 2 — IN-MEMORY SEMANTIC / PROTOCOL AUDIT
# =============================================================================

def pass2_semantic_audit(v1, v2):
    rows = []

    def check(name, condition, details=""):
        rows.append(
            {
                "check": name,
                "passed": bool(condition),
                "details": str(details),
            }
        )
        if not condition:
            raise RuntimeError(
                f"PASS-2 SEMANTIC AUDIT FAILED: {name}: {details}"
            )

    check(
        "row count unchanged",
        len(v1) == len(v2),
        f"{len(v1)} vs {len(v2)}",
    )

    check(
        "dataset/sample/split membership hash unchanged",
        membership_hash(v1) == membership_hash(v2),
    )

    check(
        "dataset/sample row identity unchanged",
        (
            v1["dataset"].astype(str).to_numpy()
            == v2["dataset"].astype(str).to_numpy()
        ).all()
        and (
            v1["sample_id"].astype(str).to_numpy()
            == v2["sample_id"].astype(str).to_numpy()
        ).all(),
    )

    # Expected split sizes.
    observed_counts = (
        v2.groupby(["dataset", "split"])
        .size()
        .to_dict()
    )

    for key, expected in EXPECTED_SPLITS.items():
        check(
            f"split count {key[0]} / {key[1]}",
            observed_counts.get(key) == expected,
            observed_counts.get(key),
        )

    # PAD patient disjointness.
    pad = v2[
        v2["dataset"].eq("PAD-UFES-20")
    ]

    for a, b in [
        ("source_train", "source_val"),
        ("source_train", "source_test"),
        ("source_val", "source_test"),
    ]:
        aa = set(
            pad.loc[
                pad["split"].eq(a),
                "patient_id",
            ]
            .dropna()
            .astype(str)
        )
        bb = set(
            pad.loc[
                pad["split"].eq(b),
                "patient_id",
            ]
            .dropna()
            .astype(str)
        )

        check(
            f"PAD patient disjoint {a} vs {b}",
            len(aa & bb) == 0,
            len(aa & bb),
        )

    # ISIC lesion-group disjointness.
    isic = v2[
        v2["dataset"].eq("ISIC 2019")
    ]

    ia = set(
        isic.loc[
            isic["split"].eq("target_adapt_ow"),
            "openworld_split_group_id",
        ].astype(str)
    )
    iv = set(
        isic.loc[
            isic["split"].eq("target_val_ow"),
            "openworld_split_group_id",
        ].astype(str)
    )

    check(
        "ISIC adapt/val lesion-group disjoint",
        len(ia & iv) == 0,
        len(ia & iv),
    )

    # MCR subject disjointness.
    mcr = v2[
        v2["dataset"].eq("MCR-SL")
    ]

    for a, b in [
        ("target_adapt_ow", "target_val_ow"),
        ("target_adapt_ow", "target_test_ow"),
        ("target_val_ow", "target_test_ow"),
    ]:
        aa = set(
            mcr.loc[
                mcr["split"].eq(a),
                "subject_id",
            ].astype(str)
        )
        bb = set(
            mcr.loc[
                mcr["split"].eq(b),
                "subject_id",
            ].astype(str)
        )

        check(
            f"MCR subject disjoint {a} vs {b}",
            len(aa & bb) == 0,
            len(aa & bb),
        )

    # Critical FOREARM fix.
    forearm_bad = v2[
        v2["dataset"].eq("PAD-UFES-20")
        & v2["site_clean"]
        .astype(str)
        .str.upper()
        .eq("FOREARM")
        & ~v2["std_location"].eq(
            "upper_extremity"
        )
    ]

    check(
        "PAD FOREARM always maps upper_extremity",
        forearm_bad.empty,
        len(forearm_bad),
    )

    # Full PAD exact-map audit.
    bad_sites = []

    for raw, group in pad.groupby(
        pad["site_clean"].astype(str)
    ):
        expected = PAD_SITE_MAP[raw]

        if not group["std_location"].eq(
            expected
        ).all():
            bad_sites.append(raw)

    check(
        "all PAD sites follow explicit mapping",
        not bad_sites,
        bad_sites,
    )

    # Age representation.
    age_pattern = re.compile(
        r"^\d{1,3}-\d{1,3}$|^unknown$"
    )

    bad_age = [
        value
        for value in v2["std_age"].astype(str).unique()
        if not age_pattern.match(value)
    ]

    check(
        "std_age contains decade bands or unknown only",
        not bad_age,
        bad_age[:20],
    )

    # Diameter semantic check.
    pad_with_diameter = pad[
        pad["std_diameter_mm"].notna()
    ]

    recomputed_pad = pad_with_diameter.apply(
        lambda row: max_numeric(
            row.get("diameter_1_clean"),
            row.get("diameter_2_clean"),
        ),
        axis=1,
    )

    check(
        "PAD diameter equals max of two axes",
        np.allclose(
            pad_with_diameter["std_diameter_mm"],
            recomputed_pad,
            equal_nan=True,
        ),
    )

    mcr_with_diameter = mcr[
        mcr["std_diameter_mm"].notna()
    ]

    check(
        "MCR diameter equals supplied scalar diameter",
        np.allclose(
            mcr_with_diameter["std_diameter_mm"],
            pd.to_numeric(
                mcr_with_diameter["diameter_clean"],
                errors="coerce",
            ),
            equal_nan=True,
        ),
    )

    # Ontology.
    vascular = isic[
        isic["label_raw"].eq("VASC")
    ]

    check(
        "ISIC VASC preserved as VASC unknown",
        vascular["label_harmonized"]
        .eq("VASC")
        .all()
        and vascular["known_unknown"]
        .eq("unknown")
        .all(),
        vascular["label_harmonized"]
        .value_counts()
        .to_dict(),
    )

    bkl = isic[
        isic["label_raw"].eq("BKL")
    ]

    check(
        "ISIC BKL -> SK is explicitly approximate",
        bkl["label_harmonized"].eq("SK").all()
        and bkl["label_harmonization_quality"]
        .eq(
            "approximate_broader_target_to_source"
        )
        .all(),
        len(bkl),
    )

    check(
        "BKL excluded from exact five-class sensitivity",
        (~bkl["ontology_5class_known_exact_eligible"]).all()
        and (~bkl["ontology_5class_openworld_eligible"]).all(),
    )

    unknown_rows = v2[v2["known_unknown"].eq("unknown")]
    check(
        "all unknown rows retained in five-known-class open-world sensitivity",
        unknown_rows["ontology_5class_openworld_eligible"].all(),
        len(unknown_rows),
    )

    # MCR conflict exclusions.
    conflict = mcr[
        mcr["lesion_id"]
        .astype(str)
        .isin(MCR_CONFLICT_LESIONS)
    ]

    check(
        "MCR L0247/L0248 are preserved but primary-eval excluded",
        len(conflict) == 2
        and (
            ~conflict["primary_eval_eligible"]
            .astype(bool)
        ).all(),
        len(conflict),
    )

    non_conflict = mcr[
        ~mcr["lesion_id"]
        .astype(str)
        .isin(MCR_CONFLICT_LESIONS)
    ]

    check(
        "all other MCR rows remain primary-eval eligible",
        non_conflict["primary_eval_eligible"]
        .astype(bool)
        .all(),
    )

    # Primary text cannot contain sex or full-schema fields.
    forbidden_primary = [
        "sex:",
        "lesion diameter:",
        "fitzpatrick",
        "itching:",
        "growth:",
        "pain:",
        "change:",
        "bleeding:",
        "elevation:",
        "history:",
        "smoking:",
        "alcohol:",
        "pesticide:",
    ]

    primary_bad = 0

    for text in v2[
        "text_shared_robust"
    ].astype(str):
        lower = text.lower()

        if any(
            token in lower
            for token in forbidden_primary
        ):
            primary_bad += 1

    check(
        "text_shared_robust contains age/location only",
        primary_bad == 0,
        primary_bad,
    )

    # No diagnosis leakage.
    leakage_tokens = [
        "diagnosis:",
        "label:",
        "pathology:",
        "clinical impression:",
    ]

    leakage_n = 0

    for column in [
        "text_age_only",
        "text_location_only",
        "text_shared_robust",
        "text_core",
        "text_full",
        "text_missing_explicit",
    ]:
        leakage_n += int(
            v2[column]
            .astype(str)
            .str.lower()
            .apply(
                lambda value: any(
                    token in value
                    for token in leakage_tokens
                )
            )
            .sum()
        )

    check(
        "no diagnosis/pathology field leaks into text",
        leakage_n == 0,
        leakage_n,
    )

    return pd.DataFrame(rows)


# =============================================================================
# REPORTS
# =============================================================================

def metadata_availability_report(df):
    rows = []

    for dataset, group in df.groupby("dataset"):
        for field in FULL_FIELDS:
            available = ~group[field].apply(is_missing)

            rows.append(
                {
                    "dataset": dataset,
                    "field": field,
                    "n": int(len(group)),
                    "available_n": int(
                        available.sum()
                    ),
                    "available_fraction": float(
                        available.mean()
                    ),
                }
            )

    return pd.DataFrame(rows)


def pad_availability_by_class(df):
    pad = df[
        df["dataset"].eq("PAD-UFES-20")
    ]

    rows = []

    for label, group in pad.groupby(
        "label_harmonized"
    ):
        for field in FULL_FIELDS:
            available = ~group[field].apply(
                is_missing
            )

            rows.append(
                {
                    "label": label,
                    "field": field,
                    "n": int(len(group)),
                    "available_n": int(
                        available.sum()
                    ),
                    "available_fraction": float(
                        available.mean()
                    ),
                }
            )

    return pd.DataFrame(rows)


def label_mapping_audit(df):
    return (
        df.groupby(
            [
                "dataset",
                "label_raw",
                "label_harmonized",
                "known_unknown",
                "unknown_family",
                "label_harmonization_quality",
                "ontology_5class_known_exact_eligible",
                "ontology_5class_openworld_eligible",
            ],
            dropna=False,
        )
        .size()
        .reset_index(name="n")
        .sort_values(
            ["dataset", "label_raw"]
        )
    )


def save_split_files(df, outdir):
    for dataset, prefix in [
        ("PAD-UFES-20", "pad"),
        ("ISIC 2019", "isic"),
        ("MCR-SL", "mcr"),
    ]:
        q = df[
            df["dataset"].eq(dataset)
        ]

        for split, group in q.groupby("split"):
            safe_split = re.sub(
                r"[^A-Za-z0-9_]+",
                "_",
                str(split),
            )

            group.to_csv(
                outdir
                / f"{prefix}_{safe_split}_v2_1.csv",
                index=False,
            )

            primary = group[
                group["primary_eval_eligible"]
                .astype(bool)
            ]

            primary.to_csv(
                outdir
                / f"{prefix}_{safe_split}_v2_1_primary_eligible.csv",
                index=False,
            )

    # Exact-ontology five-known-class CLOSED-SET sensitivity.
    five_known = df[
        df["ontology_5class_known_exact_eligible"].astype(bool)
        & df["primary_eval_eligible"].astype(bool)
    ]
    five_known.to_csv(
        outdir / "exact_5class_known_closedset_sensitivity_all_rows.csv",
        index=False,
    )

    # Five-known-class OPEN-WORLD sensitivity: retains all unknowns.
    five_ow = df[
        df["ontology_5class_openworld_eligible"].astype(bool)
        & df["primary_eval_eligible"].astype(bool)
    ]
    five_ow.to_csv(
        outdir / "exact_5known_openworld_sensitivity_all_rows.csv",
        index=False,
    )

    # Physically label-stripped adaptation files for strict UDA/DG pipelines.
    forbidden_tokens = (
        "label", "diagnos", "known_unknown", "unknown_type", "unknown_family",
        "ground_truth", "pathology", "histopath", "dermatology", "malignancy",
        "ontology_", "mapping_exact"
    )
    for dataset, prefix in [("ISIC 2019", "isic"), ("MCR-SL", "mcr")]:
        q = df[df["dataset"].eq(dataset) & df["split"].eq("target_adapt_ow")].copy()
        drop_cols = [
            c for c in q.columns
            if any(token in c.lower() for token in forbidden_tokens)
        ]
        q = q.drop(columns=drop_cols, errors="ignore")
        q.to_csv(
            outdir / f"{prefix}_target_adapt_ow_v2_1_model_unlabeled.csv",
            index=False,
        )


# =============================================================================
# PASS 3 — RELOAD FROM DISK
# =============================================================================

def pass3_reload_check(
    output_csv: Path,
    v1: pd.DataFrame,
    expected_semantic_hash: str,
):
    reloaded = pd.read_csv(
        output_csv,
        low_memory=False,
    )

    rows = []

    def check(name, condition, details=""):
        rows.append(
            {
                "check": name,
                "passed": bool(condition),
                "details": str(details),
            }
        )
        if not condition:
            raise RuntimeError(
                f"PASS-3 RELOAD CHECK FAILED: {name}: {details}"
            )

    check(
        "reloaded row count matches V1",
        len(reloaded) == len(v1),
        len(reloaded),
    )

    check(
        "reloaded split membership hash matches V1",
        membership_hash(reloaded)
        == membership_hash(v1),
    )

    observed_hash = stable_csv_semantic_hash(
        reloaded
    )

    check(
        "reloaded semantic hash matches in-memory V2",
        observed_hash == expected_semantic_hash,
        observed_hash,
    )

    # Repeat critical fixes independently.
    bad_forearm = reloaded[
        reloaded["dataset"].eq("PAD-UFES-20")
        & reloaded["site_clean"]
        .astype(str)
        .str.upper()
        .eq("FOREARM")
        & ~reloaded["std_location"]
        .eq("upper_extremity")
    ]

    check(
        "reload confirms zero FOREARM mapping failures",
        bad_forearm.empty,
        len(bad_forearm),
    )

    vascular = reloaded[
        reloaded["dataset"].eq("ISIC 2019")
        & reloaded["label_raw"].eq("VASC")
    ]

    check(
        "reload confirms VASC preserved",
        vascular["label_harmonized"]
        .eq("VASC")
        .all(),
    )

    check(
        "reload confirms open-world five-known sensitivity retains all unknowns",
        reloaded.loc[
            reloaded["known_unknown"].eq("unknown"),
            "ontology_5class_openworld_eligible",
        ].astype(bool).all(),
    )

    check(
        "reload confirms age/location-only textualizations exist",
        reloaded["text_age_only"].notna().all()
        and reloaded["text_location_only"].notna().all(),
    )

    conflict = reloaded[
        reloaded["dataset"].eq("MCR-SL")
        & reloaded["lesion_id"]
        .astype(str)
        .isin(MCR_CONFLICT_LESIONS)
    ]

    check(
        "reload confirms MCR conflict exclusions",
        len(conflict) == 2
        and (
            ~conflict["primary_eval_eligible"]
            .astype(bool)
        ).all(),
    )

    return pd.DataFrame(rows)


# =============================================================================
# MAIN
# =============================================================================

def main():
    ap = argparse.ArgumentParser()

    ap.add_argument(
        "--v1-csv",
        type=Path,
        default=DEFAULT_V1,
    )
    ap.add_argument(
        "--pad-raw",
        type=Path,
        default=DEFAULT_PAD_RAW,
    )
    ap.add_argument(
        "--isic-meta",
        type=Path,
        default=DEFAULT_ISIC_META,
    )
    ap.add_argument(
        "--isic-ground-truth",
        type=Path,
        default=DEFAULT_ISIC_GT,
        help=(
            "Authoritative ISIC 2019 TRAINING ground-truth one-hot CSV. "
            "The locked target-test ground truth is intentionally not loaded during development."
        ),
    )
    ap.add_argument(
        "--mcr-lesion",
        type=Path,
        default=DEFAULT_MCR_LESION,
    )
    ap.add_argument(
        "--mcr-image",
        type=Path,
        default=DEFAULT_MCR_IMAGE,
    )
    ap.add_argument(
        "--mcr-subject",
        type=Path,
        default=DEFAULT_MCR_SUBJECT,
    )
    ap.add_argument(
        "--mcr-unified",
        type=Path,
        default=DEFAULT_MCR_UNIFIED,
    )
    ap.add_argument(
        "--mcr-derm",
        type=Path,
        default=DEFAULT_MCR_DERM,
    )
    ap.add_argument(
        "--mcr-histo",
        type=Path,
        default=DEFAULT_MCR_HISTO,
    )
    ap.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT,
    )

    args = ap.parse_args()

    required_files = [
        args.v1_csv,
        args.pad_raw,
        args.isic_meta,
        args.isic_ground_truth,
        args.mcr_lesion,
        args.mcr_image,
        args.mcr_subject,
        args.mcr_unified,
        args.mcr_derm,
        args.mcr_histo,
    ]

    missing = [
        str(path)
        for path in required_files
        if not path.exists()
    ]

    if missing:
        raise FileNotFoundError(
            "Required protocol/raw files are missing:\n"
            + "\n".join(missing)
        )

    args.output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    # Read all supplied raw sources.
    v1 = pd.read_csv(
        args.v1_csv,
        low_memory=False,
    )
    pad_raw = pd.read_csv(
        args.pad_raw,
        low_memory=False,
    )
    isic_meta = pd.read_csv(
        args.isic_meta,
        low_memory=False,
    )
    isic_gt = parse_isic_training_groundtruth(args.isic_ground_truth)

    mcr_lesion = pd.read_excel(
        args.mcr_lesion
    )
    mcr_image = pd.read_excel(
        args.mcr_image
    )
    mcr_subject = pd.read_excel(
        args.mcr_subject
    )
    mcr_unified = pd.read_excel(
        args.mcr_unified
    )
    mcr_derm = pd.read_excel(
        args.mcr_derm
    )
    mcr_histo = pd.read_excel(
        args.mcr_histo
    )

    # Basic raw-table integrity.
    if mcr_subject["subject_id"].duplicated().any():
        raise RuntimeError(
            "MCR subject.xlsx contains duplicate subject_id rows."
        )

    if mcr_unified["lesion_id"].duplicated().any():
        raise RuntimeError(
            "MCR unified_diagnosis.xlsx contains duplicate lesion_id rows."
        )

    # PASS 1 ---------------------------------------------------------------
    pass1 = pass1_raw_crosscheck(
        v1,
        pad_raw,
        isic_meta,
        isic_gt,
        mcr_lesion,
        mcr_image,
        mcr_subject,
        mcr_unified,
        mcr_derm,
        mcr_histo,
    )

    pass1.to_csv(
        args.output_dir
        / "raw_source_crosscheck_pass1.csv",
        index=False,
    )

    # CORRECTION -----------------------------------------------------------
    v2 = correct_protocol(v1)

    # PASS 2 ---------------------------------------------------------------
    pass2 = pass2_semantic_audit(
        v1,
        v2,
    )

    pass2.to_csv(
        args.output_dir
        / "semantic_protocol_audit_pass2.csv",
        index=False,
    )

    # Reports --------------------------------------------------------------
    availability = metadata_availability_report(
        v2
    )
    availability.to_csv(
        args.output_dir
        / "metadata_availability_by_dataset.csv",
        index=False,
    )

    pad_availability = pad_availability_by_class(
        v2
    )
    pad_availability.to_csv(
        args.output_dir
        / "pad_availability_by_class.csv",
        index=False,
    )

    mappings = label_mapping_audit(v2)
    mappings.to_csv(
        args.output_dir
        / "label_mapping_audit_v2_1.csv",
        index=False,
    )

    # Split hashes before/after.
    split_hash_df = pd.DataFrame(
        [
            {
                "protocol": "openworld_v1",
                "membership_sha256": membership_hash(v1),
                "group_membership_sha256": group_membership_hash(v1),
                "n_rows": len(v1),
            },
            {
                "protocol": "openworld_v2_1_final",
                "membership_sha256": membership_hash(v2),
                "group_membership_sha256": group_membership_hash(v2),
                "evaluation_membership_sha256": evaluation_membership_hash(v2),
                "n_rows": len(v2),
            },
        ]
    )

    split_hash_df.to_csv(
        args.output_dir
        / "split_membership_hashes.csv",
        index=False,
    )

    # Main output ----------------------------------------------------------
    output_csv = (
        args.output_dir
        / "all_preprocessed_splits_standardized_text_openworld_v2_1.csv"
    )

    expected_semantic_hash = (
        stable_csv_semantic_hash(v2)
    )

    v2.to_csv(
        output_csv,
        index=False,
    )

    save_split_files(
        v2,
        args.output_dir,
    )

    # PASS 3 — independent disk reload ------------------------------------
    pass3 = pass3_reload_check(
        output_csv,
        v1,
        expected_semantic_hash,
    )

    pass3.to_csv(
        args.output_dir
        / "reload_crosscheck_pass3.csv",
        index=False,
    )

    # Protocol manifest ----------------------------------------------------
    pad_source = v2[
        v2["dataset"].eq("PAD-UFES-20")
    ]

    pad_mel_counts = (
        pad_source[
            pad_source["label_harmonized"].eq("MEL")
        ]
        .groupby("split")
        .size()
        .to_dict()
    )

    manifest = {
        "protocol_name": "openworld_v2_1_final",
        "parent_protocol": "openworld_v1",
        "split_membership_changed": False,
        "membership_sha256": membership_hash(v2),
        "group_membership_sha256": group_membership_hash(v2),
        "evaluation_membership_sha256": evaluation_membership_hash(v2),
        "semantic_sha256": expected_semantic_hash,
        "final_frozen_protocol": True,
        "input_files": {
            "v1_csv": {
                "path": str(args.v1_csv),
                "sha256": file_sha256(args.v1_csv),
            },
            "pad_raw": {
                "path": str(args.pad_raw),
                "sha256": file_sha256(args.pad_raw),
            },
            "isic_meta": {
                "path": str(args.isic_meta),
                "sha256": file_sha256(args.isic_meta),
            },
            "isic_training_ground_truth": {
                "path": str(args.isic_ground_truth),
                "sha256": file_sha256(args.isic_ground_truth),
                "scope": "training pool only; locked target-test ground truth intentionally not loaded",
            },
            "mcr_lesion": {
                "path": str(args.mcr_lesion),
                "sha256": file_sha256(args.mcr_lesion),
            },
            "mcr_image": {
                "path": str(args.mcr_image),
                "sha256": file_sha256(args.mcr_image),
            },
            "mcr_subject": {
                "path": str(args.mcr_subject),
                "sha256": file_sha256(args.mcr_subject),
            },
            "mcr_unified": {
                "path": str(args.mcr_unified),
                "sha256": file_sha256(args.mcr_unified),
            },
            "mcr_derm": {
                "path": str(args.mcr_derm),
                "sha256": file_sha256(args.mcr_derm),
            },
            "mcr_histo": {
                "path": str(args.mcr_histo),
                "sha256": file_sha256(args.mcr_histo),
            },
        },
        "corrections": {
            "pad_forearm": "FOREARM -> upper_extremity",
            "age": "all datasets harmonized to decade bands",
            "diameter": (
                "common concept=lesion diameter; PAD uses max(horizontal,vertical); "
                "MCR uses reported scalar; ISIC unavailable"
            ),
            "isic_bkl": (
                "retained as SK for six-class compatibility; "
                "explicit approximate mapping flag; exact five-class sensitivity provided"
            ),
            "isic_vasc": (
                "preserved as VASC; unknown_family=vascular; "
                "no ANG renaming"
            ),
            "mcr_conflicts": (
                "L0247/L0248 retained for provenance but excluded "
                "from primary evaluation"
            ),
        },
        "text_protocol": {
            "primary": "text_shared_robust",
            "primary_description": (
                "restricted shared-schema text; reduces but does not eliminate missingness effects"
            ),
            "primary_fields": ROBUST_PRIMARY_FIELDS,
            "text_age_only": {"fields": AGE_ONLY_FIELDS, "role": "Table-2 ablation"},
            "text_location_only": {"fields": LOCATION_ONLY_FIELDS, "role": "Table-2 ablation"},
            "text_core": {
                "fields": DEMOGRAPHIC_FIELDS,
                "role": (
                    "secondary demographic sensitivity because PAD sex "
                    "availability is acquisition/biopsy-linked"
                ),
            },
            "text_full": {
                "fields": FULL_FIELDS,
                "role": "heterogeneous-schema stress test",
            },
            "text_missing_explicit": {
                "fields": FULL_FIELDS,
                "role": "informative-missingness stress test only",
            },
        },
        "irreducible_limitations": [
            "PAD-UFES biopsy/acquisition-linked metadata missingness",
            "ISIC BKL is broader than source seborrheic keratosis",
            "PAD clinical vs ISIC dermoscopic image-domain shift",
            "PAD source melanoma class is very small",
            "metadata unavailable in one dataset cannot be reconstructed without invention",
        ],
        "pad_source_melanoma_counts": pad_mel_counts,
        "three_pass_audit": {
            "pass1_all_true": bool(pass1["passed"].all()),
            "pass2_all_true": bool(pass2["passed"].all()),
            "pass3_all_true": bool(pass3["passed"].all()),
        },
    }

    # Hash every model-facing output before freezing the manifest.
    model_facing_outputs = {}
    for p in sorted(args.output_dir.glob("*.csv")):
        if p.exists():
            model_facing_outputs[p.name] = file_sha256(p)
    manifest["output_file_sha256"] = model_facing_outputs

    json_dump(
        manifest,
        args.output_dir
        / "protocol_manifest_v2_1.json",
    )

    # Only now mark validated.
    if not (
        pass1["passed"].all()
        and pass2["passed"].all()
        and pass3["passed"].all()
    ):
        raise RuntimeError(
            "Unexpected failed audit despite previous checks."
        )

    (
        args.output_dir
        / "PROTOCOL_V2_1_THREE_PASS_AUDIT_PASSED.flag"
    ).write_text(
        (
            "openworld_v2_1_final\n"
            "PASS1_RAW=TRUE\n"
            "PASS2_SEMANTIC=TRUE\n"
            "PASS3_RELOAD=TRUE\n"
            "ISIC_TRAIN_GT_AUDITED=TRUE\n"
            "TARGET_TEST_GT_LOADED=FALSE\n"
        ),
        encoding="utf-8",
    )

    print("\n" + "=" * 118)
    print("OPEN-WORLD V2.1 FINAL REVIEWER-HARDENED PROTOCOL CREATED")
    print("=" * 118)
    print(f"Rows: {len(v2)}")
    print(f"Main CSV: {output_csv}")
    print(
        "\nCritical fixes:"
        "\n  PAD FOREARM -> upper_extremity"
        "\n  age -> decade bands"
        "\n  diameter semantics -> documented per dataset"
        "\n  ISIC VASC preserved"
        "\n  BKL->SK marked approximate"
        "\n  MCR L0247/L0248 excluded from primary eval"
        "\n  primary shared-schema text -> age group + site; single-field ablations added"
    )
    print(
        "\nTHREE-PASS CROSS-CHECK: PASS-1 raw reconciliation = PASS; "
        "PASS-2 semantic invariants = PASS; "
        "PASS-3 reload verification = PASS"
    )
    print(
        "\nIMPORTANT: richer text columns remain stress-test ablations, "
        "not the reviewer-clean primary representation."
    )


if __name__ == "__main__":
    main()
