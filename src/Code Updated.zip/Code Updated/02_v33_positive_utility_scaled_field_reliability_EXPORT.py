#!/usr/bin/env python
from __future__ import annotations

"""
02-v3.3 — POSITIVE-UTILITY SCALED FIELD RELIABILITY + SELECTIVE METADATA ADAPTATION
============================================================================

Reviewer-driven revision after 02-v3.1
---------------------------------------
02-v3.1 established two useful facts but exposed three weaknesses:
  1) perturbation supervision helped Full heterogeneous metadata relative to
     architecture-matched learned attention;
  2) the marginal target field-shift prior generally hurt;
  3) the original reliability target exp(-harm) saturated near 1 and raw
     perturbation JS was numerically tiny.

This final development revision therefore tests a narrower mechanism:

A. Frozen PanDerm visual anchor
       logits_final = logits_image + g_i * Delta(z_image, h_metadata)

B. Cross-fitted SOURCE-CALIBRATED FIELD UTILITY
   For source sample i and available field j, a source-only teacher predicts
   with all fields and with field j removed. Define signed utility:

       u_ij = CE(y_i, p_without_j) - CE(y_i, p_full)

   Positive u_ij means including field j helped; negative means it hurt.
   A source-only robust scale s_u converts this into a non-saturating target:

       r*_ij = sigmoid( clip(u_ij / s_u, -6, 6) )

   Here r*=0.5 has a precise meaning: NEUTRAL source utility. Therefore v3.3
   does NOT use rho directly as a metadata weight. At inference/adaptation:

       q_ij = relu(2*rho_ij - 1)

   q_ij is the POSITIVE-UTILITY SCALED RELIABILITY:
       rho <= 0.5  -> q = 0   (harmful/neutral: do not alter the image anchor)
       rho = 0.75  -> q = 0.5
       rho = 1.0   -> q = 1.0

   This transformation is parameter-free and preserves the source-only
   interpretation of 0.5 as the neutral point.

   Targets are generated OUT-OF-FOLD using 5-fold stratified cross-fitting.

C. LABEL-FREE perturbation sensitivity as a calibrated input
       d_ij = JS(p_full, p_without_j)

   d_ij is robust-standardized per field using SOURCE OOF statistics before
   entering the reliability network. Target labels are never used.

D. Source-support mask
   A field never observed in source training cannot have source-validated
   utility. Such fields receive zero effective weight at deployment/adaptation.

E. Field-wise residual weighting
       q_ij = relu(2*rho_ij - 1)
       w_ij = availability_ij * source_support_j * q_ij
       h_M  = weighted mean of field embeddings
       g_i  = mean positive-utility reliability across available source-supported fields

   The visual anchor remains the default when clinical fields are unreliable.

F. SELECTIVE METADATA-ONLY domain adaptation
   Script 00 showed indiscriminate visual alignment can harm strong PanDerm.
   Therefore CDAN in v3.2 aligns only the reliability-weighted METADATA summary.
   Class probabilities and reliability weights are detached in the domain path,
   so adversarial gradients do not update the image projection or reliability gate.
   Domain losses are sample-weighted by the detached residual gate.

G. Shared-PCGrad
   PCGrad acts only where task and domain objectives actually share parameters:
   the metadata field projection. It is a conflict-control mechanism, not a DA
   objective by itself.

Primary ablations
-----------------
uniform_supported
    Source-supported available fields weighted uniformly; no reliability learning.

learned_attention
    Same gate architecture with NO field-utility supervision and ordinary sigmoid
    attention weights. Reviewer control for generic learned attention.

field_utility_rawrho
    Cross-fitted signed-utility supervision, but rho itself is used as the weight.
    This isolates whether utility supervision alone is sufficient.

field_utility_scaled
    PROPOSED: cross-fitted signed-utility supervision + parameter-free
    positive-utility scaling q=relu(2*rho-1). No target adaptation.

field_utility_scaled_meta_cdan
    Proposed scaled reliability + reliability-weighted metadata-only CDAN.

field_utility_scaled_pcgrad_meta_cdan
    Same + Shared-PCGrad on metadata field-projection gradients.

Protocol safeguards
-------------------
* OpenWorld V2.1 + MIDAS V3.1 only.
* Target adaptation CSVs are physically label-stripped.
* No target label enters optimizer, reliability, calibration, checkpoint selection,
  threshold selection, or hyperparameter selection.
* Target validation labels are post-hoc reporting only.
* No locked target-test labels are read.
* Final-model RNG is reset AFTER all cache/teacher work, so cache hit/miss state
  cannot change initialization or DataLoader shuffle.
"""

import argparse
import contextlib
import gc
import importlib
import importlib.util
import io
import json
import math
import os
import random
import re
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from PIL import Image
from scipy.spatial.distance import jensenshannon
from sklearn.model_selection import StratifiedKFold
from torch.autograd import Function
from torch.utils.data import DataLoader, Dataset
from tqdm.auto import tqdm
from transformers import AutoModel, AutoTokenizer


DEFAULT_ROOT = Path(r"C:\Users\Nebula PC\Downloads\Deep Learning")

TARGETS = {
    "isic": ("ISIC 2019", "isic_target_adapt_ow_v2_1_model_unlabeled.csv"),
    "mcr": ("MCR-SL", "mcr_target_adapt_ow_v2_1_model_unlabeled.csv"),
}

SEEDS = [42, 123, 2026]

METHODS = [
    "uniform_supported",
    "learned_attention",
    "field_utility_rawrho",
    "field_utility_scaled",
    "field_utility_scaled_meta_cdan",
    "field_utility_scaled_pcgrad_meta_cdan",
]

FIELD_LABELS = [
    ("std_age", "age group"),
    ("std_sex", "sex"),
    ("std_location", "anatomical site"),
    ("std_diameter", "lesion diameter"),
    ("std_fitzpatrick", "Fitzpatrick type"),
    ("std_itch", "itching"),
    ("std_grew", "growth"),
    ("std_hurt", "pain"),
    ("std_changed", "change"),
    ("std_bleed", "bleeding"),
    ("std_elevation", "elevation"),
    ("std_personal_skin_cancer_history", "personal skin cancer history"),
    ("std_family_skin_cancer_history", "family skin cancer history"),
    ("std_general_cancer_history", "general cancer history"),
    ("std_smoking", "smoking"),
    ("std_alcohol", "alcohol"),
    ("std_pesticide_exposure", "pesticide exposure"),
    ("std_sunbed_use", "sunbed use"),
    ("std_organ_transplant", "organ transplant"),
    ("std_immunosuppression", "immunosuppression"),
    ("std_natural_hair_color", "natural hair color"),
    ("std_skin_reaction_to_sun", "skin reaction to sun"),
    ("std_moles_body_18", "moles on body at age 18"),
    ("std_moles_bigger_5mm", "moles larger than 5 mm"),
    ("std_moles_bigger_20cm", "moles field bigger 20 cm"),
    ("std_moles_body", "moles on body"),
    ("std_sunburn_number_group", "sunburn count group"),
]
FIELD_TO_LABEL = dict(FIELD_LABELS)

# Corrected to match the F0/01 Core definition: age + sex + location.
CORE3 = ["std_age", "std_sex", "std_location"]
FULL_FIELDS = [x[0] for x in FIELD_LABELS]
FIELD_SETS = {"core3": CORE3, "full": FULL_FIELDS}

# Final-head training.
BATCH = 128
TRAIN_BATCH = 128
EPOCHS = 40
EARLY_STOP = 6
LR = 2e-4
WD = 1e-3
DOMAIN_W = 0.005          # frozen from Script 00 scale
GRL_MAX = 1.0
HIDDEN = 128
GRAD_CLIP = 3.0

# Reuse source-anchor regularization established in Script 01.
LAMBDA_META = 0.10
LAMBDA_SAFETY = 0.50
LAMBDA_RELIABILITY = 1.0  # predeclared; never target-val tuned

# Source perturbation teacher.
CROSSFIT_FOLDS = 5
TEACHER_FOLD_EPOCHS = 20
TEACHER_MAX_EPOCHS = 35
TEACHER_EARLY_STOP = 6
TEACHER_LR = 3e-4
TEACHER_WD = 1e-3

TEXT_BATCH = 256
FIELD_TEXT_MAX_LEN = 48
CACHE_NUM_WORKERS = 4

OUTDIR_NAME = "results_02_positive_utility_scaled_reliability_v33"
CACHE_SOURCE_DIR = "results_02_field_reliability_selective_adaptation_v31"


# ---------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------

def jdump(obj, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    def cv(x):
        if isinstance(x, Path):
            return str(x)
        if isinstance(x, (np.integer,)):
            return int(x)
        if isinstance(x, (np.floating,)):
            v = float(x)
            return None if not np.isfinite(v) else v
        if isinstance(x, np.ndarray):
            return x.tolist()
        if isinstance(x, dict):
            return {str(k): cv(v) for k, v in x.items()}
        if isinstance(x, (list, tuple)):
            return [cv(v) for v in x]
        return x

    path.write_text(json.dumps(cv(obj), indent=2), encoding="utf-8")


def seed_all(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def cleanup():
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        try:
            torch.cuda.ipc_collect()
        except Exception:
            pass


def discover_f0(root):
    p = root / "run_f0_foundation_representation_sanity.py"
    if p.exists():
        return p
    hits = sorted(root.glob("run_f0_foundation_representation_sanity*.py"))
    if not hits:
        raise FileNotFoundError("F0-v3 script not found")
    return hits[0]


def import_f0(root):
    p = discover_f0(root).resolve()
    if str(p.parent) not in sys.path:
        sys.path.insert(0, str(p.parent))
    if p.stem.isidentifier():
        importlib.invalidate_caches()
        m = importlib.import_module(p.stem)
    else:
        spec = importlib.util.spec_from_file_location("f0_v3_runtime", p)
        m = importlib.util.module_from_spec(spec)
        sys.modules["f0_v3_runtime"] = m
        spec.loader.exec_module(m)
        if os.name == "nt":
            m.RUNTIME_NUM_WORKERS = 0
    return m, p


def image_ckpt(root, seed):
    return (
        root
        / "results_f0_backbone_metadata_benchmark"
        / "development"
        / "children"
        / "image__panderm_base"
        / f"seed_{seed}"
        / "best.pt"
    )


def clean(x):
    if pd.isna(x):
        return "unknown"
    s = str(x).strip().lower()
    return "unknown" if s in {"", "nan", "none", "null", "unknown", "n/a", "na"} else s


def field_text(row, field):
    v = clean(row.get(field, "unknown"))
    if field == "std_age" and v != "unknown":
        v = f"{v} years"
    return f"Patient metadata: {FIELD_TO_LABEL[field]}: {v}."


def availability(frame, fields):
    out = np.zeros((len(frame), len(fields)), dtype=np.float32)
    for j, f in enumerate(fields):
        if f in frame.columns:
            out[:, j] = (
                frame[f].map(clean) != "unknown"
            ).astype(np.float32).to_numpy()
    return out


def categorical_jsd(source: pd.Series, target: pd.Series) -> float:
    s = source.map(clean)
    t = target.map(clean)
    cats = sorted(set(s.unique()).union(set(t.unique())))
    ps = s.value_counts(normalize=True).reindex(cats, fill_value=0).to_numpy(dtype=float)
    pt = t.value_counts(normalize=True).reindex(cats, fill_value=0).to_numpy(dtype=float)
    return float(jensenshannon(ps, pt, base=2.0) ** 2)


def compute_field_shift_prior(source, target, fields):
    """
    Parameter-free marginal field-shift prior in [0,1].

    This is intentionally NOT named transferability: marginal shift can reflect
    class-prior/composition differences and therefore is only a conservative
    domain-stability prior.
    """
    rows, prior = [], []
    for f in fields:
        ss = source[f] if f in source.columns else pd.Series(["unknown"] * len(source))
        tt = target[f] if f in target.columns else pd.Series(["unknown"] * len(target))

        js = float(np.clip(categorical_jsd(ss, tt), 0.0, 1.0))
        avs = float((ss.map(clean) != "unknown").mean())
        avt = float((tt.map(clean) != "unknown").mean())
        gap = float(np.clip(abs(avs - avt), 0.0, 1.0))

        score = float(np.clip((1.0 - js) * (1.0 - gap), 0.0, 1.0))
        rows.append(
            {
                "field": f,
                "jsd_marginal": js,
                "source_availability": avs,
                "target_availability": avt,
                "availability_gap": gap,
                "interpretation": "marginal_domain_stability_prior_not_transferability",
            }
        )
        prior.append(score)

    return np.asarray(prior, dtype=np.float32), pd.DataFrame(rows)


def load_target_adapt(f0, t2, root, target_key):
    dataset, fn = TARGETS[target_key]
    p = root / "preprocessed_outputs_openworld_v2_1_final" / fn
    if not p.exists():
        raise FileNotFoundError(p)

    q = pd.read_csv(p, low_memory=False)
    forbidden = [
        c
        for c in q.columns
        if any(
            z in c.lower()
            for z in (
                "label",
                "diagnos",
                "known_unknown",
                "unknown_type",
                "unknown_family",
                "ground_truth",
                "pathology",
                "histopath",
                "malignancy",
                "ontology_",
            )
        )
    ]
    if forbidden:
        raise RuntimeError(
            f"Label-stripped target file contains forbidden columns: {forbidden}"
        )

    (q,) = f0._resolve_frame_paths(t2, [(dataset, q)])
    return q.reset_index(drop=True), p


# ---------------------------------------------------------------------
# Frozen encoders and feature caching
# ---------------------------------------------------------------------

class ImageCacheDataset(Dataset):
    """Top-level Dataset so Windows DataLoader workers can pickle it safely."""
    def __init__(self, frame, transform):
        self.paths = frame["image_path"].astype(str).tolist()
        self.transform = transform

    def __len__(self):
        return len(self.paths)

    def __getitem__(self, i):
        with Image.open(self.paths[i]) as im:
            x = self.transform(im.convert("RGB"))
        return x


@torch.no_grad()
def encode_images(anchor, eval_tf, frame, device, batch=64, desc="images"):
    """
    Scientifically identical frozen PanDerm extraction, but image decode/transform
    is parallelized across CPU workers. This removes the serial PIL bottleneck.
    """
    anchor.eval()
    ds = ImageCacheDataset(frame, eval_tf)

    kwargs = dict(
        batch_size=batch,
        shuffle=False,
        num_workers=CACHE_NUM_WORKERS,
        pin_memory=torch.cuda.is_available(),
        drop_last=False,
    )
    if CACHE_NUM_WORKERS > 0:
        kwargs["persistent_workers"] = True
        kwargs["prefetch_factor"] = 2

    dl = DataLoader(ds, **kwargs)

    feats, logits = [], []
    for imgs in tqdm(dl, desc=f"cache {desc}: PanDerm", leave=False, dynamic_ncols=True):
        imgs = imgs.to(device, non_blocking=torch.cuda.is_available())
        z = anchor.encode(imgs)
        l = anchor.classifier(z)
        feats.append(z.float().cpu().numpy())
        logits.append(l.float().cpu().numpy())

    return (
        np.concatenate(feats).astype(np.float16),
        np.concatenate(logits).astype(np.float16),
    )

@torch.no_grad()
def encode_fields(text_encoder, tokenizer, frame, fields, device):
    """
    Encode UNIQUE field prompts only, then reconstruct row x field embeddings.
    This is mathematically identical to encoding every repeated categorical prompt
    and is substantially faster for structured clinical metadata.
    """
    text_encoder.eval()
    texts = [field_text(r, f) for _, r in frame.iterrows() for f in fields]
    unique_texts, inverse = np.unique(np.asarray(texts, dtype=object), return_inverse=True)

    unique_out = []
    starts = list(range(0, len(unique_texts), TEXT_BATCH))
    for st in tqdm(
        starts,
        desc=f"cache BioClinicalBERT unique prompts ({len(unique_texts)})",
        leave=False,
        dynamic_ncols=True,
    ):
        batch_text = unique_texts[st : st + TEXT_BATCH].tolist()
        enc = tokenizer(
            batch_text,
            padding=True,
            truncation=True,
            max_length=FIELD_TEXT_MAX_LEN,
            return_tensors="pt",
        )
        ids = enc["input_ids"].to(device)
        mask = enc["attention_mask"].to(device)
        o = text_encoder(input_ids=ids, attention_mask=mask)
        z = getattr(o, "pooler_output", None)
        if z is None:
            z = o.last_hidden_state[:, 0]
        unique_out.append(z.float().cpu().numpy())

    table = np.concatenate(unique_out)
    x = table[inverse].reshape(len(frame), len(fields), -1)
    return x.astype(np.float16)


def load_frozen_encoders(f0, root, frames, t2, v8, seed, device):
    # Strong frozen image anchor.
    cond = f0.condition_map()["image__panderm_base"]
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        anchor, opt, train_tf, eval_tf, tok, bundle_i, audit = f0.build_condition_model(
            root, t2, v8, cond, seed, device, frames.source_train
        )
    del opt

    ip = image_ckpt(root, seed)
    if not ip.exists():
        raise FileNotFoundError(ip)
    payload = torch.load(ip, map_location=device)
    anchor.load_state_dict(payload.get("state_dict", payload), strict=True)
    anchor.eval()
    for p in anchor.parameters():
        p.requires_grad_(False)

    # IMPORTANT: pretrained BioClinicalBERT, NOT source-fine-tuned Full metadata.
    tokenizer = AutoTokenizer.from_pretrained(f0.BIOCLINICAL_MODEL)
    text_encoder = AutoModel.from_pretrained(f0.BIOCLINICAL_MODEL).to(device)
    text_encoder.eval()
    for p in text_encoder.parameters():
        p.requires_grad_(False)

    return anchor, eval_tf, text_encoder, tokenizer, bundle_i, ip



def quarantine_corrupt_cache(path, error):
    """Move a broken derived NPZ aside so export can regenerate it safely."""
    path = Path(path)
    if not path.exists():
        return
    backup = Path(str(path) + ".corrupt")
    suffix = 1
    while backup.exists():
        backup = Path(str(path) + f".corrupt{suffix}")
        suffix += 1
    os.replace(path, backup)
    print(f"[02-v33 cache] corrupt cache moved to {backup}: {type(error).__name__}: {error}")


def shared_image_cache_file(root, seed, name):
    """
    PanDerm image features do not depend on metadata field_set.
    Reuse them across core3/full instead of recomputing.
    """
    return (
        root
        / CACHE_SOURCE_DIR
        / "feature_cache"
        / f"seed_{seed}"
        / "_shared_image"
        / f"{name}.npz"
    )


def get_shared_image_cache(root, seed, name, frame, anchor, eval_tf, device):
    p = shared_image_cache_file(root, seed, name)
    if p.exists():
        try:
            with np.load(p, allow_pickle=False) as z:
                return z["image"], z["image_logits"]
        except Exception as exc:
            quarantine_corrupt_cache(p, exc)

    p.parent.mkdir(parents=True, exist_ok=True)
    print(f"[02-v33 cache] extracting shared image features: {name} (n={len(frame)})")
    img, img_logits = encode_images(
        anchor, eval_tf, frame, device, batch=64, desc=f"{name} n={len(frame)}"
    )
    np.savez_compressed(p, image=img, image_logits=img_logits)
    return img, img_logits

def cache_file(root, seed, field_set, name):
    return (
        root
        / CACHE_SOURCE_DIR
        / "feature_cache"
        / f"seed_{seed}"
        / field_set
        / f"{name}.npz"
    )


def base_cache(
    root,
    seed,
    field_set,
    name,
    frame,
    encoders,
    fields,
    device,
    return_labels,
):
    p = cache_file(root, seed, field_set, name)
    if p.exists():
        try:
            with np.load(p, allow_pickle=False) as z:
                return {k: z[k] for k in z.files}
        except Exception as exc:
            quarantine_corrupt_cache(p, exc)

    p.parent.mkdir(parents=True, exist_ok=True)
    anchor, eval_tf, text_encoder, tokenizer, *_ = encoders

    img, img_logits = get_shared_image_cache(
        root, seed, name, frame, anchor, eval_tf, device
    )
    print(
        f"[02-v33 cache] encoding fields: {name}/{field_set} "
        f"(n={len(frame)}, fields={len(fields)})"
    )
    fld = encode_fields(text_encoder, tokenizer, frame, fields, device)
    av = availability(frame, fields).astype(np.float16)

    data = {
        "image": img,
        "image_logits": img_logits,
        "fields": fld,
        "availability": av,
    }
    if return_labels:
        data["label"] = frame["label_id"].to_numpy(dtype=np.int64)

    np.savez_compressed(p, **data)
    return data


def save_cache(root, seed, field_set, name, data):
    p = cache_file(root, seed, field_set, name)
    p.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(p, **data)


# ---------------------------------------------------------------------
# Source perturbation teacher
# ---------------------------------------------------------------------

class TeacherModel(nn.Module):
    def __init__(self, image_dim, field_dim, n_classes):
        super().__init__()
        self.image_proj = nn.Sequential(
            nn.Linear(image_dim, HIDDEN), nn.GELU(), nn.LayerNorm(HIDDEN)
        )
        self.field_proj = nn.Sequential(
            nn.Linear(field_dim, HIDDEN), nn.GELU(), nn.LayerNorm(HIDDEN)
        )
        self.classifier = nn.Sequential(
            nn.Linear(2 * HIDDEN, 2 * HIDDEN),
            nn.GELU(),
            nn.Dropout(0.15),
            nn.Linear(2 * HIDDEN, n_classes),
        )

    def project(self, image, fields):
        zi = self.image_proj(image)
        hf = self.field_proj(fields)
        return zi, hf

    @staticmethod
    def pool_fields(hf, mask):
        denom = mask.sum(1, keepdim=True).clamp_min(1.0)
        return (hf * mask[:, :, None]).sum(1) / denom

    def logits_from_mask(self, zi, hf, mask):
        hm = self.pool_fields(hf, mask)
        return self.classifier(torch.cat([zi, hm], dim=1))

    def forward(self, image, fields, availability):
        zi, hf = self.project(image, fields)
        return self.logits_from_mask(zi, hf, availability)


class ArrayDataset(Dataset):
    def __init__(self, cache, indices=None):
        self.c = cache
        self.indices = (
            np.arange(len(cache["image"]), dtype=np.int64)
            if indices is None
            else np.asarray(indices, dtype=np.int64)
        )

    def __len__(self):
        return len(self.indices)

    def __getitem__(self, k):
        i = int(self.indices[k])
        out = {
            "image": torch.from_numpy(self.c["image"][i].astype(np.float32)),
            "image_logits": torch.from_numpy(
                self.c["image_logits"][i].astype(np.float32)
            ),
            "fields": torch.from_numpy(self.c["fields"][i].astype(np.float32)),
            "availability": torch.from_numpy(
                self.c["availability"][i].astype(np.float32)
            ),
            "index": torch.tensor(i, dtype=torch.long),
        }

        if "label" in self.c:
            out["label"] = torch.tensor(int(self.c["label"][i]), dtype=torch.long)
        if "perturb_js_z" in self.c:
            out["perturb_js_z"] = torch.from_numpy(
                self.c["perturb_js_z"][i].astype(np.float32)
            )
        if "reliability_target" in self.c:
            out["reliability_target"] = torch.from_numpy(
                self.c["reliability_target"][i].astype(np.float32)
            )
        if "field_utility_raw" in self.c:
            out["field_utility_raw"] = torch.from_numpy(
                self.c["field_utility_raw"][i].astype(np.float32)
            )
        if "positive_utility_target" in self.c:
            out["positive_utility_target"] = torch.from_numpy(
                self.c["positive_utility_target"][i].astype(np.float32)
            )
        return out


def make_loader(cache, batch, shuffle, indices=None):
    return DataLoader(
        ArrayDataset(cache, indices),
        batch_size=batch,
        shuffle=shuffle,
        num_workers=0,
        drop_last=False,
    )


def move(batch, device):
    return {
        k: (v.to(device, non_blocking=torch.cuda.is_available()) if torch.is_tensor(v) else v)
        for k, v in batch.items()
    }


def teacher_class_weights(labels, nclasses, device):
    counts = np.bincount(np.asarray(labels, dtype=int), minlength=nclasses).astype(float)
    counts = np.maximum(counts, 1.0)
    # Stable inverse-frequency weights normalized to mean 1.
    w = counts.sum() / (len(counts) * counts)
    w = w / w.mean()
    return torch.as_tensor(w, dtype=torch.float32, device=device)


@torch.no_grad()
def teacher_predict(model, cache, device, indices=None):
    model.eval()
    probs, ys = [], []
    for b in make_loader(cache, BATCH, False, indices):
        b = move(b, device)
        l = model(b["image"], b["fields"], b["availability"])
        probs.append(F.softmax(l, dim=1).cpu().numpy())
        if "label" in b:
            ys.append(b["label"].cpu().numpy())
    return np.concatenate(probs), (np.concatenate(ys) if ys else None)


def fit_teacher(
    cache,
    nclasses,
    device,
    seed,
    train_indices=None,
    val_cache=None,
    fixed_epochs=None,
):
    seed_all(seed)
    idim = cache["image"].shape[1]
    fdim = cache["fields"].shape[2]
    model = TeacherModel(idim, fdim, nclasses).to(device)

    labels = cache["label"] if train_indices is None else cache["label"][train_indices]
    ce = nn.CrossEntropyLoss(weight=teacher_class_weights(labels, nclasses, device))
    opt = torch.optim.AdamW(
        model.parameters(), lr=TEACHER_LR, weight_decay=TEACHER_WD
    )

    max_epochs = fixed_epochs if fixed_epochs is not None else TEACHER_MAX_EPOCHS
    best = -1.0
    patience = 0
    best_state = None

    for ep in range(1, max_epochs + 1):
        model.train()
        for b in make_loader(cache, TRAIN_BATCH, True, train_indices):
            b = move(b, device)
            opt.zero_grad(set_to_none=True)
            l = model(b["image"], b["fields"], b["availability"])
            loss = ce(l, b["label"])
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), GRAD_CLIP)
            opt.step()

        if fixed_epochs is not None:
            continue

        if val_cache is None:
            continue

        p, y = teacher_predict(model, val_cache, device)
        # local Macro-F1 without importing additional sklearn metric:
        pred = p.argmax(1)
        f1s = []
        for c in range(nclasses):
            tp = np.sum((pred == c) & (y == c))
            fp = np.sum((pred == c) & (y != c))
            fn = np.sum((pred != c) & (y == c))
            den = 2 * tp + fp + fn
            f1s.append(0.0 if den == 0 else 2 * tp / den)
        score = float(np.mean(f1s))

        if score > best + 1e-12:
            best = score
            patience = 0
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        else:
            patience += 1
            if patience >= TEACHER_EARLY_STOP:
                break

    if best_state is not None:
        model.load_state_dict(best_state, strict=True)
    return model


def js_torch_from_logits(a, b):
    pa = F.softmax(a, dim=1).clamp_min(1e-8)
    pb = F.softmax(b, dim=1).clamp_min(1e-8)
    m = 0.5 * (pa + pb)
    js = 0.5 * (
        (pa * (pa.log() - m.log())).sum(1)
        + (pb * (pb.log() - m.log())).sum(1)
    )
    return js / math.log(2.0)


@torch.no_grad()
def perturbation_signals(model, cache, device, indices=None, use_labels=True):
    """
    Always returns raw label-free leave-one-field-out JS.
    On SOURCE only, also returns signed utility:
        utility = CE_without_field - CE_full
    Positive = field helped; negative = field harmed.
    """
    model.eval()
    N = len(cache["image"]) if indices is None else len(indices)
    FIELDS_N = cache["fields"].shape[1]

    js_out = np.zeros((N, FIELDS_N), dtype=np.float32)
    util_out = np.zeros((N, FIELDS_N), dtype=np.float32)
    global_positions = []
    cursor = 0

    for b in make_loader(cache, BATCH, False, indices):
        raw_idx = b["index"].numpy()
        global_positions.extend(raw_idx.tolist())
        b = move(b, device)

        zi, hf = model.project(b["image"], b["fields"])
        av = b["availability"]
        full = model.logits_from_mask(zi, hf, av)

        if use_labels and "label" in b:
            y = b["label"]
            full_ce = F.cross_entropy(full, y, reduction="none")

        bs = len(av)
        local_js = torch.zeros(bs, FIELDS_N, device=device)
        local_util = torch.zeros(bs, FIELDS_N, device=device)

        for j in range(FIELDS_N):
            mask = av.clone()
            mask[:, j] = 0.0
            loo = model.logits_from_mask(zi, hf, mask)
            local_js[:, j] = js_torch_from_logits(full, loo) * av[:, j]

            if use_labels and "label" in b:
                loo_ce = F.cross_entropy(loo, y, reduction="none")
                local_util[:, j] = (loo_ce - full_ce) * av[:, j]

        sl = slice(cursor, cursor + bs)
        js_out[sl] = local_js.cpu().numpy()
        if use_labels and "label" in b:
            util_out[sl] = local_util.cpu().numpy()
        cursor += bs

    return {
        "indices": np.asarray(global_positions, dtype=np.int64),
        "perturb_js_raw": js_out,
        "field_utility_raw": util_out if use_labels else None,
    }


def _robust_scale(x, floor):
    x = np.asarray(x, dtype=np.float64)
    if x.size == 0:
        return float(floor)
    med = float(np.median(x))
    mad = float(np.median(np.abs(x - med)))
    std = float(np.std(x))
    return float(max(1.4826 * mad, std, floor))


def calibrate_source_oof(raw_js, raw_utility, availability):
    """Source-only calibration. No target statistics or target labels."""
    av = np.asarray(availability, dtype=np.float32)
    support = (av.sum(0) > 0).astype(np.float32)

    util_vals = raw_utility[av > 0.5]
    utility_scale = _robust_scale(util_vals, 1e-4)
    z_u = np.clip(raw_utility / utility_scale, -6.0, 6.0)
    rel = (1.0 / (1.0 + np.exp(-z_u))).astype(np.float32) * av

    FIELDS_N = av.shape[1]
    js_median = np.zeros(FIELDS_N, dtype=np.float32)
    js_scale = np.ones(FIELDS_N, dtype=np.float32)
    js_z = np.zeros_like(raw_js, dtype=np.float32)

    for j in range(FIELDS_N):
        m = av[:, j] > 0.5
        if not m.any():
            js_median[j] = 0.0
            js_scale[j] = 1.0
            continue
        vals = raw_js[m, j]
        med = float(np.median(vals))
        scale = _robust_scale(vals, 1e-7)
        js_median[j] = med
        js_scale[j] = scale
        js_z[m, j] = np.clip((vals - med) / scale, -6.0, 6.0)

    return {
        "perturb_js_raw": raw_js.astype(np.float32),
        "perturb_js_z": js_z.astype(np.float32),
        "field_utility_raw": raw_utility.astype(np.float32),
        "reliability_target": rel,
        "positive_utility_target": np.maximum(2.0 * rel - 1.0, 0.0).astype(np.float32),
        "source_support": support,
        "js_median": js_median,
        "js_scale": js_scale,
        "utility_scale": np.asarray([utility_scale], dtype=np.float32),
    }


def apply_js_calibration(raw_js, availability, calibration):
    av = np.asarray(availability, dtype=np.float32)
    med = np.asarray(calibration["js_median"], dtype=np.float32)
    scale = np.asarray(calibration["js_scale"], dtype=np.float32)
    z = (np.asarray(raw_js, dtype=np.float32) - med[None, :]) / np.maximum(scale[None, :], 1e-12)
    z = np.clip(z, -6.0, 6.0) * av
    return z.astype(np.float32)


def teacher_dir(root, seed, field_set):
    return root / OUTDIR_NAME / "teacher" / f"seed_{seed}" / field_set


def ensure_teacher_and_source_signals(
    root, seed, field_set, source_train, source_val, nclasses, device
):
    """
    Generate OOF source utility + perturbation signals and one final source teacher.
    v3.3 deliberately does NOT reuse the saturated v3.1 reliability targets.
    """
    tdir = teacher_dir(root, seed, field_set)
    tdir.mkdir(parents=True, exist_ok=True)
    signal_path = tdir / "source_train_crossfit_calibrated_signals_v33.npz"
    teacher_path = tdir / "final_teacher_v33.pt"

    if signal_path.exists():
        try:
            with np.load(signal_path, allow_pickle=False) as z:
                signals = {k: z[k] for k in z.files}
        except Exception as exc:
            quarantine_corrupt_cache(signal_path, exc)
    if not signal_path.exists():
        y = source_train["label"].astype(int)
        skf = StratifiedKFold(n_splits=CROSSFIT_FOLDS, shuffle=True, random_state=seed)
        N = len(y)
        FN = source_train["fields"].shape[1]
        oof_js = np.zeros((N, FN), dtype=np.float32)
        oof_util = np.zeros((N, FN), dtype=np.float32)
        fold_id = np.full(N, -1, dtype=np.int16)

        fold_splits = list(skf.split(np.zeros(N), y))
        for fold, (tr_idx, ho_idx) in enumerate(
            tqdm(fold_splits, desc=f"02-v33 source cross-fit {field_set}/s{seed}", unit="fold", dynamic_ncols=True)
        ):
            teacher = fit_teacher(
                source_train, nclasses, device, seed + 1000 + fold,
                train_indices=tr_idx, fixed_epochs=TEACHER_FOLD_EPOCHS
            )
            sig = perturbation_signals(teacher, source_train, device, indices=ho_idx, use_labels=True)
            idx = sig["indices"]
            oof_js[idx] = sig["perturb_js_raw"]
            oof_util[idx] = sig["field_utility_raw"]
            fold_id[idx] = fold
            del teacher
            cleanup()

        if np.any(fold_id < 0):
            raise RuntimeError("OOF source signals incomplete")

        signals = calibrate_source_oof(oof_js, oof_util, source_train["availability"])
        signals["fold_id"] = fold_id
        np.savez_compressed(signal_path, **signals)

    if teacher_path.exists():
        idim = source_train["image"].shape[1]
        fdim = source_train["fields"].shape[2]
        teacher = TeacherModel(idim, fdim, nclasses).to(device)
        payload = torch.load(teacher_path, map_location=device, weights_only=True)
        teacher.load_state_dict(payload["state_dict"], strict=True)
    else:
        teacher = fit_teacher(
            source_train, nclasses, device, seed + 9999, train_indices=None,
            val_cache=source_val, fixed_epochs=None
        )
        torch.save({
            "state_dict": teacher.state_dict(),
            "seed": seed,
            "field_set": field_set,
            "protocol": "source_only_final_teacher_v32",
        }, teacher_path)

    teacher.eval()
    return teacher, signals, teacher_path, signal_path


def ensure_cache_signals(
    root, seed, field_set, name, cache, teacher, device, calibration, source_oof=False
):
    data = dict(cache)

    if source_oof:
        for k in [
            "perturb_js_raw", "perturb_js_z", "field_utility_raw",
            "reliability_target", "positive_utility_target", "fold_id"
        ]:
            if k in calibration:
                data[k] = calibration[k].astype(np.float16 if k != "fold_id" else np.int16)
    else:
        # Non-source-train signal construction is strictly label-free.
        sig = perturbation_signals(teacher, cache, device, indices=None, use_labels=False)
        data["perturb_js_raw"] = sig["perturb_js_raw"].astype(np.float16)
        data["perturb_js_z"] = apply_js_calibration(
            sig["perturb_js_raw"], cache["availability"], calibration
        ).astype(np.float16)

    save_cache(root, seed, field_set, name, data)
    return data


# ---------------------------------------------------------------------
# Final field-reliability model
# ---------------------------------------------------------------------

class GRL(Function):
    @staticmethod
    def forward(ctx, x, lambd):
        ctx.lambd = float(lambd)
        return x.view_as(x)

    @staticmethod
    def backward(ctx, g):
        return -ctx.lambd * g, None


class FieldReliabilityModel(nn.Module):
    def __init__(self, image_dim, field_dim, n_fields, n_classes, method, source_support):
        super().__init__()
        self.method = method
        self.n_fields = n_fields

        self.image_proj = nn.Sequential(
            nn.Linear(image_dim, HIDDEN), nn.GELU(), nn.LayerNorm(HIDDEN)
        )
        self.field_proj = nn.Sequential(
            nn.Linear(field_dim, HIDDEN), nn.GELU(), nn.LayerNorm(HIDDEN)
        )
        self.reliability_gate = nn.Sequential(
            nn.Linear(2 * HIDDEN + 2, 64), nn.GELU(), nn.Linear(64, 1)
        )
        self.delta_head = nn.Sequential(
            nn.Linear(2 * HIDDEN, 2 * HIDDEN), nn.GELU(), nn.Dropout(0.15),
            nn.Linear(2 * HIDDEN, n_classes)
        )
        self.meta_head = nn.Linear(HIDDEN, n_classes)
        self.domain_classifier = nn.Sequential(
            nn.Linear(HIDDEN * n_classes, 256), nn.ReLU(), nn.Dropout(0.15), nn.Linear(256, 2)
        )
        self.register_buffer(
            "source_support", torch.as_tensor(source_support, dtype=torch.float32).view(1, n_fields)
        )

    @property
    def uses_reliability_supervision(self):
        return self.method in {
            "field_utility_rawrho",
            "field_utility_scaled",
            "field_utility_scaled_meta_cdan",
            "field_utility_scaled_pcgrad_meta_cdan",
        }

    @property
    def uses_positive_utility_scaling(self):
        return self.method in {
            "field_utility_scaled",
            "field_utility_scaled_meta_cdan",
            "field_utility_scaled_pcgrad_meta_cdan",
        }

    def shared_parameters(self):
        # Domain gradients are intentionally restricted to metadata field projection.
        return list(self.field_proj.parameters())

    def task_only_parameters(self):
        modules = [self.image_proj, self.reliability_gate, self.delta_head, self.meta_head]
        return [p for m in modules for p in m.parameters()]

    def domain_head_parameters(self):
        return list(self.domain_classifier.parameters())

    def reliability(self, zi, hf, perturb_js_z, av):
        B, FN, _ = hf.shape
        features = torch.cat([
            zi[:, None, :].expand(-1, FN, -1), hf,
            perturb_js_z[:, :, None], av[:, :, None]
        ], dim=-1)
        return torch.sigmoid(self.reliability_gate(features).squeeze(-1))

    @staticmethod
    def positive_utility_reliability(rho):
        """
        Final scaled reliability signal.

        rho is calibrated so 0.5 = neutral signed source utility.
        Only evidence ABOVE neutral is allowed to modify the visual anchor.
        """
        return F.relu(2.0 * rho - 1.0).clamp(0.0, 1.0)

    def effective_weights(self, rho, av):
        supported_av = av * self.source_support.expand_as(av)

        if self.method == "uniform_supported":
            q = torch.ones_like(rho)
        elif self.method in {"learned_attention", "field_utility_rawrho"}:
            # Explicit controls: ordinary nonnegative sigmoid weighting.
            q = rho
        elif self.uses_positive_utility_scaling:
            q = self.positive_utility_reliability(rho)
        else:
            raise ValueError(self.method)

        return q * supported_av, q

    @staticmethod
    def _pool(hf, w):
        denom = w.sum(1, keepdim=True).clamp_min(1e-6)
        return (hf * w[:, :, None]).sum(1) / denom

    def forward(self, image, image_logits, fields, av, perturb_js_z, return_aux=False):
        zi = self.image_proj(image)
        hf = self.field_proj(fields)
        rho = self.reliability(zi, hf, perturb_js_z, av)
        w, scaled_reliability = self.effective_weights(rho, av)
        hm = self._pool(hf, w)

        supported_available = (av * self.source_support.expand_as(av)).sum(1).clamp_min(1.0)
        residual_gate = (w.sum(1) / supported_available).clamp(0.0, 1.0)

        fused = torch.cat([zi, hm], dim=1)
        delta = self.delta_head(fused)
        logits = image_logits + residual_gate[:, None] * delta
        meta_logits = self.meta_head(hm)

        # DA path: reliability weights are detached so domain loss cannot game rho;
        # image representation is absent, so adversarial gradients only align metadata.
        domain_meta = self._pool(hf, w.detach())

        aux = {
            "fused": fused, "domain_meta": domain_meta, "rho": rho,
            "scaled_reliability": scaled_reliability,
            "weights": w, "residual_gate": residual_gate,
            "delta": delta, "meta_logits": meta_logits,
        }
        return (logits, aux) if return_aux else logits

    def domain(self, domain_meta, logits, lambd):
        p = F.softmax(logits, dim=1).detach()
        cdan = torch.bmm(p.unsqueeze(2), domain_meta.unsqueeze(1)).flatten(1)
        return self.domain_classifier(GRL.apply(cdan, float(lambd)))


def grl_lambda(step, total):
    p = min(max(step / max(total - 1, 1), 0.0), 1.0)
    return GRL_MAX * (2.0 / (1.0 + math.exp(-10.0 * p)) - 1.0)


def reliability_loss(rho, target, av):
    mask = av > 0.5
    if not mask.any():
        return torch.zeros((), device=rho.device)
    return F.mse_loss(rho[mask], target[mask])


def optimized_pcgrad(task_loss, domain_loss, model):
    """Project conflicting metadata-domain gradient away from task gradient."""
    sh = model.shared_parameters()
    th = model.task_only_parameters()
    dh = model.domain_head_parameters()

    gt = torch.autograd.grad(task_loss, sh + th, retain_graph=True, allow_unused=True)
    gd = torch.autograd.grad(domain_loss, sh + dh, retain_graph=False, allow_unused=True)

    ns = len(sh)
    gts, gth = gt[:ns], gt[ns:]
    gds, gdh = gd[:ns], gd[ns:]

    zero = torch.zeros((), device=task_loss.device)
    dot = sum(((a*b).sum() for a,b in zip(gts,gds) if a is not None and b is not None), zero)
    norm_t = sum(((a*a).sum() for a in gts if a is not None), zero)
    conflict = (dot < 0) & (norm_t > 0)
    scale = torch.where(conflict, dot / norm_t.clamp_min(1e-12), torch.zeros_like(dot))

    for p,a,b in zip(sh,gts,gds):
        a = torch.zeros_like(p) if a is None else a
        b = torch.zeros_like(p) if b is None else b
        p.grad = (a + b - scale*a).detach()
    for p,g in zip(th,gth):
        p.grad = None if g is None else g.detach()
    for p,g in zip(dh,gdh):
        p.grad = None if g is None else g.detach()
    return conflict.detach().float()


def export_case_predictions_csv(frame, pred, out_path, meta, classes, y_key="y",
                               prob_key="probs", anchor_key="anchor_probs",
                               gate_key=None):
    """Write development-cohort predictions with hashed case/patient keys."""
    import hashlib
    import json
    import os
    idx = pred.get("index", np.arange(len(pred[prob_key]))).astype(int)
    fr = frame.iloc[idx].reset_index(drop=True)
    probs = pred[prob_key]
    anchor = pred.get(anchor_key)
    ys = pred.get(y_key)
    if ys is None:
        raise ValueError("Case export requires labels on known development cohorts.")
    candidates = ("patient_id", "patient_uid", "patient_group_id",
                  "patient_group", "split_group_id", "group_id", "patient")
    patient_col = next((c for c in candidates if c in fr.columns), None)
    rows = []
    class_names = [str(x) for x in classes]
    for i in range(len(fr)):
        path = str(fr.iloc[i].get("image_path", ""))
        # Hash full normalized path for stable matching across methods on this machine.
        case_raw = os.path.normcase(os.path.abspath(path)) if path else f"row-{idx[i]}"
        case_key = hashlib.sha256(case_raw.encode("utf-8")).hexdigest()[:20]
        patient_raw = str(fr.iloc[i][patient_col]) if patient_col else case_key
        if patient_raw.strip().lower() in {"", "nan", "none", "null"}:
            patient_raw = case_key
        group_key = hashlib.sha256(patient_raw.encode("utf-8")).hexdigest()[:20]
        row = {
            **meta,
            "domain": str(meta.get("domain", "")),
            "sample_key": case_key,
            "bootstrap_group_key": group_key,
            "group_key_type": "patient" if patient_col else "case",
            "y_true": int(ys[i]),
            "y_true_name": (class_names[int(ys[i])] if 0 <= int(ys[i]) < len(class_names) else "UNKNOWN"),
            "class_names_json": json.dumps(class_names, ensure_ascii=False),
            "y_pred": int(np.argmax(probs[i])),
            "y_pred_name": class_names[int(np.argmax(probs[i]))],
            "max_softmax_probability": float(np.max(probs[i])),
            "normalized_entropy": float(-(np.clip(probs[i], 1e-12, 1.0) * np.log(np.clip(probs[i], 1e-12, 1.0))).sum() / np.log(len(class_names))),
        }
        for j, value in enumerate(probs[i]):
            row[f"prob_{j:02d}"] = float(value)
        if anchor is not None:
            row["anchor_y_pred"] = int(np.argmax(anchor[i]))
            for j, value in enumerate(anchor[i]):
                row[f"anchor_prob_{j:02d}"] = float(value)
        if gate_key and gate_key in pred:
            gate = pred[gate_key][i]
            row["residual_gate"] = float(np.asarray(gate).mean())
        rows.append(row)
    import pandas as pd
    pd.DataFrame(rows).to_csv(out_path, index=False)

@torch.no_grad()
def predict(model, cache, device):
    model.eval()
    probs, anchor_probs, ys = [], [], []
    rhos, scaled_rels, weights, gates, pjs, avs = [], [], [], [], [], []

    for b in make_loader(cache, BATCH, False):
        b = move(b, device)
        logits, aux = model(
            b["image"],
            b["image_logits"],
            b["fields"],
            b["availability"],
            b["perturb_js_z"],
            True,
        )
        probs.append(F.softmax(logits, dim=1).cpu().numpy())
        anchor_probs.append(F.softmax(b["image_logits"], dim=1).cpu().numpy())
        rhos.append(aux["rho"].cpu().numpy())
        scaled_rels.append(aux["scaled_reliability"].cpu().numpy())
        weights.append(aux["weights"].cpu().numpy())
        gates.append(aux["residual_gate"].cpu().numpy())
        pjs.append(b["perturb_js_z"].cpu().numpy())
        avs.append(b["availability"].cpu().numpy())
        if "label" in b:
            ys.append(b["label"].cpu().numpy())

    return {
        "probs": np.concatenate(probs),
        "anchor_probs": np.concatenate(anchor_probs),
        "y": np.concatenate(ys).astype(int) if ys else None,
        "rho": np.concatenate(rhos),
        "scaled_reliability": np.concatenate(scaled_rels),
        "weights": np.concatenate(weights),
        "residual_gate": np.concatenate(gates),
        "perturb_js_z": np.concatenate(pjs),
        "availability": np.concatenate(avs),
    }


def field_summary(predout, fields, domain, extra=None):
    rows = []
    av = predout["availability"]
    rho = predout["rho"]
    scaled_rel = predout["scaled_reliability"]
    w = predout["weights"]
    pj = predout["perturb_js_z"]

    for j, f in enumerate(fields):
        m = av[:, j] > 0.5
        row = {
            "domain": domain,
            "field": f,
            "n_available": int(m.sum()),
            "availability": float(m.mean()),
            "mean_rho_available": float(rho[m, j].mean()) if m.any() else np.nan,
            "std_rho_available": float(rho[m, j].std()) if m.any() else np.nan,
            "mean_scaled_reliability_available": float(scaled_rel[m, j].mean()) if m.any() else np.nan,
            "std_scaled_reliability_available": float(scaled_rel[m, j].std()) if m.any() else np.nan,
            "fraction_positive_utility_available": float((scaled_rel[m, j] > 0).mean()) if m.any() else np.nan,
            "mean_effective_weight_available": float(w[m, j].mean()) if m.any() else np.nan,
            "mean_calibrated_perturb_js_available": float(pj[m, j].mean()) if m.any() else np.nan,
        }
        if extra:
            row.update(extra)
        rows.append(row)
    return rows


# ---------------------------------------------------------------------
# Experiment
# ---------------------------------------------------------------------

def is_da_method(method):
    return method in {
        "field_utility_scaled_meta_cdan",
        "field_utility_scaled_pcgrad_meta_cdan",
    }


def is_pcgrad_method(method):
    return method == "field_utility_scaled_pcgrad_meta_cdan"


def run_one(root, target_key, method, field_set, seed, force=False, export_only=False):
    if method not in METHODS:
        raise ValueError(method)
    if field_set not in FIELD_SETS:
        raise ValueError(field_set)

    outroot = root / OUTDIR_NAME
    run = outroot / "runs" / target_key / method / field_set / f"seed_{seed}"
    flag = run / "RUN_COMPLETE.flag"

    if flag.exists() and not force and not export_only:
        print(f"[02-v33] skip {target_key}/{method}/{field_set}/s{seed}")
        return

    run.mkdir(parents=True, exist_ok=True)
    f0, f0p = import_f0(root)
    frames, t2, t2p = f0.load_study_frames(root, "development")
    v8, v8p = f0.import_v8(root)

    target_adapt, adapt_path = load_target_adapt(f0, t2, root, target_key)
    fields = FIELD_SETS[field_set]

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    seed_all(seed)

    print(
        f"[02-v33] start target={target_key} method={method} "
        f"field_set={field_set} seed={seed}"
    )
    print("[02-v33] loading frozen PanDerm + pretrained BioClinicalBERT ...")
    enc = load_frozen_encoders(f0, root, frames, t2, v8, seed, device)

    print("[02-v33] building/reusing feature caches ...")
    caches = {}
    caches["source_train"] = base_cache(
        root,
        seed,
        field_set,
        "source_train",
        frames.source_train,
        enc,
        fields,
        device,
        True,
    )
    caches["source_val"] = base_cache(
        root,
        seed,
        field_set,
        "source_val",
        frames.source_val,
        enc,
        fields,
        device,
        True,
    )

    # Source-only perturbation teacher + OOF source-train reliability labels.
    print("[02-v33] building/reusing source cross-fit reliability signals ...")
    teacher, oof, teacher_path, oof_path = ensure_teacher_and_source_signals(
        root,
        seed,
        field_set,
        caches["source_train"],
        caches["source_val"],
        len(f0.KNOWN_CLASSES),
        device,
    )

    caches["source_train"] = ensure_cache_signals(
        root,
        seed,
        field_set,
        "source_train",
        caches["source_train"],
        teacher,
        device,
        calibration=oof,
        source_oof=True,
    )
    caches["source_val"] = ensure_cache_signals(
        root,
        seed,
        field_set,
        "source_val",
        caches["source_val"],
        teacher,
        device,
        calibration=oof,
        source_oof=False,
    )

    # Target-adaptation features are only needed for training. Avoid touching
    # these large label-stripped caches during a prediction-only export.
    if not export_only:
        caches["target_adapt"] = base_cache(
            root,
            seed,
            field_set,
            f"{target_key}_adapt",
            target_adapt,
            enc,
            fields,
            device,
            False,
        )
        caches["target_adapt"] = ensure_cache_signals(
            root,
            seed,
            field_set,
            f"{target_key}_adapt",
            caches["target_adapt"],
            teacher,
            device,
            calibration=oof,
            source_oof=False,
        )

    for d, fr in frames.known_eval.items():
        key = "known_" + re.sub(r"[^A-Za-z0-9]+", "_", d)
        caches[key] = base_cache(
            root, seed, field_set, key, fr, enc, fields, device, True
        )
        caches[key] = ensure_cache_signals(
            root, seed, field_set, key, caches[key], teacher, device,
            calibration=oof, source_oof=False
        )

    idim = caches["source_train"]["image"].shape[1]
    fdim = caches["source_train"]["fields"].shape[2]
    if export_only:
        print("[02-v33] caches ready; loading completed checkpoint for prediction export ...")
    else:
        print("[02-v33] caches ready; resetting RNG and training final field-utility head ...")
    # CRITICAL reproducibility fix: cache hit/miss history cannot affect model RNG.
    seed_all(seed)
    model = FieldReliabilityModel(
        idim, fdim, len(fields), len(f0.KNOWN_CLASSES), method,
        source_support=oof["source_support"],
    ).to(device)

    bestp = run / "best.pt"
    if export_only:
        if not flag.exists():
            raise RuntimeError(f"Refusing export from an incomplete run (RUN_COMPLETE.flag missing): {run}")
        if not bestp.exists():
            raise FileNotFoundError(f"Cannot export; checkpoint missing: {bestp}")
        payload = torch.load(bestp, map_location=device, weights_only=True)
        model.load_state_dict(payload["state_dict"], strict=True)
        out_rows = []
        for d, fr in frames.known_eval.items():
            key = "known_" + re.sub(r"[^A-Za-z0-9]+", "_", d)
            po = predict(model, caches[key], device)
            export_case_predictions_csv(
                fr, po, run / f"case_predictions_{re.sub(r'[^A-Za-z0-9]+', '_', d)}.csv",
                {"target": target_key, "method": method, "field_set": field_set,
                 "seed": seed, "domain": d, "cohort": "development_known_eval"},
                f0.KNOWN_CLASSES, y_key="y", gate_key="residual_gate",
            )
            out_rows.append(pd.read_csv(run / f"case_predictions_{re.sub(r'[^A-Za-z0-9]+', '_', d)}.csv"))
        for d, fr in frames.open_eval.items():
            key = "open_" + re.sub(r"[^A-Za-z0-9]+", "_", d)
            cc = base_cache(root, seed, field_set, key, fr, enc, fields, device, False)
            cc = ensure_cache_signals(
                root, seed, field_set, key, cc, teacher, device,
                calibration=oof, source_oof=False
            )
            po = predict(model, cc, device)
            po["y"] = f0.make_open_targets(fr)
            open_name = f"case_predictions_open_{re.sub(r'[^A-Za-z0-9]+', '_', d)}.csv"
            export_case_predictions_csv(
                fr, po, run / open_name,
                {"target": target_key, "method": method, "field_set": field_set,
                 "seed": seed, "domain": d, "cohort": "development_open_eval"},
                f0.KNOWN_CLASSES, y_key="y", gate_key="residual_gate",
            )
            out_rows.append(pd.read_csv(run / open_name))
        merged = pd.concat(out_rows, ignore_index=True) if out_rows else pd.DataFrame()
        merged.to_csv(run / "case_predictions.csv", index=False)
        for d in frames.known_eval:
            for prefix in ("case_predictions_", "case_predictions_open_"):
                per_domain = run / f"{prefix}{re.sub(r'[^A-Za-z0-9]+', '_', d)}.csv"
                if per_domain.exists():
                    per_domain.unlink()
        print(f"[02-v33] exported development predictions: {run / 'case_predictions.csv'}")
        return

    tr = make_loader(caches["source_train"], TRAIN_BATCH, True)
    va = make_loader(caches["source_val"], BATCH, False)
    ta = make_loader(caches["target_adapt"], TRAIN_BATCH, True)

    weights, counts = f0.effective_number_loss_weights(frames.source_train, device)
    ce = nn.CrossEntropyLoss(weight=weights)
    ce_none = nn.CrossEntropyLoss(weight=weights, reduction="none")

    opt = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=WD)
    sched = torch.optim.lr_scheduler.ReduceLROnPlateau(
        opt, mode="max", factor=0.5, patience=2
    )

    use_da = is_da_method(method)
    use_pcgrad = is_pcgrad_method(method)
    total_steps = EPOCHS * max(len(tr), 1)
    step = 0
    best = -1.0
    patience = 0
    best_epoch = -1
    bestp = run / "best.pt"
    hist = []

    for ep in tqdm(
        range(1, EPOCHS + 1),
        desc=f"02-v33 {target_key}/{method}/{field_set}/s{seed}",
        unit="epoch",
        dynamic_ncols=True,
    ):
        model.train()
        ti = iter(ta)

        agg_loss = torch.zeros((), device=device)
        agg_cls = torch.zeros((), device=device)
        agg_meta = torch.zeros((), device=device)
        agg_safe = torch.zeros((), device=device)
        agg_rel = torch.zeros((), device=device)
        agg_dom = torch.zeros((), device=device)
        agg_conf = torch.zeros((), device=device)
        agg_gate = torch.zeros((), device=device)
        agg_n = 0

        for sb in tr:
            sb = move(sb, device)
            opt.zero_grad(set_to_none=True)

            slog, saux = model(
                sb["image"],
                sb["image_logits"],
                sb["fields"],
                sb["availability"],
                sb["perturb_js_z"],
                True,
            )

            cls = ce(slog, sb["label"])
            meta = ce(saux["meta_logits"], sb["label"])

            final_per = ce_none(slog, sb["label"])
            anchor_per = ce_none(sb["image_logits"].detach(), sb["label"])
            safety = F.relu(final_per - anchor_per).mean()

            rel = torch.zeros((), device=device)
            if model.uses_reliability_supervision:
                rel = reliability_loss(
                    saux["rho"], sb["reliability_target"], sb["availability"]
                )

            task_loss = (
                cls
                + LAMBDA_META * meta
                + LAMBDA_SAFETY * safety
                + (LAMBDA_RELIABILITY * rel if model.uses_reliability_supervision else 0.0)
            )

            dom = torch.zeros((), device=device)
            if use_da:
                try:
                    tb = next(ti)
                except StopIteration:
                    ti = iter(ta)
                    tb = next(ti)

                tb = move(tb, device)
                n = min(len(sb["label"]), len(tb["image"]))

                # Recompute matched source/target batch sizes for CDAN only.
                slog2, saux2 = model(
                    sb["image"][:n],
                    sb["image_logits"][:n],
                    sb["fields"][:n],
                    sb["availability"][:n],
                    sb["perturb_js_z"][:n],
                    True,
                )
                tlog, taux = model(
                    tb["image"][:n],
                    tb["image_logits"][:n],
                    tb["fields"][:n],
                    tb["availability"][:n],
                    tb["perturb_js_z"][:n],
                    True,
                )

                lam = grl_lambda(step, total_steps)
                sd = model.domain(saux2["domain_meta"], slog2, lam)
                td = model.domain(taux["domain_meta"], tlog, lam)

                ls_vec = F.cross_entropy(
                    sd, torch.zeros(n, dtype=torch.long, device=device), reduction="none"
                )
                lt_vec = F.cross_entropy(
                    td, torch.ones(n, dtype=torch.long, device=device), reduction="none"
                )
                sw = saux2["residual_gate"].detach()
                tw = taux["residual_gate"].detach()
                ls = (ls_vec * sw).sum() / sw.sum().clamp_min(1e-6)
                lt = (lt_vec * tw).sum() / tw.sum().clamp_min(1e-6)
                dom = 0.5 * (ls + lt)

            if use_pcgrad:
                conflict = optimized_pcgrad(task_loss, DOMAIN_W * dom, model)
                agg_conf += conflict
                total_loss_for_log = task_loss + DOMAIN_W * dom.detach()
            else:
                total_loss = task_loss + DOMAIN_W * dom
                total_loss.backward()
                total_loss_for_log = total_loss

            torch.nn.utils.clip_grad_norm_(model.parameters(), GRAD_CLIP)
            opt.step()

            bs = len(sb["label"])
            agg_n += bs
            agg_loss += total_loss_for_log.detach() * bs
            agg_cls += cls.detach() * bs
            agg_meta += meta.detach() * bs
            agg_safe += safety.detach() * bs
            agg_rel += rel.detach() * bs
            agg_dom += dom.detach() * bs
            agg_gate += saux["residual_gate"].mean().detach() * bs
            step += 1

        pv = predict(model, caches["source_val"], device)
        vm = f0.closed_metrics(pv["y"], pv["probs"])
        sched.step(vm["macro_f1"])

        improved = vm["macro_f1"] > best + 1e-12
        if improved:
            best = vm["macro_f1"]
            best_epoch = ep
            patience = 0
            torch.save(
                {
                    "state_dict": model.state_dict(),
                    "source_support": torch.as_tensor(oof["source_support"], dtype=torch.float32).cpu(),
                    "utility_scale": torch.as_tensor(oof["utility_scale"], dtype=torch.float32).cpu(),
                    "fields": fields,
                    "method": method,
                    "field_set": field_set,
                    "seed": seed,
                    "best_source_val_macro_f1": best,
                },
                bestp,
            )
        else:
            patience += 1

        hist.append(
            {
                "epoch": ep,
                "train_loss": float((agg_loss / max(agg_n, 1)).cpu()),
                "class_ce": float((agg_cls / max(agg_n, 1)).cpu()),
                "metadata_aux_ce": float((agg_meta / max(agg_n, 1)).cpu()),
                "safety_hinge": float((agg_safe / max(agg_n, 1)).cpu()),
                "reliability_loss": float((agg_rel / max(agg_n, 1)).cpu()),
                "domain_loss": float((agg_dom / max(agg_n, 1)).cpu()),
                "pcgrad_conflict_batches": float(agg_conf.cpu()),
                "mean_residual_gate_train": float((agg_gate / max(agg_n, 1)).cpu()),
                "source_val_macro_f1": vm["macro_f1"],
                "source_val_balanced_accuracy": vm["balanced_accuracy"],
                "mean_residual_gate_val": float(pv["residual_gate"].mean()),
                "mean_rho_val_available": float(
                    pv["rho"][pv["availability"] > 0.5].mean()
                )
                if (pv["availability"] > 0.5).any()
                else np.nan,
                "patience": patience,
            }
        )

        if patience >= EARLY_STOP:
            break

    pd.DataFrame(hist).to_csv(run / "history.csv", index=False)

    payload = torch.load(bestp, map_location=device, weights_only=True)
    model.load_state_dict(payload["state_dict"], strict=True)

    # ----------------------------- closed-set -------------------------
    closed = []
    field_rows = []

    for d, fr in frames.known_eval.items():
        key = "known_" + re.sub(r"[^A-Za-z0-9]+", "_", d)
        po = predict(model, caches[key], device)

        met = f0.closed_metrics(po["y"], po["probs"])
        anchor_met = f0.closed_metrics(po["y"], po["anchor_probs"])

        final_pred = po["probs"].argmax(1)
        anchor_pred = po["anchor_probs"].argmax(1)
        y = po["y"]

        harm = float(((anchor_pred == y) & (final_pred != y)).mean())
        rescue = float(((anchor_pred != y) & (final_pred == y)).mean())
        override = float((anchor_pred != final_pred).mean())

        available_mask = po["availability"] > 0.5

        closed.append(
            {
                "target": target_key,
                "method": method,
                "field_set": field_set,
                "seed": seed,
                "domain": d,
                "n": len(fr),
                "best_epoch": best_epoch,
                "best_source_val_macro_f1": best,
                "anchor_macro_f1": anchor_met["macro_f1"],
                "delta_macro_f1_vs_anchor": met["macro_f1"] - anchor_met["macro_f1"],
                "harm_rate_anchor_correct_final_wrong": harm,
                "rescue_rate_anchor_wrong_final_correct": rescue,
                "prediction_override_rate": override,
                "mean_residual_gate": float(po["residual_gate"].mean()),
                "std_residual_gate": float(po["residual_gate"].std()),
                "mean_rho_available": float(po["rho"][available_mask].mean())
                if available_mask.any()
                else np.nan,
                "std_rho_available": float(po["rho"][available_mask].std())
                if available_mask.any()
                else np.nan,
                "mean_scaled_reliability_available": float(
                    po["scaled_reliability"][available_mask].mean()
                ) if available_mask.any() else np.nan,
                "fraction_positive_utility_available": float(
                    (po["scaled_reliability"][available_mask] > 0).mean()
                ) if available_mask.any() else np.nan,
                "mean_effective_field_weight_available": float(
                    po["weights"][available_mask].mean()
                )
                if available_mask.any()
                else np.nan,
                **met,
            }
        )

        field_rows.extend(
            field_summary(
                po,
                fields,
                d,
                {
                    "target": target_key,
                    "method": method,
                    "field_set": field_set,
                    "seed": seed,
                },
            )
        )

    pd.DataFrame(closed).to_csv(run / "closed_metrics.csv", index=False)
    pd.DataFrame(field_rows).to_csv(run / "field_diagnostics.csv", index=False)

    # ----------------------------- open-world -------------------------
    threshold, ood = f0.prepare_ood_cache(root, outroot, frames, v8)
    op = []

    for d, fr in frames.open_eval.items():
        key = "open_" + re.sub(r"[^A-Za-z0-9]+", "_", d)

        cc = base_cache(
            root, seed, field_set, key, fr, enc, fields, device, False
        )
        cc = ensure_cache_signals(
            root, seed, field_set, key, cc, teacher, device,
            calibration=oof, source_oof=False
        )

        po = predict(model, cc, device)
        y_open = f0.make_open_targets(fr)
        met = f0.open_metrics(y_open, po["probs"], ood[d], threshold)

        op.append(
            {
                "target": target_key,
                "method": method,
                "field_set": field_set,
                "seed": seed,
                "domain": d,
                "n": len(fr),
                "n_known": int((y_open != f0.UNKNOWN_ID).sum()),
                "n_unknown": int((y_open == f0.UNKNOWN_ID).sum()),
                "mean_residual_gate": float(po["residual_gate"].mean()),
                **met,
            }
        )

    pd.DataFrame(op).to_csv(run / "open_metrics.csv", index=False)

    # Source perturbation audit by field (OOF only).
    avs = caches["source_train"]["availability"].astype(np.float32)
    srcdiag = []
    for j, f in enumerate(fields):
        m = avs[:, j] > 0.5
        srcdiag.append(
            {
                "field": f,
                "n_available": int(m.sum()),
                "availability": float(m.mean()),
                "oof_mean_raw_perturb_js": float(oof["perturb_js_raw"][m, j].mean())
                if m.any() else np.nan,
                "oof_mean_calibrated_perturb_js": float(oof["perturb_js_z"][m, j].mean())
                if m.any() else np.nan,
                "oof_mean_field_utility": float(oof["field_utility_raw"][m, j].mean())
                if m.any() else np.nan,
                "oof_mean_reliability_target": float(oof["reliability_target"][m, j].mean())
                if m.any()
                else np.nan,
                "oof_mean_positive_utility_target": float(
                    oof["positive_utility_target"][m, j].mean()
                ) if m.any() else np.nan,
                "oof_fraction_positive_utility_target": float(
                    (oof["positive_utility_target"][m, j] > 0).mean()
                ) if m.any() else np.nan,
            }
        )
    pd.DataFrame(srcdiag).to_csv(
        run / "source_oof_field_utility_audit.csv", index=False
    )

    jdump(
        {
            "protocol": "02_positive_utility_scaled_field_reliability_v33",
            "f0_script": f0p,
            "table2": t2p,
            "v8": v8p,
            "target": target_key,
            "target_adapt": adapt_path,
            "target_labels_in_optimizer": False,
            "target_labels_in_reliability": False,
            "target_labels_in_perturbation_signal": False,
            "target_test_read": False,
            "method": method,
            "field_set": field_set,
            "fields": fields,
            "seed": seed,
            "image_anchor_checkpoint": image_ckpt(root, seed),
            "image_anchor": "frozen source-fine-tuned F0 PanDerm image-only",
            "field_encoder": "frozen vanilla pretrained BioClinicalBERT",
            "teacher_checkpoint": teacher_path,
            "source_oof_signal_file": oof_path,
            "crossfit_folds": CROSSFIT_FOLDS,
            "reliability_target": "rho*=sigmoid(clip((CE_without_field-CE_full)/source_only_robust_scale,-6,6)); OOF source_train only",
            "scaled_reliability": "q=relu(2*rho-1); parameter-free; rho=0.5 is neutral and maps to zero metadata influence",
            "perturbation_signal": "leave-one-field-out JS robust-standardized per field using source OOF only",
            "source_support": "fields unseen in source_train receive zero effective weight",
            "residual": "anchor_logits + mean positive-utility scaled reliability * metadata_delta",
            "domain_adaptation": "metadata-only CDAN; reliability weights and class probabilities detached in DA path",
            "loss": {
                "classification": 1.0,
                "metadata_auxiliary": LAMBDA_META,
                "source_anchor_safety": LAMBDA_SAFETY,
                "field_utility_supervision": LAMBDA_RELIABILITY if model.uses_reliability_supervision else 0.0,
                "domain": DOMAIN_W if use_da else 0.0,
            },
            "selection": "PAD source_val Macro-F1 only",
            "openworld": "same frozen F0 DermLIP-MCM branch; 02-v3.2 does not claim to solve OOD rejection",
            "execution_optimizations": [
                "reuse v3.1 PanDerm/BioClinicalBERT feature caches",
                "unique structured prompts encoded once",
                "final RNG reset after cache/teacher work"
            ],
            "reviewer_controls": [
                "uniform source-supported fields",
                "architecture-matched learned attention without utility supervision",
                "source-calibrated field utility",
                "field utility + metadata-only CDAN",
                "field utility + metadata-only CDAN + Shared-PCGrad"
            ],
        },
        run / "run_manifest.json",
    )

    flag.write_text("complete\n", encoding="utf-8")

    del model, teacher
    for obj in enc:
        try:
            del obj
        except Exception:
            pass
    cleanup()


# ---------------------------------------------------------------------
# Aggregation / launcher
# ---------------------------------------------------------------------

def aggregate(root):
    base = root / OUTDIR_NAME
    for fn in [
        "closed_metrics.csv",
        "open_metrics.csv",
        "field_diagnostics.csv",
        "source_oof_field_utility_audit.csv",
    ]:
        ps = list((base / "runs").glob(f"*/*/*/seed_*/{fn}"))
        if not ps:
            continue
        df = pd.concat([pd.read_csv(x) for x in ps], ignore_index=True)
        df.to_csv(base / f"ALL_{fn}", index=False)

        if fn in {"closed_metrics.csv", "open_metrics.csv"}:
            nums = [
                c for c in df.columns
                if pd.api.types.is_numeric_dtype(df[c])
                and c not in {"seed", "n", "n_known", "n_unknown", "best_epoch"}
            ]
            keys = ["target", "method", "field_set", "domain"]
            z = df.groupby(keys)[nums].agg(["mean", "std"]).reset_index()
            z.columns = [
                "_".join([str(x) for x in c if str(x)]) if isinstance(c, tuple) else str(c)
                for c in z.columns
            ]
            z.to_csv(base / f"MEAN_STD_{fn}", index=False)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, default=DEFAULT_ROOT)
    ap.add_argument("--targets", default="isic,mcr")
    ap.add_argument("--methods", default=",".join(METHODS))
    ap.add_argument("--field-sets", default="core3,full")
    ap.add_argument("--seeds", default="42,123,2026")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--export-predictions-only", action="store_true", help="Load completed best.pt checkpoints and export labeled development predictions; do not train.")

    ap.add_argument("--child-target", choices=list(TARGETS))
    ap.add_argument("--child-method", choices=METHODS)
    ap.add_argument("--child-field-set", choices=list(FIELD_SETS))
    ap.add_argument("--child-seed", type=int)

    args = ap.parse_args()
    root = args.root.resolve()

    targets = [x.strip() for x in args.targets.split(",") if x.strip()]
    methods = [x.strip() for x in args.methods.split(",") if x.strip()]
    fsets = [x.strip() for x in args.field_sets.split(",") if x.strip()]
    seeds = [int(x) for x in args.seeds.split(",") if x.strip()]

    if args.child_target:
        run_one(
            root,
            args.child_target,
            args.child_method,
            args.child_field_set,
            args.child_seed,
            args.force,
            args.export_predictions_only,
        )
        return

    # Preflight: corrected source/dev frames, physically label-stripped target
    # adaptation files, and F0 PanDerm anchors only.
    f0, _ = import_f0(root)
    frames, t2, _ = f0.load_study_frames(root, "development")

    for t in targets:
        load_target_adapt(f0, t2, root, t)

    for s in seeds:
        if not image_ckpt(root, s).exists():
            raise FileNotFoundError(image_ckpt(root, s))

    jobs = [
        (t, m, fs, s)
        for t in targets
        for m in methods
        for fs in fsets
        for s in seeds
    ]

    base = root / OUTDIR_NAME / "runs"
    rem = []
    done = 0

    for t, m, fs, s in jobs:
        run_dir = base / t / m / fs / f"seed_{s}"
        flag = run_dir / "RUN_COMPLETE.flag"
        if args.export_predictions_only:
            if (run_dir / "RUN_COMPLETE.flag").exists() and (run_dir / "best.pt").exists():
                rem.append((t, m, fs, s))
            else:
                print(f"[02-v33] incomplete or missing checkpoint; skipping export: {run_dir}")
        elif flag.exists() and not args.force:
            done += 1
        else:
            rem.append((t, m, fs, s))

    print(
        f"[02-v33] resume {done}/{len(jobs)} complete; {len(rem)} remaining"
    )

    bar = tqdm(
        total=len(jobs),
        initial=done,
        desc="02-v33 field-utility runs",
        unit="run",
        dynamic_ncols=True,
    )

    for t, m, fs, s in rem:
        bar.set_postfix_str(f"{t}/{m}/{fs}/s{s}")
        cmd = [
            sys.executable,
            str(Path(__file__).resolve()),
            "--root",
            str(root),
            "--child-target",
            t,
            "--child-method",
            m,
            "--child-field-set",
            fs,
            "--child-seed",
            str(s),
        ]
        if args.force:
            cmd.append("--force")
        if args.export_predictions_only:
            cmd.append("--export-predictions-only")
        subprocess.check_call(cmd)
        bar.update(1)

    bar.close()
    aggregate(root)


if __name__ == "__main__":
    main()
